# Verificação — 08/10/2026

## Executado neste ambiente

- `npm test`: 6 testes, 6 passaram; nenhum ignorado.
- `npm run test:browser`: passou em Chromium headless via Playwright.
- Campanha completa pela rota honesta, incluindo prólogo, chegada, grupos, amizade, nove ações de rotina, cinco questões, lógica, preparação, apresentação e encerramento.
- Colisão dos pés com uma carteira do mapa Tiled: movimento bloqueado corretamente.
- Pausa e retomada sem perder o estado.
- Restauração de checkpoint pelo menu CONTINUAR após destruir e recriar o jogo.
- Rota da cola: pista segurando C, respiração, professor com padrão previsível, flagrante e retorno à escolha; nova tentativa concluída com sucesso.
- Prova reprovada com pontuação zero: tentativa reiniciada em 100 sem repetir a campanha.
- CONHECER NOSSO PROJETO: Phaser destruído, página visível, teclado liberado.
- Viewport móvel 390 × 844: sem overflow horizontal.
- Nenhum erro JavaScript de página ou resposta HTTP 4xx/5xx durante os fluxos finais.
- `npm run build`: build estático com engine, código e assets locais.

Os testes aceleram os diálogos via ENTER e posicionam o protagonista perto dos NPCs; isso valida o encadeamento e as interações sem medir a duração de uma sessão humana. A colisão foi testada separadamente. A rota arriscada usa tempo real de patrulha.

## Ainda precisa de playtest humano

- Ritmo de 25–35 minutos, dificuldade e percepção de qualidade artística.
- Touch em aparelhos reais, Safari/iOS e diferentes dispositivos de áudio.
- Publicação no domínio final e integração com o conteúdo real da equipe.
- Preenchimento dos créditos em `Javascript/data/configJogo.js`.

A arte é procedural original, e a encenação é compacta. O protagonista original mencionado no roteiro não estava presente: foi entregue um novo spritesheet compatível. Não há uso da API Sprite Fusion.
