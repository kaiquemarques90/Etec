# PROMPT MESTRE — SURVIVE AT ETEC
## Documento completo de criação, roteiro, arte, programação e game design

Você será meu **diretor criativo, roteirista, game designer, pixel artist, programador Phaser 3, level designer e sound designer**.

Quero que desenvolva um jogo completo chamado **SURVIVE AT ETEC**, destinado à apresentação em uma feira escolar (EPA) da ETEC.

Não quero apenas ideias ou um protótipo superficial. Quero um jogo polido, divertido, com identidade visual própria, narrativa coerente, cutscenes, animações, efeitos sonoros, músicas, personagens carismáticos, quatro níveis jogáveis, sistemas de HUD, minigames, consequências, telas de transição e encerramento.

Este documento é a especificação criativa principal. **Siga o roteiro, mas melhore a apresentação, o ritmo, a experiência do jogador e os detalhes de implementação sempre que isso contribuir para a qualidade final.**

---

# 1. VISÃO GERAL DO JOGO

**Nome:** Survive at ETEC

**Subtítulo:** Um ano. Quatro bimestres. Boa sorte.

**Gênero:** Aventura narrativa 2D, pixel art, humor escolar, exploração, minigames e gerenciamento de recursos.

**Plataforma:** Navegador, integrado a um site.

**Engine:** Phaser 3.90.0.

**Linguagens:** HTML5, CSS3 e JavaScript.

**Mapas:** Tiled, com exportação JSON compatível com Phaser 3.

**Resolução-base:** 640 × 360 pixels, com escalonamento responsivo e pixel art nítida.

**Duração desejada:** 25–35 minutos, podendo ser concluído mais rapidamente por jogadores experientes.

**Ambientação:** ETEC Sales Gomes, em Tatuí, São Paulo, representada de forma estilizada e inspirada em uma escola técnica brasileira.

**Tom narrativo:** Humor cotidiano, ironia, amizade, pressão acadêmica, pequenas situações absurdas e uma conclusão emocional.

## Premissa

O jogador acabou de passar no vestibulinho da ETEC.

Inicialmente, acredita que a parte difícil acabou.

Porém, logo descobre que sobreviver ao primeiro ano será uma aventura muito mais complicada do que imaginava.

O jogo acompanha quatro bimestres:

1. **Primeiro bimestre — Faça amigos.** O desafio é se enturmar.
2. **Segundo bimestre — Sobreviva às provas.** O desafio é administrar tempo, energia e notas.
3. **Terceiro bimestre — A tentação da cola.** O desafio é lidar com pressão, escolhas e risco.
4. **Quarto bimestre — O EPA.** O desafio final é apresentar um projeto diante de professores, avaliadores e visitantes.

A história deve evoluir de forma contínua. Os amigos conquistados no primeiro bimestre devem voltar nos demais. As experiências anteriores devem influenciar diálogos posteriores.

O humor não deve ridicularizar pessoas reais. O professor Diogo será representado como um personagem carismático, exigente e engraçado, inspirado no professor de programação e algoritmos do projeto.

---

# 2. IDENTIDADE VISUAL

## Direção artística obrigatória

Quero pixel art 2D de qualidade, com perspectiva **top-down ou três quartos**, iluminação suave, ambientes escolares detalhados e personagens expressivos.

Referências de linguagem visual:

- Undertale: apresentação dos diálogos, humor e ritmo narrativo.
- Stardew Valley: cenários acolhedores, organização espacial e legibilidade.
- Jogos RPG indie pixel art: animações, expressões e exploração.
- Pixel art escolar brasileira: carteiras, computadores, quadro, mochilas, corredores, murais e objetos cotidianos.

**Não copie sprites, músicas, interfaces ou personagens dessas obras. Crie uma identidade original.**

## Paleta sugerida

| Uso | Cor |
|---|---|
| Azul-escuro principal | `#1C2231` |
| Preto azulado | `#11151F` |
| Creme dos ambientes | `#E7D6B8` |
| Marrom da madeira | `#A77D58` |
| Azul escolar | `#4D739C` |
| Vermelho de alerta | `#AD4251` |
| Roxo narrativo | `#6C5B7B` |
| Amarelo de destaque | `#F2CB78` |
| Branco da interface | `#F2F2F2` |

A iluminação deve variar entre as cenas:

- Primeiro dia: manhã clara, tons quentes.
- Primeiro bimestre: ambiente acolhedor, mas socialmente intimidante.
- Segundo bimestre: contraste maior e sombras que transmitam cansaço.
- Terceiro bimestre: iluminação mais fria, clima de suspense.
- Quarto bimestre: iluminação de evento, telas, banners e luzes de apresentação.
- Final: tons suaves, nostálgicos e um pouco melancólicos.

## Regras de consistência

O player atual já existe e funciona.

**Não recrie, substitua ou altere o spritesheet principal do player.**

Seu arquivo é `Assets/sprites/player.png`, com 12 frames de 96 × 96 pixels, organizados em 3 colunas e 4 linhas:

- Frames 0–2: andando para baixo.
- Frames 3–5: andando para esquerda.
- Frames 6–8: andando para direita.
- Frames 9–11: andando para cima.

A escala visual deve ser ajustada em relação às mesas, portas e demais personagens. Não aumente o player arbitrariamente.

Use uma hitbox reduzida, concentrada nos pés, para colisões naturais.

Os novos NPCs devem combinar com a proporção visual do personagem existente.

Evite incorporar personagens dentro de imagens de cenário. Personagens devem ser sprites separados, permitindo animação, profundidade e interação.

Use ordenação por profundidade baseada na posição Y sempre que apropriado.

---

# 3. ESTRUTURA COMPLETA DO JOGO

A sequência narrativa será:

**Boot → Prólogo → Menu principal → Cutscene do primeiro dia → Bimestre 1 → Transição → Bimestre 2 → Transição → Bimestre 3 → Transição → Bimestre 4 → Cutscene final → Encerramento → Site do EPA.**

Cada etapa deve ter início, desenvolvimento, clímax e conclusão.

Não quero quatro minigames desconectados. Quero uma história única.

---

# 4. PRÓLOGO — VOCÊ PASSOU

## Cena P01 — Tela inicial

**Duração:** aproximadamente 10–20 segundos, dependendo do jogador.

**Fundo:** preto quase absoluto, com pequenos pontos de luz em pixel art e uma textura discreta.

**Sprites:** inicialmente nenhum personagem.

**Música:** notas isoladas de piano e sintetizador, em andamento lento.

**Interface:** caixa de diálogo preta com borda branca, na parte inferior, inspirada em RPGs narrativos.

O texto deve surgir letra por letra.

O som de digitação deve ser discreto, com pequenos bipes.

O jogador aperta ENTER para completar a frase e novamente para avançar.

### Diálogos

NARRADOR:

"Parabéns."

"Você passou no vestibulinho."

"Depois de tanto estudar..."

"...finalmente conseguiu entrar na ETEC."

Pausa de aproximadamente 1 segundo.

NARRADOR:

"Você provavelmente acha que a parte difícil acabou."

Pausa.

"Que ingenuidade."

A tela apresenta um pequeno tremor, acompanhado de um som grave cômico.

NARRADOR:

"Agora começa o verdadeiro desafio."

"Um ano."

"Quatro bimestres."

"E muitas coisas que ninguém explicou no vestibulinho."

Última frase:

"Bem-vindo à ETEC."

## Cena P02 — A carta de aprovação

**Fundo:** quarto do protagonista, em pixel art, com mesa, computador, mochila, janela e cama.

**Primeiro plano:** tela de computador exibindo uma notificação estilizada de aprovação.

**Sprites:** player sentado diante do computador.

**Câmera:** aproximação lenta da tela.

**Música:** melodia esperançosa, ainda discreta.

### Diálogos

PLAYER (pensamento):

"Eu consegui..."

"Caramba."

"EU CONSEGUI!"

Pequena animação do personagem levantando os braços.

PLAYER:

"Agora vai ser tranquilo."

A música para abruptamente por um instante.

NARRADOR:

"É claro."

"...tranquilo."

## Cena P03 — Transição para o menu

A câmera se afasta da janela do quarto.

A imagem escurece.

Ouvimos um sinal escolar distante.

Surge lentamente o logotipo:

**SURVIVE AT ETEC**

A música principal começa.

---

# 5. MENU PRINCIPAL

## Aparência

Não quero um fundo preto simples.

O menu deve mostrar uma composição pixel art da escola.

**Fundo:**

- Fachada estilizada da ETEC.
- Céu azul com nuvens animadas lentamente.
- Árvores balançando.
- Algumas janelas iluminadas.
- Silhuetas de estudantes entrando.
- Pequenos elementos relacionados a programação, livros, provas e relógios.
- Eventualmente, folhas atravessando a tela.

**Primeiro plano:** título grande em pixel art, com contorno e sombra.

Texto:

**SURVIVE AT ETEC**

Abaixo:

"Um ano. Quatro bimestres. Boa sorte."

## Menu

- COMEÇAR
- CONTINUAR
- OPÇÕES
- CRÉDITOS

O jogador navega com as setas e confirma com ENTER.

A opção CONTINUAR só fica disponível quando existe progresso salvo.

## Animações

- O título entra com leve movimento vertical.
- As opções aparecem em sequência.
- O item selecionado recebe uma seta ou destaque.
- Ao mudar a seleção, toca um som curto.
- Ao confirmar, toca um efeito sonoro diferente.
- O menu não deve ter piscadas excessivas.

## Música

Tema original de aproximadamente 100 BPM.

Estilo: chiptune melódico com piano elétrico, baixo suave, bateria eletrônica leve e sintetizadores nostálgicos.

Deve ser animado, mas com uma pequena sensação de que algo está por vir.

## Transição ao começar

Ao selecionar COMEÇAR:

1. O som de confirmação toca.
2. As opções desaparecem.
3. A música diminui gradualmente.
4. A tela escurece durante aproximadamente 900 ms.
5. Começa a cutscene do primeiro dia.

---

# 6. CUTSCENE — PRIMEIRO DIA DE AULA

## Cena C01 — Caminho para a ETEC

**Fundo:** rua brasileira em pixel art, calçada, árvores, postes, carros estacionados e a fachada estilizada da escola ao fundo.

**Sprites:** player andando com mochila; dois alunos entrando pelo portão.

**Câmera:** movimento lateral suave acompanhando o personagem.

**Música:** tema leve de manhã, com piano, sintetizador e sons ambientes.

### Diálogos

PLAYER (pensamento):

"Primeiro dia."

"Escola nova."

"Pessoas novas."

"Eu consigo."

Pausa.

"...eu acho."

## Cena C02 — Entrada da escola

**Fundo:** portão, pátio e entrada da ETEC.

**Sprites:** alunos conversando em pequenos grupos; um estudante correndo atrasado; outro olhando o celular.

**Efeitos sonoros:** passos, conversas indistintas, pássaros e sinal escolar.

### Diálogos

ALUNO CORRENDO:

"LICENÇA! EU TÔ ATRASADO!"

O aluno atravessa a cena rapidamente.

PLAYER:

"Mas a aula nem começou..."

NARRADOR:

"Você descobrirá que isso não importa."

## Cena C03 — Corredor

**Fundo:** corredor escolar com portas, murais, janelas, placas, lixeiras e bebedouro.

**Sprites:** player caminhando; NPCs ambientais.

**Câmera:** segue o player até uma porta.

### Diálogos

PLAYER:

"Primeiro ano de Desenvolvimento de Sistemas..."

"Deve ser aqui."

Ele para diante da sala.

PLAYER:

"Tá. É só entrar."

Pausa.

"...por que eu tô nervoso?"

## Cena C04 — Entrando na sala

**Fundo:** mapa da sala de aula.

**Câmera:** primeiro enquadra o player entrando, depois percorre lentamente o ambiente.

Mostrar:

- Professor Diogo perto do quadro.
- Alunos conversando.
- Um grupo estudando.
- Um grupo jogando ou falando de jogos.
- Um grupo silencioso.
- Um grupo descontraído.
- Um aluno dormindo.
- Um aluno escondido debaixo de uma mesa.
- Computadores, carteiras, armários e mochilas.

**Música:** diminui para destacar o som da sala.

### Diálogos

PLAYER (pensamento):

"Uau."

"Todo mundo já parece conhecer alguém."

"Tem até gente que já formou grupo."

A câmera mostra o aluno debaixo da mesa.

PLAYER:

"...e tem alguém escondido ali?"

O professor começa a falar.

DIOGO:

"Bom dia, pessoal."

"Sejam bem-vindos ao curso de Desenvolvimento de Sistemas."

"Espero que gostem de lógica."

Pausa.

DIOGO:

"Porque vocês vão precisar."

Pequeno efeito sonoro dramático.

PLAYER:

"Isso foi uma ameaça?"

## Cena C05 — Apresentação do primeiro objetivo

A câmera retorna ao protagonista.

A tela escurece parcialmente.

Surge um painel:

**1º BIMESTRE**

**OBJETIVO: FAÇA AMIGOS**

NARRADOR:

"Seu primeiro desafio não será uma prova."

"Será encontrar alguém com quem passar o intervalo."

O controle é entregue ao jogador.

---

# 7. PRIMEIRO BIMESTRE — FAÇA AMIGOS

## Cenário

Sala de aula explorável com mapa feito no Tiled.

A sala deve conter:

- Quadro branco e projetor.
- Mesa do professor.
- Carteiras e cadeiras.
- Computadores.
- Armários.
- Janelas.
- Lixeira.
- Mochilas.
- Relógio.
- Cartazes.
- Plantas.
- Pequenos objetos decorativos.

O cenário deve parecer habitado.

## Grupos

Criar quatro sprites de grupos, cada um com três ou quatro estudantes juntos.

### Grupo 1 — Tryhards

Visual: estudantes com óculos, cadernos, notebooks, roupas organizadas e postura séria.

Local: próximo ao quadro.

Personalidade: competitivos, preocupados com notas e vestibulares.

### Grupo 2 — Jogadores

Visual: estudantes com bonés, fones, camisetas temáticas originais, mochilas e acessórios.

Local: próximo aos computadores.

Personalidade: jogadores, competitivos em games e fãs de tecnologia.

### Grupo 3 — Misteriosos

Visual: roupas escuras, cabelo cobrindo parte do rosto, postura reservada e acessórios discretos.

Local: perto das janelas.

Personalidade: silenciosos, enigmáticos e um pouco excêntricos.

### Grupo 4 — Artistas/Alternativos

Visual: roupas variadas, sketchbooks, adesivos, acessórios coloridos e mochilas personalizadas.

Local: região posterior da sala.

Personalidade: acolhedores, criativos, brincalhões e interessados em projetos.

Este será o grupo de amigos do protagonista.

## Mecânica principal

O jogador anda com WASD ou setas.

Ao chegar perto de um grupo, aparece:

**[E] CONVERSAR**

O jogo pausa o movimento durante o diálogo.

Os três primeiros grupos rejeitam o jogador de maneiras diferentes.

O quarto grupo o aceita.

Para garantir progressão narrativa, o grupo 4 pode ser encontrado antes dos outros, mas sua aceitação definitiva acontece depois de o jogador conhecer os outros três grupos. O jogador pode visitá-los em qualquer ordem.

## HUD do primeiro bimestre

Canto superior esquerdo:

**1º BIMESTRE**

Abaixo:

"Objetivo: encontre seu grupo."

Canto superior direito:

**GRUPOS CONHECIDOS: 0/3**

Quando encontrar amigos:

**AMIZADE: 1**

O HUD deve ser discreto e não esconder a sala.

---

## Diálogo — Grupo 1

Ao apertar E:

TRYHARD 1:

"Você é novo aqui?"

PLAYER:

"Sou. Posso ficar com vocês?"

TRYHARD 2:

"Depende."

"Quanto você tirou no vestibulinho?"

PLAYER:

"Eu... passei?"

TRYHARD 3:

"Isso não responde à pergunta."

TRYHARD 1:

"Você já começou a estudar para o ENEM?"

PLAYER:

"Mas a gente acabou de entrar..."

TRYHARD 2:

"Exatamente."

TRYHARD 1:

"Desculpa, nosso grupo está completo."

PLAYER (pensamento):

"Eu só queria conversar..."

**Resultado:** grupo rejeita.

Efeito: som curto de rejeição.

HUD atualizado.

---

## Diálogo — Grupo 2

JOGADOR 1:

"E aí, mano."

"Você joga alguma coisa?"

PLAYER:

"Jogo, sim."

JOGADOR 2:

"Qual seu rank?"

PLAYER:

"Em quê?"

JOGADOR 3:

"Isso já responde."

PLAYER:

"Eu também gosto de programação."

JOGADOR 1:

"Legal."

"Mas nosso squad tá fechado."

JOGADOR 2:

"Foi mal."

PLAYER (pensamento):

"Até na escola tem matchmaking..."

**Resultado:** grupo rejeita.

---

## Diálogo — Grupo 3

PLAYER:

"Oi..."

MISTERIOSO 1:

"..."

PLAYER:

"Posso ficar aqui?"

MISTERIOSO 2:

"......"

PLAYER:

"Vocês estão fazendo alguma coisa?"

MISTERIOSO 3:

"Estamos esperando."

PLAYER:

"Esperando o quê?"

MISTERIOSO 1:

"O momento."

Pausa de dois segundos.

PLAYER:

"Tá bom..."

MISTERIOSO 2:

"Não."

PLAYER:

"...entendi."

**Resultado:** grupo rejeita.

A música deve ficar silenciosa por um instante para valorizar a piada.

---

## Diálogo — Grupo 4

Quando o jogador chega:

LIA:

"Ei!"

"Você é o aluno novo, né?"

PLAYER:

"Sou."

NIKO:

"Você tá procurando alguém pra conversar?"

PLAYER:

"Mais ou menos."

BIA:

"Ele tá com cara de quem já foi rejeitado três vezes."

PLAYER:

"..."

NIKO:

"Caramba, acertou?"

LIA:

"Relaxa."

"Pode ficar aqui com a gente."

PLAYER:

"Sério?"

LIA:

"Claro."

"Você gosta de fazer o quê?"

Aparecem três opções:

**[1] Programação e tecnologia.**

**[2] Jogos e música.**

**[3] Eu ainda tô descobrindo.**

### Resposta 1

PLAYER:

"Eu gosto de programação e tecnologia."

NIKO:

"Então você vai se dar bem com a gente."

BIA:

"Principalmente quando nossos códigos pararem de funcionar."

### Resposta 2

PLAYER:

"Jogos e música."

BIA:

"Perfeito."

NIKO:

"Já temos assunto pro intervalo inteiro."

### Resposta 3

PLAYER:

"Eu ainda tô descobrindo."

LIA:

"Melhor ainda."

"Tem um monte de coisa pra descobrir aqui."

### Continuação comum

LIA:

"Enfim, seja bem-vindo."

NIKO:

"Agora você faz parte do grupo."

BIA:

"Infelizmente."

PLAYER:

"Infelizmente?"

BIA:

"Você vai entender."

Os personagens riem.

**HUD: AMIZADE +1**

Efeito visual: pequenas estrelas ou corações pixelados, sem exagero.

---

## NPCs ambientais e easter eggs

### Aluno debaixo da mesa

PLAYER:

"Por que você tá aí?"

ALUNO:

"Você já viu a quantidade de matéria?"

PLAYER:

"Ainda não."

ALUNO:

"Então entra também."

### Aluno dormindo

PLAYER:

"Ele tá dormindo?"

ALUNO PRÓXIMO:

"Não."

"Tá compilando."

### Aluno no computador

ALUNO:

"Meu código funcionava ontem."

PLAYER:

"E hoje?"

ALUNO:

"Hoje é outro dia."

### Professor Diogo — interação opcional

DIOGO:

"Alguma dúvida?"

PLAYER:

"Por enquanto, não."

DIOGO:

"Ótimo."

"Guarde essa sensação."

Esses diálogos podem ser encontrados livremente e não devem bloquear a missão.

---

## Cutscene de encerramento do 1º bimestre

**Fundo:** sala no final da aula, com iluminação de fim de tarde.

**Sprites:** player e seus três amigos juntos.

**Música:** tema de amizade, leve e otimista.

LIA:

"Viu? Não foi tão difícil."

PLAYER:

"Foi um pouco."

NIKO:

"Agora que você tem amigos, vai ficar tranquilo."

BIA:

"É."

"Até começarem as provas."

A música para.

PLAYER:

"...as provas?"

Aparece:

**1º BIMESTRE CONCLUÍDO**

"Você fez amigos."

"+1 AMIZADE"

"Próximo desafio: sobreviver às provas."

Fade para preto.

---

# 8. SEGUNDO BIMESTRE — PROVAS E ROTINA

## Conceito

O jogador descobriu que a escola exige estudo, organização, energia e administração de tempo.

O segundo nível terá dois sistemas principais:

1. **Gerenciamento de rotina.**
2. **Minigame de provas.**

O resultado das provas usa um sistema fictício inspirado nas menções MB, B, R e I. Não apresentar as regras numéricas do jogo como se fossem critérios oficiais da escola.

---

## Cutscene de abertura

**Fundo:** montagem rápida de relógios, cadernos, calendário, computadores e folhas de prova.

**Sprites:** player estudando, digitando, bocejando e sentado na carteira.

**Música:** batida progressivamente mais acelerada.

NARRADOR:

"Depois de algumas semanas..."

"Você descobriu uma verdade."

"A ETEC tem provas."

Pausa.

"Muitas provas."

A câmera mostra uma pilha de atividades.

PLAYER:

"Mas eu acabei de entregar um trabalho!"

LIA:

"Sim."

"Agora tem outro."

NIKO:

"Relaxa, eu também não comecei."

BIA:

"A entrega é amanhã."

NIKO:

"..."

PLAYER:

"Estamos perdidos."

Surge:

**2º BIMESTRE**

**OBJETIVO: NÃO FIQUE COM I**

---

# 9. MINIGAME — GERENCIAMENTO DE ROTINA

## Cenário

Quarto do protagonista.

Elementos:

- Cama.
- Computador.
- Mesa de estudos.
- Livros.
- Caderno.
- Celular.
- Janela.
- Relógio.
- Mochila.
- Calendário.

## Interface

HUD superior:

**DIA 1/3**

**TEMPO: 3 AÇÕES**

**ENERGIA: 70/100**

**PREPARAÇÃO: 0/100**

**ESTRESSE: 20/100**

O jogador dispõe de três dias, com três ações por dia.

Cada ação consome um período do dia.

## Ações

### Estudar

+20 preparação

-15 energia

+10 estresse

### Descansar

+25 energia

-10 estresse

### Fazer exercícios

+10 preparação

-10 energia

+5 estresse

### Conversar com amigos

+5 energia

-15 estresse

### Jogar

+15 energia

-10 estresse

Não aumenta preparação.

### Dormir cedo

Encerra o dia atual, recupera energia e reduz estresse.

Todos os valores devem ser balanceados para evitar uma estratégia única obrigatória.

## Diálogos contextuais

Ao estudar:

PLAYER:

"Se eu entender isso agora, talvez não sofra amanhã."

Ao descansar:

PLAYER:

"Cinco minutinhos..."

Ao jogar:

PLAYER:

"Só uma partida."

NARRADOR:

"Três partidas depois..."

Ao ficar com pouca energia:

PLAYER:

"Meu cérebro tá rodando a 2 FPS."

Ao atingir preparação alta:

PLAYER:

"Tá. Acho que finalmente entendi."

Ao terminar o terceiro dia:

NARRADOR:

"Chegou a hora."

"Você pode estudar o quanto quiser."

"Mas a prova sempre chega."

---

# 10. MINIGAME — A PROVA

## Cenário

Sala de aula com alunos sentados.

Professor à frente.

O player aparece sentado diante de uma folha.

A câmera aproxima a carteira e abre a interface da prova.

## HUD

**NOTA: MB**

**QUESTÃO: 1/5**

**TEMPO RESTANTE: 20s**

**PREPARAÇÃO: valor adquirido**

A preparação pode aumentar o tempo disponível ou fornecer dicas.

## Sistema de menções

Pontuação inicial: 100.

Cada erro: -20 pontos.

Tempo esgotado: -10 pontos.

Faixas fictícias do minigame:

- MB: 80–100
- B: 60–79
- R: 40–59
- I: 0–39

Se terminar com I, o jogador perde a tentativa e pode reiniciar a prova a partir do checkpoint, sem precisar repetir o jogo inteiro.

## Questões

### Questão 1 — Matemática

"Se 2x + 3 = 11, qual é o valor de x?"

[1] 3

[2] 4

[3] 7

Resposta correta: 2.

### Questão 2 — Algoritmos

"Qual estrutura executa comandos enquanto uma condição for verdadeira?"

[1] while

[2] const

[3] return

Resposta correta: 1.

### Questão 3 — Programação Web

"Qual elemento HTML cria um link?"

[1] div

[2] a

[3] span

Resposta correta: 2.

### Questão 4 — Física

"Uma força resultante atua sobre um corpo de 2 kg e produz aceleração de 3 m/s². Qual é a força?"

[1] 5 N

[2] 6 N

[3] 9 N

Resposta correta: 2.

### Questão 5 — Química

"Quantos átomos de hidrogênio existem em uma molécula de H₂O?"

[1] 1

[2] 2

[3] 3

Resposta correta: 2.

As perguntas devem ser facilmente configuráveis por arquivo de dados.

## Feedback

Resposta correta:

Som positivo discreto.

"Resposta registrada."

Resposta incorreta:

Som de erro.

A folha treme levemente.

"Você não tem tanta certeza dessa resposta..."

Tempo acabando:

Tique-taque suave e aumento de tensão musical.

## Cutscene — Resultado

### Resultado MB

PLAYER:

"EU CONSEGUI!"

LIA:

"Sabia que você ia conseguir."

BIA:

"Agora só faltam as próximas."

PLAYER:

"Não estraga o momento."

### Resultado B

PLAYER:

"Tá bom."

"Tá ótimo, na verdade."

NIKO:

"Passamos por mais uma."

### Resultado R

PLAYER:

"Isso foi por pouco."

LIA:

"Na próxima a gente estuda junto."

### Resultado I

A tela escurece.

NARRADOR:

"Você descobriu uma nova palavra."

"Recuperação."

DIOGO:

"Vamos precisar conversar sobre essa prova."

Surge:

**TENTAR NOVAMENTE**

O jogador reinicia o checkpoint da prova.

## Encerramento do 2º bimestre

NARRADOR:

"Você aprendeu a administrar seu tempo."

"Mais ou menos."

"Mas uma coisa é certa..."

"O próximo bimestre não será mais fácil."

Aparece:

**2º BIMESTRE CONCLUÍDO**

Fade para preto.

---

# 11. TERCEIRO BIMESTRE — A TENTAÇÃO DA COLA

## Conceito

O terceiro bimestre deve ser o mais tenso até agora.

O jogador está diante de uma avaliação difícil e precisa decidir como enfrentá-la.

A história deve permitir duas rotas:

- **Resolver honestamente**, usando estudo e memória.
- **Tentar colar**, enfrentando um minigame de nervosismo, suspeita e observação do professor.

A segunda rota deve apresentar riscos e consequências. Não deve ser retratada como a única forma de vencer.

---

## Cutscene de abertura

**Fundo:** sala escurecida por nuvens, relógio, quadro e carteiras.

**Sprites:** professor Diogo entregando provas, alunos tensos.

**Música:** notas graves, pulsação eletrônica discreta.

DIOGO:

"Bom dia, pessoal."

"Hoje teremos uma avaliação."

PLAYER:

"Hoje?"

NIKO:

"Hoje."

PLAYER:

"Mas ninguém avisou!"

BIA:

"Avisaram."

PLAYER:

"Quando?"

BIA:

"Na última aula."

PLAYER:

"Eu tava aqui?"

LIA:

"Fisicamente."

O professor começa a distribuir as provas.

DIOGO:

"Podem começar."

A câmera aproxima o player.

PLAYER (pensamento):

"Eu não lembro de metade disso..."

Surge:

**3º BIMESTRE**

**OBJETIVO: SOBREVIVA À AVALIAÇÃO**

---

# 12. ESCOLHA DO TERCEIRO BIMESTRE

O jogador escolhe:

**[1] Tentar resolver com o que sabe.**

**[2] Usar a cola escondida.**

## Rota 1 — Resolver honestamente

Minigame de memória e raciocínio.

Três desafios rápidos de lógica.

O jogador observa pequenas sequências, condições e resultados de algoritmos.

A cada acerto, ganha confiança.

Exemplo:

"Se x = 4 e x > 3, qual mensagem aparece?"

[1] Verdadeiro

[2] Falso

Resposta: 1.

A dificuldade cresce moderadamente.

A rota é menos arriscada, mas exige atenção.

### Diálogo final da rota

PLAYER:

"Talvez eu não soubesse tudo..."

"...mas consegui resolver."

DIOGO:

"É assim que se aprende."

---

# 13. ROTA 2 — MINIGAME DA COLA

## Cenário

Visão da carteira do protagonista, com a folha de prova e um papel pequeno escondido.

Ao fundo, o professor patrulha a sala.

## HUD

Superior esquerdo:

**QUESTÕES: 0/3**

Superior direito:

**SUSPEITA: 10/100**

Inferior:

**NERVOSISMO: 35/100**

## Controles

- Segurar C: olhar discretamente a cola.
- Soltar C: esconder a cola.
- ESPAÇO: respirar fundo, com tempo de recarga.
- Setas: selecionar respostas.

## Mecânica

Quando a cola está aberta:

- O jogador consegue visualizar pistas.
- O nervosismo aumenta.
- A suspeita pode aumentar caso o professor esteja observando.

Quando a cola está escondida:

- O nervosismo diminui gradualmente.
- A suspeita pode diminuir.
- O jogador não consegue consultar novas pistas.

O professor tem padrões de movimento e observação que devem ser comunicados visualmente.

**Nunca use uma detecção completamente aleatória e impossível de prever.**

## Parâmetros iniciais sugeridos

- Suspeita começa em 10/100.
- Nervosismo começa em 35/100.
- Cola visível: nervosismo +12 por segundo.
- Professor olhando enquanto cola visível: suspeita +20 por segundo.
- Cola escondida: suspeita -8 por segundo.
- Respiração: nervosismo -20, com recarga de 5 segundos.
- Suspeita em 100: flagrante.

Balancear após testes reais.

## Efeitos visuais

- Coração pixelado pulsa mais rápido conforme o nervosismo aumenta.
- Pequenas gotas de suor aparecem no player.
- A música aumenta de intensidade.
- Um ícone de olho indica quando o professor está olhando.
- A tela pode apresentar tremor suave nos momentos críticos.
- Não usar flashes intensos.

## Diálogos durante o minigame

PLAYER:

"Tá. Só uma olhadinha."

Quando o professor se aproxima:

PLAYER:

"Não, não, não..."

Quando consegue uma pista:

PLAYER:

"Consegui!"

Quando quase é descoberto:

PLAYER:

"Meu coração vai sair pela boca."

## Flagrante

O professor para ao lado da carteira.

A música interrompe.

DIOGO:

"Posso saber o que você está fazendo?"

PLAYER:

"..."

DIOGO:

"Guarde isso."

"Depois conversamos."

A tela apresenta:

**VOCÊ FOI DESCOBERTO**

O jogador pode voltar ao checkpoint e escolher novamente como enfrentar a prova.

## Sucesso na rota arriscada

PLAYER:

"Consegui..."

Pausa.

"...acho que perdi uns cinco anos de vida."

NARRADOR:

"Você terminou a avaliação."

"Mas talvez não tenha sido sua melhor decisão."

Guardar a escolha como uma variável narrativa, para pequenas diferenças nos diálogos finais.

---

# 14. ENCERRAMENTO DO TERCEIRO BIMESTRE

**Fundo:** corredor no fim do dia.

**Sprites:** player, Lia, Niko e Bia.

LIA:

"Finalmente acabou."

NIKO:

"Eu achei que não ia sobreviver."

BIA:

"Vocês falam isso todo bimestre."

PLAYER:

"E ainda estamos aqui."

LIA:

"Falta só mais um."

Pausa.

NIKO:

"O último costuma ser tranquilo, né?"

BIA:

"Tem o EPA."

Silêncio.

PLAYER:

"...o quê?"

A tela escurece.

**3º BIMESTRE CONCLUÍDO**

Surge uma última frase:

"Você ainda não terminou."

---

# 15. QUARTO BIMESTRE — O EPA

## Conceito

Este é o clímax narrativo.

O quarto bimestre deve ser o nível visualmente mais elaborado, emocional e cinematográfico.

O desafio final não é derrotar um inimigo.

É apresentar um projeto desenvolvido com os amigos diante de outras pessoas.

O jogo deve representar a experiência de uma feira escolar de tecnologia, com estandes, projetos, professores, avaliadores e visitantes.

O conteúdo específico do projeto apresentado deve ser configurável, para combinar com o projeto real da equipe.

---

## Cutscene Q01 — O anúncio

**Fundo:** sala de aula.

**Sprites:** professor Diogo, player e amigos.

DIOGO:

"Pessoal, estamos chegando ao final do ano."

"Agora vocês terão uma oportunidade de mostrar o que aprenderam."

"Preparem seus projetos para o EPA."

PLAYER:

"Projeto?"

NIKO:

"Projeto."

BIA:

"Apresentação."

LIA:

"Avaliadores."

PLAYER:

"...público?"

DIOGO:

"Exatamente."

PLAYER:

"Eu prefiro outra prova."

## Cutscene Q02 — Preparação

**Fundo:** laboratório de informática.

**Sprites:** os quatro amigos em computadores.

**Música:** instrumental calmo, de trabalho em equipe.

LIA:

"Precisamos terminar o projeto."

NIKO:

"Eu fiz a parte visual."

BIA:

"Eu organizei a apresentação."

PLAYER:

"E eu?"

Silêncio.

NIKO:

"Você vai explicar o sistema."

PLAYER:

"..."

BIA:

"Boa sorte."

## Mecânica de preparação

O jogador tem três tarefas:

1. Testar o projeto.
2. Revisar a apresentação.
3. Ensaiar com os amigos.

Cada tarefa consiste em uma interação curta.

### Testar o projeto

Minigame simples de encontrar um erro visual ou lógico.

Sucesso aumenta a preparação.

### Revisar a apresentação

Organizar três tópicos em ordem:

- Problema.
- Solução.
- Benefícios.

### Ensaiar

Escolher a melhor forma de apresentar uma ideia.

A preparação influencia a confiança inicial no EPA.

Não exigir desempenho perfeito para avançar.

---

# 16. CUTSCENE — DIA DO EPA

## Cena E01 — Entrada do evento

**Fundo:** entrada da escola decorada para o evento.

**Sprites:** visitantes, professores, estudantes, banners e player.

**Música:** tema de expectativa, com piano e sintetizadores.

NARRADOR:

"Meses se passaram."

"Trabalhos foram entregues."

"Provas foram feitas."

"Amizades foram construídas."

"E agora..."

"...chegou o grande dia."

## Cena E02 — Estande

**Fundo:** salão ou laboratório com estandes.

Mostrar:

- Mesas com projetos.
- Notebooks.
- Monitores.
- Banners.
- Cartazes.
- Outros grupos apresentando.
- Professores conversando.
- Visitantes observando.
- Decoração tecnológica.

A câmera se aproxima do estande do protagonista.

LIA:

"Tá tudo pronto?"

NIKO:

"O sistema tá funcionando."

BIA:

"O banner tá no lugar."

PLAYER:

"E se eu esquecer tudo?"

LIA:

"A gente te ajuda."

BIA:

"Você passou o ano inteiro aprendendo."

NIKO:

"E sobrevivendo."

PLAYER:

"...verdade."

## Cena E03 — Chegada dos avaliadores

Dois avaliadores se aproximam.

A música diminui.

AVALIADOR 1:

"Bom dia."

"Podemos conhecer o projeto de vocês?"

O player olha para os amigos.

LIA:

"Vai lá."

NIKO:

"Você consegue."

PLAYER:

"Tá."

Pausa.

"Vamos começar."

Surge:

**DESAFIO FINAL**

**APRESENTE O PROJETO**

---

# 17. MINIGAME FINAL — APRESENTAÇÃO DO EPA

## Objetivo

Concluir três etapas da apresentação mantendo controle do nervosismo e respondendo às perguntas dos avaliadores.

## HUD

Superior esquerdo:

**EPA — APRESENTAÇÃO**

Superior direito:

**ETAPA 1/3**

Inferior:

**NERVOSISMO: 35/100**

**CONFIANÇA: 65/100**

## Mecânica de nervosismo

O nervosismo aumenta durante momentos de pressão.

O jogador pode usar ESPAÇO para executar uma ação de respiração com recarga.

A respiração reduz temporariamente o nervosismo, mas não resolve automaticamente todas as dificuldades.

A confiança aumenta com respostas adequadas e preparação.

A apresentação não deve virar um minigame frustrante de apertar botões freneticamente.

A tensão precisa ser divertida e compreensível.

---

## Etapa 1 — Introdução

AVALIADOR 1:

"Qual problema o projeto de vocês procura resolver?"

O jogador escolhe:

[1] "Identificamos uma dificuldade real e desenvolvemos uma solução para ela."

[2] "A gente fez porque precisava entregar."

[3] "É complicado explicar."

A opção 1 aumenta confiança.

As outras geram uma pequena reação humorística, mas não encerram a apresentação.

### Resposta boa

AVALIADOR 1:

"Interessante. Continuem."

PLAYER (pensamento):

"Primeira parte concluída."

---

## Etapa 2 — Demonstração

A câmera mostra o notebook do projeto.

O jogador precisa executar três ações em ordem:

1. Abrir a aplicação.
2. Demonstrar a funcionalidade principal.
3. Mostrar o resultado.

Uma sequência simples de interação, com limite de tempo generoso.

Se errar:

PLAYER:

"Calma..."

"Isso funcionava ontem."

NIKO:

"Clássico."

O jogador pode corrigir o erro e continuar.

Se acertar:

AVALIADOR 2:

"Entendi. Muito bom."

---

## Etapa 3 — Perguntas

### Pergunta 1

AVALIADOR 2:

"Quem pode se beneficiar dessa solução?"

Opções:

[1] "As pessoas que enfrentam o problema que identificamos."

[2] "Só os desenvolvedores."

[3] "Não pensamos nisso."

Resposta 1 é a melhor.

### Pergunta 2

AVALIADOR 1:

"Qual foi a maior dificuldade no desenvolvimento?"

Opções:

[1] "Integrar as funcionalidades e resolver problemas durante os testes."

[2] "Escolher a cor do botão."

[3] "Nenhuma. Foi tudo perfeito."

Resposta 1 é a melhor.

### Pergunta 3

AVALIADOR 2:

"O que vocês melhorariam em uma próxima versão?"

Opções:

[1] "Faríamos mais testes e adicionaríamos funcionalidades com base no retorno dos usuários."

[2] "Nada. O sistema é perfeito."

[3] "Talvez mudar o nome."

Resposta 1 é a melhor.

## Clímax

Após a terceira pergunta:

A música diminui.

A câmera aproxima o player.

O coração pulsa.

PLAYER (pensamento):

"Acabou?"

O avaliador olha suas anotações.

Pausa de dois segundos.

AVALIADOR 1:

"Obrigado pela apresentação."

AVALIADOR 2:

"Parabéns pelo trabalho."

A música de tensão termina.

Surge um tema suave de vitória.

O player olha para os amigos.

LIA:

"Conseguimos."

NIKO:

"Eu falei."

BIA:

"Você tava tremendo."

PLAYER:

"Eu sei."

Todos riem.

---

# 18. CUTSCENE FINAL — O FIM DO PRIMEIRO ANO

Esta deve ser a cena mais emocional do jogo.

## Ambiente

Corredor da escola ao entardecer.

Luz alaranjada entrando pelas janelas.

Salas quase vazias.

Sons distantes de estudantes indo embora.

O player caminha lentamente com os amigos.

**Música:** piano suave, sintetizador nostálgico e notas longas.

## Diálogos

NIKO:

"Então..."

"Acabou?"

BIA:

"Parece que sim."

LIA:

"Foi um ano estranho."

PLAYER:

"Foi."

LIA:

"A gente nem se conhecia."

NIKO:

"E agora sobrevivemos a tudo isso."

BIA:

"Mais ou menos."

PLAYER:

"É engraçado..."

"No primeiro dia eu só queria encontrar alguém pra conversar."

"Depois vieram as provas."

"As noites estudando."

"Os trabalhos."

"E agora a gente acabou de apresentar um projeto."

LIA:

"Você mudou bastante."

PLAYER:

"Vocês também."

O grupo para diante da saída.

NIKO:

"Será que o próximo ano vai ser mais fácil?"

BIA:

"Não."

Pausa.

Todos riem.

LIA:

"Mas pelo menos não vamos estar sozinhos."

O player olha para a escola uma última vez.

PLAYER:

"É."

"Isso já ajuda bastante."

## Última cena

A câmera se afasta lentamente.

Os quatro personagens saem pelo portão.

O céu está alaranjado.

A música chega ao seu ponto mais emocionante.

A tela escurece.

Surge, letra por letra:

**FIM.**

Pausa.

**NÃO SABEMOS O QUE ACONTECERÁ DAQUI PARA FRENTE.**

Pausa.

**MAS SOBREVIVEMOS ATÉ AQUI.**

Uma última linha aparece:

**OBRIGADO POR JOGAR SURVIVE AT ETEC.**

---

# 19. TELA DE FECHAMENTO

Depois da cutscene, mostrar uma tela final própria, não simplesmente uma tela preta.

## Visual

Fundo pixel art da escola à noite.

Janelas iluminadas.

Estrelas discretas.

Os quatro amigos aparecem de costas olhando para a escola.

Título:

**SURVIVE AT ETEC**

Subtítulo:

**FIM DO PRIMEIRO ANO**

## Opções

- CONHECER NOSSO PROJETO
- JOGAR NOVAMENTE
- CRÉDITOS

A primeira opção deve levar ao restante do site do EPA.

Ao selecioná-la:

1. Executar fade-out.
2. Parar ou reduzir os sons do jogo.
3. Destruir ou ocultar adequadamente a instância do Phaser.
4. Exibir o conteúdo principal do site.
5. Restaurar rolagem e layout da página.
6. Garantir que o jogo não continue capturando o teclado.

A opção JOGAR NOVAMENTE reinicia a campanha.

A opção CRÉDITOS abre uma tela com os participantes do projeto.

Não inventar nomes reais da equipe. Criar campos configuráveis para os créditos.

## Créditos

Categorias:

- Desenvolvimento.
- Programação.
- Roteiro.
- Arte e animação.
- Design de som.
- Orientação.
- Agradecimentos.

Finalizar com:

"Feito por estudantes que ainda estão tentando sobreviver à ETEC."

---

# 20. SISTEMA COMPLETO DE MÚSICA

Todas as músicas devem ser originais ou utilizar recursos com licença apropriada.

Não utilizar melodias extraídas de Undertale, Stardew Valley ou outros jogos.

Criar as seguintes faixas ou especificações de composição:

| Arquivo | BPM | Estilo e instrumentos | Uso |
|---|---:|---|---|
| `bgm-prologo.ogg` | 68 | Piano minimalista, pad ambiente, notas espaçadas | Prólogo |
| `bgm-menu.ogg` | 102 | Chiptune melódico, baixo eletrônico, bateria leve | Menu |
| `bgm-primeiro-dia.ogg` | 90 | Piano elétrico, percussão leve, sintetizador alegre | Caminho da escola |
| `bgm-sala.ogg` | 94 | Lo-fi/chiptune escolar, baixo suave, teclado | Exploração |
| `bgm-amizade.ogg` | 106 | Melodia otimista, piano, arpejos 8-bit | Grupo aceita |
| `bgm-rotina.ogg` | 112 | Batida repetitiva, synth e relógio percussivo | Gerenciamento |
| `bgm-prova.ogg` | 126 | Pulso eletrônico, baixo tenso, notas curtas | Prova |
| `bgm-suspense.ogg` | 118 | Sintetizadores graves, percussão espaçada | Terceiro bimestre |
| `bgm-cola.ogg` | 138 | Batimento, baixo pulsante, notas tensas | Minigame da cola |
| `bgm-preparacao.ogg` | 96 | Piano, sintetizador suave, clima de colaboração | Preparação EPA |
| `bgm-epa.ogg` | 124 | Eletrônico cinematográfico, progressão ascendente | Apresentação |
| `bgm-final.ogg` | 72 | Piano nostálgico, pad quente, melodia delicada | Encerramento |

## Regras de áudio

- Músicas de exploração devem funcionar em loop sem cortes perceptíveis.
- Usar crossfade ou fade-out/fade-in entre cenas.
- Música padrão aproximadamente 25–35% do volume máximo.
- Efeitos sonoros com volume moderado.
- Sons de diálogo discretos, sem repetição agressiva.
- Reduzir a música durante falas importantes.
- Não tocar várias músicas de fundo simultaneamente.
- Respeitar as restrições de autoplay dos navegadores: ativar áudio após interação válida do jogador.
- Disponibilizar opções separadas de volume de música e efeitos.

## Sons necessários

- `dialogo-blip.wav`: digitação de texto.
- `dialogo-professor.wav`: variante mais grave.
- `dialogo-narrador.wav`: variante suave.
- `menu-mover.wav`: navegar no menu.
- `menu-confirmar.wav`: confirmar.
- `menu-voltar.wav`: voltar.
- `passos.wav`: caminhada, sem tocar excessivamente.
- `porta.wav`: abrir porta.
- `sinal-escola.wav`: sinal escolar.
- `ambiente-sala.wav`: conversas ambientais discretas.
- `acerto.wav`: resposta correta.
- `erro.wav`: resposta incorreta.
- `rejeicao.wav`: grupo rejeita.
- `amizade.wav`: grupo aceita.
- `relogio.wav`: contagem regressiva.
- `coracao.wav`: batimento.
- `alerta.wav`: professor percebe algo.
- `papel.wav`: manusear prova.
- `teclado.wav`: digitação no computador.
- `sucesso.wav`: concluir objetivo.
- `game-over.wav`: falha.
- `transicao.wav`: mudança de bimestre.
- `aplausos.wav`: final da apresentação.

Criar um sistema central de áudio que gerencie música, efeitos, volumes e transições.

---

# 21. SISTEMA DE DIÁLOGO

Criar uma classe reutilizável, por exemplo `DialogueBox`.

## Visual

- Caixa preta com borda clara.
- Posição inferior da tela.
- Texto branco em fonte pixelada legível.
- Nome do personagem.
- Retrato opcional do personagem.
- Pequena seta animada indicando que pode continuar.
- Fundo da caixa com transparência mínima para boa leitura.

## Funcionamento

- Texto digitado letra por letra.
- Velocidade configurável.
- Som discreto de digitação.
- ENTER completa imediatamente a frase atual.
- ENTER novamente avança.
- Não permitir que uma única tecla avance várias falas acidentalmente.
- Pausar movimento durante diálogos.
- Suportar escolhas com setas ou números.
- Suportar retratos e expressões diferentes.
- Permitir eventos disparados no final de uma fala.
- Permitir diálogos condicionais com base nas decisões do jogador.
- Possibilitar histórico de diálogo e opção de pular texto já visto.

O sistema deve ser utilizado em todas as cutscenes e conversas.

---

# 22. HUD GERAL

O HUD deve ser consistente em todos os níveis.

## Elementos fixos

- Indicador do bimestre.
- Objetivo atual.
- Pequena instrução de controle quando necessária.
- Feedback visual de conclusão.

## Primeiro bimestre

Grupos conhecidos e amizade.

## Segundo bimestre

Energia, preparação, estresse, tempo e menção.

## Terceiro bimestre

Suspeita, nervosismo e progresso da avaliação.

## Quarto bimestre

Confiança, nervosismo e etapas da apresentação.

## Direção visual

HUD pixel art com bordas finas, cantos discretamente arredondados quando fizer sentido, sombras leves e cores de estado.

Não cobrir a visão do personagem nem os elementos importantes dos minigames.

Animações de HUD devem ser curtas e legíveis.

---

# 23. PERSONAGENS E SPRITES

Produzir ou preparar os seguintes grupos de assets.

## Protagonista

Preservar `player.png` atual.

Criar um spritesheet adicional `player-acoes.png` com:

- Sentado.
- Escrevendo.
- Estudando.
- Mexendo no celular.
- Nervoso.
- Assustado.
- Dormindo.
- Correndo.
- Escondendo cola.
- Apresentando.
- Comemorando.
- Olhando para os amigos.

## Professor Diogo

Criar:

- `professor-diogo.png`
- `diogo-explicando.png`
- `diogo-quadro.png`
- `diogo-andando.png`
- `diogo-desconfiado.png`
- `diogo-retrato.png`

Visual: professor adulto, cabelo curto escuro, roupa de professor de programação, crachá opcional, estilo pixel art consistente.

Se houver uma imagem de referência fornecida, usá-la apenas para orientar o visual do personagem.

## Amigos principais

Criar personagens individuais:

**Lia:** expressiva, acolhedora, roupas criativas, mochila personalizada.

**Niko:** interessado em tecnologia e jogos, aparência descontraída, acessórios digitais.

**Bia:** irônica, observadora, estilo alternativo, cabelo e roupas distintos.

Criar sprites de corpo inteiro, retratos e expressões.

## Grupos do primeiro bimestre

- `grupo-tryhards.png`
- `grupo-jogadores.png`
- `grupo-misteriosos.png`
- `grupo-amigos.png`

Cada um deve representar três ou quatro estudantes juntos.

## NPCs ambientais

- Aluno dormindo.
- Aluno escondido debaixo da mesa.
- Aluno no computador.
- Aluno no celular.
- Aluno conversando.
- Aluno andando pelo corredor.
- Aluno atrasado.
- Colegas fazendo prova.
- Professores genéricos.
- Avaliadores.
- Visitantes do EPA.

## Efeitos visuais

- Suor.
- Interrogação.
- Exclamação.
- Zzz.
- Coração.
- Estrelas de sucesso.
- Poeira de passos.
- Impacto de erro.
- Indicador de interação.
- Indicador de suspeita.
- Pulsação do coração.

Sprites de personagens devem preferencialmente possuir fundo transparente e dimensões consistentes.

---

# 24. CENÁRIOS E TILESETS

Criar ou preparar os seguintes ambientes:

1. Quarto do protagonista.
2. Rua em frente à escola.
3. Fachada e portão da ETEC.
4. Corredor escolar.
5. Sala de aula principal.
6. Laboratório de informática.
7. Sala durante avaliação.
8. Ambiente de preparação do EPA.
9. Salão/estandes do EPA.
10. Exterior da escola ao entardecer.
11. Exterior da escola à noite, para a tela final.

Reutilizar mapas quando possível, mudando iluminação, decoração, NPCs e atmosfera.

## Tilesets

- `sala-tiles.png`
- `corredor-tiles.png`
- `exterior-tiles.png`
- `quarto-tiles.png`
- `laboratorio-tiles.png`
- `epa-tiles.png`

## Objetos necessários

- Pisos.
- Paredes.
- Portas.
- Janelas.
- Quadros.
- Projetores.
- Carteiras.
- Cadeiras.
- Mesa do professor.
- Computadores.
- Monitores.
- Teclados.
- Armários.
- Estantes.
- Lixeiras.
- Mochilas.
- Livros.
- Cadernos.
- Relógios.
- Murais.
- Cartazes.
- Plantas.
- Bebedouros.
- Bancos.
- Mesas do EPA.
- Banners.
- Notebooks.
- Microfones.
- Cabos.
- Decorações tecnológicas.

---

# 25. TILED — MAPAS E COLISÕES

Usar Tiled com mapas ortogonais.

Preferência inicial:

- Tiles de 32 × 32 pixels.
- Mapas maiores que a viewport.
- Câmera seguindo o player.
- Colisões físicas com paredes e objetos.
- Interações baseadas em proximidade.

## Camadas sugeridas

**Piso:** chão e variações.

**Paredes:** estrutura da sala.

**MobiliarioAtras:** objetos que devem ficar atrás do jogador.

**MobiliarioFrente:** objetos que podem aparecer à frente do jogador.

**Decoracao:** elementos visuais.

**Colisoes:** camada de objetos com retângulos de colisão.

**Spawns:** pontos de entrada de personagens.

**Interacoes:** NPCs e objetos interativos.

**Gatilhos:** portas, mudanças de cena e eventos.

## Propriedades

Objetos de colisão podem usar `collides = true`.

Pontos de interação podem usar `interactionId`.

Gatilhos podem usar `targetScene`.

Pontos de spawn podem usar `spawnId`.

O código deve interpretar essas propriedades corretamente.

**Atenção:** uma camada de objetos do Tiled não é automaticamente equivalente a uma camada de tiles colidíveis. Implementar as colisões dos retângulos de objetos por meio de corpos estáticos do Arcade Physics. Para camadas de tiles, usar os métodos próprios de colisão do Phaser.

Não inventar coordenadas de mesas ou paredes sem consultar o mapa real.

Não usar uma imagem gigante com personagens incorporados como substituta de um mapa interativo.

---

# 26. CONTROLES

| Tecla | Ação |
|---|---|
| W / ↑ | Mover para cima |
| A / ← | Mover para esquerda |
| S / ↓ | Mover para baixo |
| D / → | Mover para direita |
| E | Interagir |
| ENTER | Confirmar/avançar diálogo |
| ESC | Pausar/voltar |
| 1, 2, 3 | Escolhas rápidas |
| ESPAÇO | Ação contextual de minigame |
| C | Consultar/esconder cola no 3º bimestre |

Controles específicos devem aparecer antes de cada minigame.

Evitar conflitos entre movimentação, diálogo e menus.

---

# 27. PAUSA, OPÇÕES E ACESSIBILIDADE

Criar menu de pausa com:

- Continuar.
- Reiniciar checkpoint.
- Volume da música.
- Volume dos efeitos.
- Velocidade do texto.
- Reduzir tremor de tela.
- Voltar ao menu.

As configurações devem ser preservadas localmente.

Implementar legendas e indicadores visuais para informações importantes transmitidas por som.

Não depender exclusivamente de cores para indicar erro ou sucesso.

Permitir pular cutscenes já vistas.

Evitar flashes intensos e movimentos excessivos de câmera.

---

# 28. SISTEMA DE PROGRESSO

Criar estado global do jogo com:

- Bimestre atual.
- Objetivos concluídos.
- Grupos conhecidos.
- Amizade conquistada.
- Desempenho do segundo bimestre.
- Rota escolhida no terceiro bimestre.
- Preparação para o EPA.
- Desempenho da apresentação.
- Cutscenes já assistidas.

Usar armazenamento local do navegador para checkpoints.

Não reiniciar o jogo inteiro quando o jogador falhar em um minigame.

O menu CONTINUAR deve restaurar o checkpoint válido.

---

# 29. ESTRUTURA DE ARQUIVOS

Preservar, sempre que possível, a estrutura existente:

- `Assets/`
- `Css/`
- `Javascript/`
- `Javascript/Scenes/`
- `index.html`

Organização sugerida:

**Javascript**

- `main.js`: configuração e inicialização.
- `Player.js`: movimento, animações e hitbox.
- `dialogo.js`: caixa de diálogo.
- `AudioManager.js`: música e efeitos.
- `HUD.js`: interface compartilhada.
- `SaveManager.js`: progresso.
- `GameState.js`: estado narrativo.
- `AssetLoader.js`: carregamento de assets.

**Javascript/Scenes**

- `Boot.js`
- `Preload.js`
- `Prologo.js`
- `Titulo.js`
- `CutsceneInicio.js`
- `Bimestre1.js`
- `TransicaoBimestre.js`
- `Bimestre2.js`
- `Bimestre3.js`
- `CutsceneEPA.js`
- `Bimestre4.js`
- `Final.js`
- `Creditos.js`

**Javascript/data**

- `dialogos.js`
- `questoes.js`
- `personagens.js`
- `configJogo.js`

O arquivo `main.js` não deve concentrar milhares de linhas de lógica.

Cada sistema deve ter uma responsabilidade clara.

---

# 30. QUALIDADE DA PROGRAMAÇÃO

Requisitos obrigatórios:

- Código JavaScript organizado e legível.
- Sem variáveis globais desnecessárias.
- Sem referências a classes antes do carregamento.
- Ordem correta dos scripts no HTML.
- Sem caminhos quebrados.
- Sem animações duplicadas.
- Sem listeners acumulados ao reiniciar cenas.
- Sem timers que continuam rodando após o fim da cena.
- Sem sons sobrepostos indevidamente.
- Sem atravessar paredes, mesas ou armários.
- Sem personagem desproporcional ao cenário.
- Sem NPCs bloqueando permanentemente passagens.
- Sem HUD acompanhando a câmera incorretamente.
- Sem diálogos avançando duas vezes com um único ENTER.
- Sem softlocks em minigames.
- Sem dependência de arquivos inexistentes.

Se algum asset ainda não existir, usar um placeholder funcional e claramente identificado, sem quebrar o jogo.

---

# 31. POLIMENTO E DETALHES ESPECIAIS

Adicionar detalhes ambientais para que a escola pareça viva.

Exemplos:

- Relógio funcionando.
- Alunos piscando.
- Ventilador girando.
- Computador com monitor animado.
- Folhas em cima de carteiras.
- Som ambiente de sala.
- Estudantes conversando.
- Professor escrevendo no quadro.
- Pequenos movimentos dos grupos.
- Aluno escondido debaixo da mesa.
- Aluno dormindo.
- Comentários opcionais ao interagir com objetos.
- Pequenos segredos e piadas.
- Alteração da iluminação ao longo da história.

Adicionar transições cinematográficas curtas, mas sem prejudicar o ritmo.

O jogo deve ter personalidade, não apenas cumprir uma lista de funcionalidades.

---

# 32. CRITÉRIOS DE CONCLUSÃO

O jogo só estará completo quando:

1. O prólogo funcionar com texto digitado e áudio.
2. O menu principal funcionar com música, opções e transições.
3. A cutscene inicial mostrar o player chegando à escola.
4. O primeiro bimestre permitir exploração e diálogo com os quatro grupos.
5. As colisões da sala funcionarem corretamente.
6. Os amigos conquistados aparecerem nos bimestres seguintes.
7. O segundo bimestre possuir gerenciamento de rotina e prova funcional.
8. As menções MB/B/R/I funcionarem.
9. O terceiro bimestre possuir as duas rotas e o minigame de suspeita.
10. O quarto bimestre possuir preparação e apresentação do EPA.
11. O minigame final apresentar perguntas e consequências.
12. Todas as cutscenes principais possuírem fundo, sprites, música e diálogos.
13. O jogo possuir telas de conclusão e transições entre os quatro bimestres.
14. O encerramento mostrar a mensagem final planejada.
15. A tela de fechamento possuir créditos, rejogar e conhecer o projeto.
16. A opção de conhecer o projeto revelar corretamente o restante do site.
17. O progresso puder ser salvo e retomado.
18. O jogo funcionar no navegador sem erros críticos.
19. Os sprites e cenários possuírem estilo visual consistente.
20. O jogador conseguir terminar a campanha inteira.

---

# 33. COMO VOCÊ DEVE TRABALHAR COMIGO

Quero que você atue como um desenvolvedor responsável pelo projeto inteiro.

**Primeiro:** examine os arquivos reais que eu enviar. Entenda o que já está funcionando antes de modificar qualquer coisa.

**Segundo:** preserve o player existente e os recursos funcionais.

**Terceiro:** identifique quais assets já existem, quais precisam ser ajustados e quais precisam ser criados.

**Quarto:** organize a arquitetura completa do projeto.

**Quinto:** implemente as cenas, diálogos, mapas, minigames, áudio, HUD e encerramento.

**Sexto:** teste os fluxos, identifique erros e corrija problemas de integração.

**Sétimo:** entregue os arquivos completos e indique exatamente em quais pastas devem ficar.

Não quero respostas do tipo "adicione este pequeno trecho em algum lugar" sem contexto.

Quando entregar código, forneça o arquivo inteiro ou uma alteração claramente localizada.

Não afirme ter criado, renderizado ou testado arquivos que você não conseguiu efetivamente produzir ou executar.

Se não puder gerar diretamente um PNG, áudio ou mapa, forneça uma especificação exata, utilizável, com dimensões, frames, transparência, posições, camadas e nomes dos arquivos.

Se tiver ferramentas de edição e execução, utilize-as para criar e verificar os arquivos.

Se o projeto for grande demais para uma única entrega, divida a implementação em etapas completas e jogáveis, mantendo esta especificação como referência permanente.

**Não simplifique a história eliminando os quatro bimestres, os amigos, o professor Diogo, a cutscene inicial, o sistema de diálogo ou o EPA.**

---

# 34. RESULTADO QUE ESPERO

Quero que Survive at ETEC pareça um verdadeiro jogo indie de pixel art.

O jogador deve:

- Sorrir com os diálogos.
- Se identificar com a vida escolar.
- Gostar dos personagens.
- Sentir a pressão das provas.
- Ficar tenso durante o terceiro bimestre.
- Sentir nervosismo e satisfação durante o EPA.
- Gostar do encerramento.
- Ter vontade de mostrar o jogo a outra pessoa.

O jogo deve começar de forma engraçada, ficar progressivamente mais intenso e terminar com uma mensagem simples sobre aprendizado, amizade e crescimento.

A mensagem central é:

**Entrar na ETEC foi uma conquista. Sobreviver ao ano foi uma experiência. E o mais importante foram as pessoas e as coisas que aprendemos no caminho.**

Agora utilize este documento para desenvolver **SURVIVE AT ETEC**, respeitando a identidade visual, o roteiro, as mecânicas e os requisitos técnicos, e transforme o projeto existente em um jogo completo, funcional e apresentável.
