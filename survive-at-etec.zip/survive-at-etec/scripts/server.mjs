import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { resolve, extname, relative } from "node:path";
import { fileURLToPath } from "node:url";
const root = fileURLToPath(
  new URL(process.env.SERVE_DIST === "1" ? "../dist/" : "../", import.meta.url),
);
const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".png": "image/png",
  ".ogg": "audio/ogg",
  ".wav": "audio/wav",
  ".md": "text/plain; charset=utf-8",
};
createServer(async (req, res) => {
  try {
    const path = resolve(
      root,
      "." +
        decodeURIComponent(
          new URL(req.url, "http://local").pathname === "/"
            ? "/index.html"
            : new URL(req.url, "http://local").pathname,
        ),
    );
    if (
      relative(root, path).startsWith("..") ||
      relative(root, path)
        .split("/")
        .some((x) => x.startsWith("."))
    ) {
      res.writeHead(403).end();
      return;
    }
    const body = await readFile(path);
    res.setHeader(
      "Content-Type",
      types[extname(path)] || "application/octet-stream",
    );
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.end(body);
  } catch {
    res.writeHead(404).end("Arquivo não encontrado");
  }
}).listen(Number(process.env.PORT) || 4173, "0.0.0.0", () =>
  console.log("Survive at ETEC — porta " + (process.env.PORT || 4173)),
);
