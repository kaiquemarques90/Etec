"""Original pixel assets, Tiled maps and synthesized audio; no external art."""
from PIL import Image, ImageDraw
from pathlib import Path
import json, math, wave, struct, subprocess, random
ROOT=Path(__file__).resolve().parents[1]; A=ROOT/'Assets'; random.seed(44)
P={'ink':'#11151f','navy':'#1c2231','cream':'#e7d6b8','wood':'#a77d58','blue':'#4d739c','red':'#ad4251','purple':'#6c5b7b','gold':'#f2cb78','white':'#f2f2f2'}
characters={'player':('#4d739c','#382d30','#dfa979'),'lia':('#b66f8d','#663d32','#dba177'),'niko':('#6a988f','#292e40','#cb9874'),'bia':('#6c5b7b','#c19c75','#e5b38b'),'professor-diogo':('#d3dfdc','#302b32','#c8916e'),'tryhard':('#698bb2','#654938','#e0b08c'),'jogador':('#c7954f','#282735','#c8916e'),'misterioso':('#3e4255','#282431','#d2a38c'),'aluno':('#679094','#644436','#bd825e'),'avaliador':('#7a8398','#725340','#d0a080')}
def character(colors,direction=0,step=0,pose=0):
 im=Image.new('RGBA',(32,32)); d=ImageDraw.Draw(im); shirt,hair,skin=colors; off=1 if step==1 else 0
 def r(box,c): d.rectangle((box[0],box[1]+off,box[2],box[3]+off),fill=c)
 d.ellipse((7,27,25,30),fill=(12,17,27,60))
 r((11,22,14,28-step%2),P['ink']);r((18,22,21,28-(step+1)%2),P['ink']);r((10,27-step%2,14,29-step%2),'#4a4250');r((18,27-(step+1)%2,23,29-(step+1)%2),'#4a4250')
 r((9,14,23,22),P['ink']);r((10,14,22,21),shirt);r((11,15,12,20),'#ffffff40');r((8,15,10,20),shirt);r((22,15,24,20),shirt);r((8,20,10,22),skin);r((22,20,24,22),skin)
 r((10,3,22,13),P['ink']);r((11,4,21,12),skin);r((12,13,20,14),skin);r((10,2,21,6),hair);r((9,4,11,9),hair);r((20,3,23,8),hair);r((12,2,17,3),'#8a6a58')
 if direction==3: r((10,4,22,12),hair);r((11,16,21,22),'#273749');r((12,17,20,20),'#354e63')
 elif direction==1: r((10,8,11,9),P['ink']);r((9,10,10,11),skin);r((17,5,22,12),hair)
 elif direction==2: r((21,8,22,9),P['ink']);r((22,10,23,11),skin);r((10,5,15,12),hair)
 else:
  r((12,8,13,9),P['ink']);r((19,8,20,9),P['ink']);r((15,11,17,11),'#9a5e4b');r((12,7,14,7),hair);r((18,7,20,7),hair)
 if pose in (0,1,2): pass
 if pose in (3,4): r((20,17,24,22),P['ink']);r((21,18,23,20),'#8ebad0')
 if pose==5: r((14,10,18,12),P['ink'])
 if pose==6: r((8,11,24,15),P['cream'])
 if pose==8: r((18,18,24,21),P['cream'])
 if pose in (9,10): r((5,11,9,16),shirt);r((4,9,7,12),skin);r((23,10,26,15),shirt);r((25,8,27,11),skin)
 return im
for name,colors in characters.items():
 sheet=Image.new('RGBA',(288,384))
 for direction in range(4):
  for step in range(3): sheet.paste(character(colors,direction,step).resize((96,96),Image.Resampling.NEAREST),(step*96,direction*96))
 target=A/'sprites'/f'{name}.png'
 if name!='player' or not target.exists(): sheet.save(target)
 face=character(colors).crop((7,0,26,16)).resize((76,64),Image.Resampling.NEAREST);face.save(A/'sprites'/f'{name}-retrato.png')
 expressions=Image.new('RGBA',(76*3,64));
 for i in range(3): expressions.paste(character(colors,0,i,5 if i==2 else 0).crop((7,0,26,16)).resize((76,64),Image.Resampling.NEAREST),(i*76,0))
 expressions.save(A/'sprites'/f'{name}-expressoes.png')
poses=Image.new('RGBA',(288,384))
for i in range(12): poses.paste(character(characters['player'],0,i%3,i).resize((96,96),Image.Resampling.NEAREST),((i%3)*96,(i//3)*96))
poses.save(A/'sprites'/'player-acoes.png')
for name in ['diogo-explicando','diogo-quadro','diogo-andando','diogo-desconfiado']:
 sheet=Image.new('RGBA',(288,96))
 for i in range(3): sheet.paste(character(characters['professor-diogo'],3 if 'quadro' in name else 0,i,9 if 'explicando' in name else 0).resize((96,96),Image.Resampling.NEAREST),(i*96,0))
 sheet.save(A/'sprites'/f'{name}.png')
for group,names in {'tryhards':['tryhard']*3,'jogadores':['jogador']*3,'misteriosos':['misterioso']*3,'amigos':['lia','niko','bia']}.items():
 im=Image.new('RGBA',(96,48))
 for i,n in enumerate(names):im.paste(character(characters[n],0,i), (i*28+4,8+(i%2)*5),character(characters[n],0,i))
 im.save(A/'sprites'/f'grupo-{group}.png')
for name,pose in [('dormindo',6),('escondido',8),('computador',3),('celular',3),('conversando',0),('corredor',0),('atrasado',10),('prova',1),('professor',9),('visitante',0)]:
 character(characters['aluno'],0,0,pose).resize((96,96),Image.Resampling.NEAREST).save(A/'sprites'/f'npc-{name}.png')
effects=Image.new('RGBA',(16*11,16)); d=ImageDraw.Draw(effects)
for i,symbol in enumerate(['!','?','z','<3','*','..','X','E','!','~','+']):d.text((i*16+4,2),symbol,fill=P['gold'])
effects.save(A/'sprites'/'efeitos.png')
# Tiles, hand-drawn with flat pixel shapes, shade accents and worn surfaces.
tiles=Image.new('RGBA',(256,128))
for i in range(32):
 im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im);r=d.rectangle;l=d.line
 if i in [0,1,2]:
  color=['#cdbfa8','#d8cbb4','#b8ad9b'][i];r((0,0,31,31),fill=color);l((0,31,31,31),fill='#a79b8b');l((31,0,31,31),fill='#a79b8b');l((2,2,29,2),fill='#dfd3bd');r((7,11,8,11),fill='#b5a790')
 elif i==3:
  r((0,0,31,31),fill='#e7d6b8');r((0,24,31,31),fill='#897d75');l((0,24,31,24),fill='#f3e4cc');l((0,31,31,31),fill='#534e50')
 elif i==4:
  r((0,0,31,31),fill='#645450');r((3,2,28,31),fill='#a77d58');r((6,4,25,19),fill='#536a7a');r((7,5,24,18),fill='#7195a4');r((24,24,26,25),fill=P['gold']);r((4,30,28,31),fill='#413d43')
 elif i==5:
  r((2,5,30,29),fill='#a39683');r((4,20,6,30),fill='#484654');r((25,20,27,30),fill='#484654');r((1,3,30,22),fill='#493e3c');r((2,3,29,18),fill='#bb9066');l((3,4,28,4),fill='#e1b383');r((8,6,18,13),fill='#e9dfc6');l((10,8,16,8),fill='#8a94a0');r((23,6,25,12),fill='#516e90')
 elif i==6:
  r((8,3,24,24),fill='#343f50');r((9,4,23,15),fill='#4d739c');r((10,5,22,8),fill='#6999bb');r((7,18,25,23),fill='#4d739c');r((8,24,10,30),fill='#404551');r((22,24,24,30),fill='#404551')
 elif i==7:
  r((1,8,30,27),fill='#55464a');r((2,9,29,23),fill='#a77d58');r((6,1,25,17),fill='#1c2231');r((8,3,23,14),fill='#294d59');l((10,5,19,5),fill='#81cfb0');l((10,8,21,8),fill='#f2cb78');l((10,11,17,11),fill='#81cfb0');r((5,20,23,23),fill='#c2bbb0');r((7,21,20,21),fill='#534f5e')
 elif i==8:
  r((3,3,28,29),fill='#8b735b');r((4,4,27,27),fill='#405854');l((6,6,21,6),fill='#ccdac0');l((6,10,25,10),fill='#aab9aa');l((6,14,19,14),fill='#aab9aa');r((8,25,19,26),fill='#e5daca')
 elif i==9:
  r((1,1,30,30),fill='#6d7f8f');r((3,3,28,27),fill='#91b1c5');r((5,4,13,23),fill='#bcd3db');r((16,4,25,23),fill='#a4c6cf');r((14,1,16,27),fill='#e1d5bf');r((1,27,30,30),fill='#f0dfc4')
 elif i==10:
  r((9,20,23,29),fill='#98654d');r((8,19,24,22),fill='#bb8763');r((15,6,17,19),fill='#3d654b');d.ellipse((3,5,17,18),fill='#528b63');d.ellipse((12,1,27,14),fill='#629a6b');r((15,4,18,8),fill='#85af76')
 elif i==11:
  r((3,1,28,30),fill='#464f61');r((4,2,15,29),fill='#5b7082');r((17,2,27,29),fill='#526879');r((12,13,13,16),fill=P['cream']);r((24,13,25,16),fill=P['cream']);l((6,6,12,6),fill='#354457');l((19,6,25,6),fill='#354457')
 elif i==12:
  r((3,2,28,29),fill='#5d4a47');r((5,4,26,27),fill='#ad8761');r((7,7,15,16),fill='#e5d7bb');r((18,6,24,12),fill='#b5c9c6');r((17,16,24,24),fill='#f2cb78');l((9,10,13,10),fill='#8b8790')
 elif i==13:
  r((0,0,31,31),fill='#59815a');
  for j in range(12):x=random.randrange(30);y=random.randrange(30);r((x,y,x+1,y+2),fill=random.choice(['#759b69','#4c7050','#8fab71']))
 elif i==14:
  r((0,0,31,31),fill='#b6a99c');l((0,30,31,30),fill='#8c847f');l((30,0,30,31),fill='#8c847f');l((2,2,29,2),fill='#d0c4b2')
 elif i==15:
  r((0,0,31,31),fill='#424957');l((0,28,31,28),fill='#535867');r((0,13,18,15),fill='#dfc78e')
 elif i==16:
  r((12,16,19,31),fill='#70533f');d.ellipse((1,1,30,26),fill='#3b654b');d.ellipse((3,0,26,19),fill='#56865e');r((9,5,18,7),fill='#77a06a')
 elif i==17:
  r((1,9,30,24),fill='#474153');r((2,8,29,14),fill='#b08b62');r((3,19,28,22),fill='#98704d');r((5,24,7,29),fill='#484351');r((25,24,27,29),fill='#484351')
 elif i==18:
  r((0,0,31,31),fill='#77666d');r((0,1,31,2),fill='#998087');r((0,27,31,29),fill='#513f52')
 elif i==19:
  r((0,0,31,31),fill='#47566c');r((2,2,29,29),fill='#5f6d84');r((4,4,27,27),fill='#495873');r((8,8,23,23),fill='#6c5b7b')
 elif i==20:
  r((2,5,30,29),fill='#5b3d51');r((3,4,29,12),fill='#8e6380');r((4,13,28,26),fill='#c29aab');r((6,6,26,10),fill='#e7d6b8');l((8,16,25,16),fill='#d9bec7');r((3,28,5,31),fill='#3c3646');r((26,28,28,31),fill='#3c3646')
 elif i==21:
  r((2,5,29,29),fill='#b0825a');r((3,6,28,10),fill='#d9b88d');r((6,12,12,22),fill='#4d739c');r((14,12,19,22),fill='#ad4251');r((21,12,26,22),fill='#f2cb78');r((5,23,27,25),fill='#d9b88d')
 elif i==22:
  d.ellipse((5,3,26,25),fill='#3a3845');d.ellipse((7,5,24,23),fill='#f2e5c9');l((16,8,16,14,21,14),fill='#484451',width=2)
 elif i==23:
  r((6,4,26,29),fill='#4c6976');r((7,5,25,10),fill='#9fc6cb');r((9,13,23,16),fill='#d8d5c5');r((8,20,24,28),fill='#344a59');r((16,16,18,18),fill='#88b3c5')
 elif i==24:
  r((3,4,29,30),fill='#25354a');r((5,6,27,23),fill='#5c829b');l((7,10,22,10),fill='#a0cfbf');l((7,14,20,14),fill='#f2cb78');r((4,26,28,29),fill='#475c70')
 elif i==25:
  r((10,1,22,26),fill='#352e48');r((11,2,21,22),fill='#6c5b7b');l((13,5,19,5),fill='#f2cb78');l((13,8,19,8),fill='#f2cb78');r((7,26,25,28),fill='#374156')
 elif i==26:
  r((9,8,23,28),fill='#445c72');r((11,10,21,25),fill='#658a9e');r((12,3,20,9),fill='#594b49');r((10,20,22,21),fill='#86a4ab')
 elif i==27:
  r((0,0,31,31),fill='#946a52');l((0,10,31,10),fill='#765341');l((0,21,31,21),fill='#765341');l((15,0,15,10),fill='#765341');l((6,11,6,21),fill='#765341');l((23,22,23,31),fill='#765341')
 elif i==28:
  r((3,4,28,29),fill='#373d50');r((4,5,27,13),fill='#d2c6a9');r((4,14,27,28),fill='#5b7486');r((7,17,10,19),fill='#f2cb78');r((14,17,17,19),fill='#e7d6b8');r((21,17,24,19),fill='#ad4251')
 elif i==29:
  r((6,8,26,29),fill='#6e6d6a');r((5,7,27,10),fill='#90928a');l((10,13,10,25),fill='#555b58');l((21,13,21,25),fill='#555b58')
 elif i==30:
  r((1,8,30,24),fill='#584b49');r((2,9,29,22),fill='#b59369');r((7,5,25,10),fill='#ddd7c8');r((4,23,7,31),fill='#45424b');r((25,23,28,31),fill='#45424b')
 else:
  r((0,0,31,31),fill='#65766d');l((0,30,31,30),fill='#4f615a');r((2,2,29,3),fill='#82968a')
 tiles.paste(im,((i%8)*32,(i//8)*32))
for name in ['sala','corredor','exterior','quarto','laboratorio','epa']:tiles.save(A/'tiles'/f'{name}-tiles.png')
# Each collision is exported from actual placed map objects.
for kind in ['quarto','rua','fachada','corredor','sala','laboratorio','avaliacao','preparacao','epa','entardecer','noite']:
 w,h=30,20; outside=kind in ['rua','fachada','entardecer','noite'];base=[14 if outside else (19 if kind=='epa' else 1+(x+y)%2) for y in range(h) for x in range(w)];decor=[0]*(w*h);coll=[]
 def put(x,y,t,solid=False):
  decor[y*w+x]=t+1
  if solid:coll.append({'id':len(coll)+1,'name':'obstacle','type':'collision','x':x*32,'y':y*32,'width':32,'height':30,'properties':[{'name':'collides','type':'bool','value':True}]})
 for x in range(w):put(x,0,3,True);put(x,h-1,3,True)
 for y in range(1,h-1):put(0,y,3,True);put(w-1,y,3,True)
 if outside:
  for y in range(1,7):
   for x in range(6,24):put(x,y,27,True)
  for x in [8,11,18,21]:put(x,3,9,True);put(x,5,9,True)
  put(14,6,4,True);put(15,6,4,True)
  for x,y in [(3,4),(26,4),(3,12),(26,12)]:put(x,y,16,True)
  for y in [16,17,18]:
   for x in range(1,29):base[y*w+x]=16
  for x in [5,23]:put(x,11,17,True)
 elif kind=='quarto':
  for x,y,t in [(3,3,20),(4,3,20),(3,4,20),(4,4,20),(8,3,7),(9,3,7),(12,3,21),(18,1,9),(20,1,9),(25,4,11),(24,15,10),(9,4,6),(11,3,5)]:put(x,y,t,True)
 elif kind=='corredor':
  for x in [4,12,21]:put(x,1,4,True);put(x+2,1,12,True)
  for x,y,t in [(3,5,17),(25,5,17),(18,1,23),(2,1,10),(26,1,9),(27,1,9)]:put(x,y,t,True)
 elif kind in ['laboratorio','preparacao']:
  for y in [5,9,13]:
   for x in [4,5,10,11,20,21,25,26]:put(x,y,7,True);put(x,y+1,6,True)
  put(14,1,8,True);put(15,1,8,True)
 elif kind=='epa':
  for x in [3,11,22]:
   for y in [4,13]:put(x,y,7,True);put(x+1,y,30,True);put(x+2,y,24,True);put(x+3,y,25,True)
  for x,y in [(2,1),(8,1),(20,1),(27,1)]:put(x,y,10,True)
 else:
  for y in [7,11,15]:
   for x in [6,10,19,23]:put(x,y,5,True);put(x,y+1,6,True)
  for x in [12,13,14,15,16,17]:put(x,1,8,True)
  for x,y,t in [(3,1,9),(4,1,9),(24,1,22),(27,2,11),(2,4,10),(26,4,12),(14,3,30),(25,16,7),(26,16,7),(2,16,29)]:put(x,y,t,True)
 zones=[('tryhards',220,140,'tryhard'),('jogadores',780,430,'jogador'),('misteriosos',105,285,'misterioso'),('amigos',450,455,'lia'),('diogo',450,122,'professor-diogo'),('dormindo',210,450,'aluno'),('escondido',330,330,'aluno'),('computador',810,510,'aluno')]
 if kind=='quarto':zones=[('estudar',365,155,'book'),('descansar',130,190,'bed'),('exercicios',640,260,'book'),('amigos',680,390,'lia'),('jogar',265,155,'computer'),('dormir',130,300,'bed')]
 if kind in ['laboratorio','preparacao']:zones=[('testar',210,180,'computer'),('revisar',670,310,'book'),('ensaiar',480,470,'lia'),('niko',450,270,'niko'),('bia',780,480,'bia')]
 if kind=='epa':zones=[('apresentar',470,230,'avaliador'),('lia',390,240,'lia'),('niko',570,250,'niko'),('bia',630,280,'bia')]
 interactions=[{'id':100+i,'name':name,'point':True,'x':x,'y':y,'properties':[{'name':'interactionId','type':'string','value':name},{'name':'sprite','type':'string','value':spr}]} for i,(name,x,y,spr) in enumerate(zones)]
 tsname='exterior' if outside else ('sala' if kind=='avaliacao' else ('laboratorio' if kind=='preparacao' else kind));tsname=tsname if tsname in ['sala','corredor','exterior','quarto','laboratorio','epa'] else 'sala'
 layers=[{'id':1,'name':'Piso','type':'tilelayer','width':w,'height':h,'data':base,'opacity':1,'visible':True,'x':0,'y':0},{'id':2,'name':'Decoracao','type':'tilelayer','width':w,'height':h,'data':decor,'opacity':1,'visible':True,'x':0,'y':0},{'id':3,'name':'Colisoes','type':'objectgroup','objects':coll,'opacity':1,'visible':True},{'id':4,'name':'Spawns','type':'objectgroup','objects':[{'id':90,'name':'player','point':True,'x':480,'y':550,'properties':[{'name':'spawnId','type':'string','value':'player'}]}]},{'id':5,'name':'Interacoes','type':'objectgroup','objects':interactions},{'id':6,'name':'Gatilhos','type':'objectgroup','objects':[]}]
 m={'version':'1.10','tiledversion':'1.11.0','type':'map','orientation':'orthogonal','renderorder':'right-down','width':w,'height':h,'tilewidth':32,'tileheight':32,'infinite':False,'layers':layers,'tilesets':[{'firstgid':1,'name':'escola','tilewidth':32,'tileheight':32,'tilecount':32,'columns':8,'image':f'../tiles/{tsname}-tiles.png','imagewidth':256,'imageheight':128,'margin':0,'spacing':0}]}
 (A/'maps'/f'{kind}.json').write_text(json.dumps(m),encoding='utf8')
# Original 8-bar looping themes; deterministic oscillator composition with soft envelopes.
SR=16000
tracks={'prologo':68,'menu':102,'primeiro-dia':90,'sala':94,'amizade':106,'rotina':112,'prova':126,'suspense':118,'cola':138,'preparacao':96,'epa':124,'final':72}
def wav(path,samples):
 with wave.open(str(path),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(SR);f.writeframes(struct.pack('<'+'h'*len(samples),*[max(-32767,min(32767,int(v*32767))) for v in samples]))
for index,(name,bpm) in enumerate(tracks.items()):
 beat=60/bpm;duration=32*beat;out=[0.] * int(duration*SR);scale=[0,3,7,10,12,7,3,5] if name in ['suspense','cola','prova'] else [0,4,7,11,12,7,4,2];root=48+(index%3)*2
 def note(start,length,midi,gain,style):
  freq=440*2**((midi-69)/12)
  for k in range(int(length*SR)):
   p=int(start*SR)+k
   if p>=len(out):break
   t=k/SR;env=min(1,t/.012)*min(1,(length-t)/.10)*math.exp(-t*2)
   v=math.sin(2*math.pi*freq*t)
   if style=='lead':v=.65*v+.22*math.sin(2*math.pi*freq*2*t)+.10*math.sin(2*math.pi*freq*3*t)
   out[p]+=v*env*gain
 for b in range(32):
  chord=[0,5,9,7][b//8]; note(b*beat,beat*.92,root+12+scale[(b+index)%8],.13,'lead');
  if b%2==0:note(b*beat,beat*1.8,root-12+chord,.13,'bass')
  if name not in ['prologo','final']:
   for k in range(int(.09*SR)):
    p=int(b*beat*SR)+k
    if p<len(out):out[p]+=.07*math.sin(2*math.pi*(95-45*k/(.09*SR))*k/SR)*math.exp(-k/(SR*.023))
 path=A/'audio'/f'bgm-{name}.wav';wav(path,out);subprocess.run(['ffmpeg','-v','error','-y','-i',str(path),'-c:a','libvorbis','-q:a','3',str(path.with_suffix('.ogg'))],check=True);path.unlink()
sfx=['dialogo-blip','dialogo-professor','dialogo-narrador','menu-mover','menu-confirmar','menu-voltar','passos','porta','sinal-escola','ambiente-sala','acerto','erro','rejeicao','amizade','relogio','coracao','alerta','papel','teclado','sucesso','game-over','transicao','aplausos']
for i,name in enumerate(sfx):
 duration=1.5 if name in ['aplausos','sinal-escola','sucesso','amizade'] else (.055 if name.startswith('dialogo') else .22);freq=180+(i%8)*85;out=[]
 for k in range(int(duration*SR)):
  t=k/SR;env=min(1,t/.005)*(1-t/duration)**2;v=math.sin(2*math.pi*(freq+(120 if i%2 else -80)*t)*t)
  if name=='aplausos':v=random.uniform(-1,1)*(.6+.4*math.sin(t*23))
  out.append(v*env*.22)
 wav(A/'audio'/f'{name}.wav',out)
manifest={'original':True,'generator':'scripts/create-assets.py','player':{'frameWidth':96,'frameHeight':96,'columns':3,'rows':4,'directions':['down','left','right','up'],'fallback':True},'music':tracks,'tiles':{'width':32,'height':32,'columns':8,'count':32},'actions':['sentado','escrevendo','estudando','celular','nervoso','assustado','dormindo','correndo','cola','apresentando','comemorando','amigos']}
(A/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('Created original character sheets, portraits, tiles, 11 Tiled maps, 12 OGG themes and 23 WAV effects.')
