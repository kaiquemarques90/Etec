from pathlib import Path
import re,json
root=Path(__file__).resolve().parents[1];text=(root/'docs/ESPECIFICACAO.md').read_text()
def extract(start,end):
 part=text[text.index(start):text.index(end,text.index(start)+len(start))];speaker='NARRADOR';lines=[]
 for line in part.splitlines():
  line=line.strip()
  if re.match(r'^[A-ZÁÉÍÓÚÃÕÇ0-9 ]+(?: \(pensamento\))?:$',line):speaker=line.rstrip(':').replace(' (pensamento)','')
  if line.startswith('"') and line.endswith('"'):lines.append({'speaker':speaker,'text':line[1:-1]})
 return lines
sections={'prologo':('## Cena P01','## Cena P02'),'quarto':('## Cena P02','## Cena P03'),'chegada':('## Cena C01','## Cena C05'),'tryhards':('## Diálogo — Grupo 1','## Diálogo — Grupo 2'),'jogadores':('## Diálogo — Grupo 2','## Diálogo — Grupo 3'),'misteriosos':('## Diálogo — Grupo 3','## Diálogo — Grupo 4'),'amigos':('## Diálogo — Grupo 4','### Resposta 1'),'fim1':('## Cutscene de encerramento do 1º bimestre','# 8.'),'inicio2':('## Cutscene de abertura','# 9.'),'inicio3':('# 11.','# 12.'),'fim3':('# 14.','# 15.'),'inicio4':('## Cutscene Q01','# 16.'),'epa':('## Cena E01','# 17.'),'final':('# 18.','## Última cena')}
(root/'Javascript/data/dialogos.js').write_text('export const dialogos = '+json.dumps({k:extract(*v) for k,v in sections.items()},ensure_ascii=False,indent=2)+';\n')
