import { cp, mkdir, rm } from "node:fs/promises";
import { fileURLToPath } from "node:url";
const root = fileURLToPath(new URL("../", import.meta.url));
await rm(root + "dist", { recursive: true, force: true });
await mkdir(root + "dist");
for (const file of ["index.html", "Css", "Javascript", "Assets"])
  await cp(root + file, root + "dist/" + file, { recursive: true });
console.log("Build estático completo: dist/ (engine, sprites e áudio locais).");
