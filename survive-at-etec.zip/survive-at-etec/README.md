# SURVIVE AT ETEC

Um ano. Quatro bimestres. Boa sorte.

Jogo narrativo em Phaser **3.90.0**, JavaScript, pixel art e áudio originais. Aplicação independente dos outros projetos do repositório, em `survive-at-etec/`. Engine e assets são locais; o jogo não precisa de API, conta, banco ou conexão externa depois de carregado.

## Executar

Node.js 22 ou posterior:

```sh
cd /workspace/Etec/survive-at-etec
npm start
```

Servidor na porta 4173. Abra a origem do servidor no navegador; módulos ES não funcionam abrindo o HTML como `file://`. A tela de entrada ativa o áudio com um clique válido. `PORT=8080 npm start` muda a porta.

```sh
npm test
npm run build
SERVE_DIST=1 npm start
```

O build estático fica em `dist/`. Para hospedar, publique **todo** o conteúdo dessa pasta. Sem chamadas a CDN ou serviços de arte; Phaser está em `Assets/vendor/`, com sua licença MIT.

## Campanha

1. Prólogo e primeiro dia: diálogos com digitação, quarto, rua, corredor e sala.
2. Primeiro bimestre: exploração com colisões reais, três grupos e aceitação por Lia, Niko e Bia; escolha de interesse.
3. Segundo: nove períodos de rotina em três dias, equilíbrio entre preparo/energia/estresse, cinco questões e menções MB/B/R/I fictícias. Recuperação repete só a prova.
4. Terceiro: três desafios honestos ou consulta de cola com patrulha previsível, aviso de observação, suspeita e respiração. Flagrante permite escolher outra rota.
5. Quarto: teste, revisão e ensaio com os amigos; apresentação com introdução, demonstração em ordem e três perguntas. Preparação, respostas e respiração influenciam o resultado.
6. Final: conversa dos amigos, consequência da rota, encerramento e página do projeto. Conhecer o projeto destrói a instância Phaser e libera o teclado.

O salvamento local registra checkpoints, tarefas e escolhas. Minigames retomam do seu início; rotinas/tarefas concluídas são preservadas. O jogo não depende de atingir uma nota perfeita. Pausa oferece checkpoint, volumes separados, velocidade de texto, redução de tremor e histórico. Cenas marcadas como vistas permitem pular quando reproduzidas pelo sistema de cutscene reutilizável.

## Controles

- WASD/setas: andar; E: interação próxima.
- ENTER: completar/avançar texto e confirmar escolhas.
- Setas ou 1–3: escolhas; todas as opções também aceitam toque.
- ESC: pausa; ESPAÇO: respiração nas avaliações/apresentação.
- Segurar C: consultar a cola; soltar: esconder.
- Controles de toque sob o canvas em telas pequenas. Fullscreen no topo da moldura.

## Arquivos e personalização

- `index.html` e `Css/style.css`: site, moldura, controles móveis e página do EPA.
- `Javascript/Scenes/`: cenas e minigames; `main.js` apenas inicializa e integra o site.
- `Javascript/dialogo.js`, `Player.js`, `AudioManager.js`, `SaveManager.js`, `HUD.js`: sistemas reutilizáveis.
- `Javascript/GameState.js`: regras puras de rotina, menções e risco.
- `Javascript/data/dialogos.js`: diálogos extraídos do roteiro fornecido.
- `Javascript/data/questoes.js`: questões, respostas, pistas e preparação.
- `Javascript/data/configJogo.js`: conteúdo do projeto e créditos **sem nomes inventados**. Preencha os arrays de participantes.
- `Assets/sprites/`: PNGs transparentes, spritesheets, retratos e expressões.
- `Assets/maps/`: 11 mapas JSON no formato Tiled ortogonal 32 × 32; editáveis no Tiled.
- `Assets/tiles/`: tilesets de 256 × 128, 32 tiles; objetos e colisões exportados do mesmo mapa.
- `Assets/audio/`: 12 composições OGG e 23 efeitos WAV originais.
- `Assets/manifest.json`: dimensões, frames e BPMs.
- `docs/ESPECIFICACAO.md`: documento original recebido.

O `player.png` referido no documento não existia nos arquivos recebidos. Foi criado um protagonista original no formato **288 × 384**, com 12 frames de **96 × 96**: baixo 0–2, esquerda 3–5, direita 6–8, cima 9–11. Sua escala é 1/3 e o corpo físico está nos pés. Se você tem o personagem original, substitua apenas esse arquivo com o mesmo layout; o gerador preserva um `player.png` existente.

### Regenerar arte e áudio

Requer Python 3, Pillow e FFmpeg com libvorbis. O gerador é determinístico e não chama APIs:

```sh
python scripts/create-assets.py
python scripts/extract-dialogues.py
```

O gerador escreve apenas assets próprios; não use sobre arte customizada sem antes preservá-la. Os sprites adicionais de ações e NPCs foram entregues, mas a campanha reutiliza principalmente animações de caminhada e poses estáticas. As faixas são loops curtos de síntese original, não gravações de instrumentos reais. Não foram usados sprites ou melodias dos jogos citados como referência.

### Verificação de navegador

`tests/browser.cjs` usa Playwright e Chromium. Configure `PLAYWRIGHT_MODULE` se o módulo estiver fora da resolução padrão, `CHROMIUM_PATH` para o executável e `TEST_URL` para outra origem. No ambiente atual, Playwright está disponível e Chromium está em `/usr/bin/chromium`.

```sh
npm start
# em outro terminal
npm run test:browser
```

A campanha principal usa teclas reais; os testes posicionam o protagonista próximo aos NPCs para acelerar deslocamentos e verificam separadamente colisão com carteira. Cobrem conclusão dos quatro bimestres, rota honesta, flagrante, sucesso na rota arriscada, respiração, reprovação/repetição, restauração de checkpoint, saída para o site e layout móvel.

## Escopo e limites de validação

Esta entrega contém uma campanha jogável de ponta a ponta. Ainda requer playtest presencial para calibrar ritmo/dificuldade e atingir a duração desejada de 25–35 minutos; essa duração não foi certificada por um playtest humano. As cutscenes são encenações compactas com mapas, sprites e diálogo, não animações cinematográficas quadro a quadro. A arte é pixel art procedural original, editável e reproduzível. Safari/iOS, dispositivos físicos e implantação pública não foram verificados. As menções são mecânicas ficcionais, sem equivalência com critérios oficiais da escola.
