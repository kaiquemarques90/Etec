import { test } from "node:test";
import assert from "node:assert/strict";
import {
  newState,
  applyRoutine,
  mention,
  examSeconds,
  updateRisk,
  breathe,
} from "../Javascript/GameState.js";
import { prova, logica, preparacao, epa } from "../Javascript/data/questoes.js";
import { readFile, readdir } from "node:fs/promises";
test("rotina termina em três dias, com valores limitados e preparação útil", () => {
  let r = newState().routine;
  for (const a of [
    "estudar",
    "estudar",
    "descansar",
    "estudar",
    "exercicios",
    "amigos",
    "estudar",
    "estudar",
    "descansar",
  ])
    r = applyRoutine(r, a);
  assert.equal(r.day, 4);
  assert.equal(r.preparation, 100);
  for (const key of ["energy", "preparation", "stress"])
    assert.ok(r[key] >= 0 && r[key] <= 100);
  assert.ok(examSeconds(r) > 20);
  assert.deepEqual(applyRoutine(r, "estudar"), r);
});
test("dormir encerra só o dia atual, sem prender a progressão", () => {
  let r = newState().routine;
  for (let i = 0; i < 3; i++) r = applyRoutine(r, "dormir");
  assert.equal(r.day, 4);
  assert.equal(r.preparation, 0);
});
test("menções e penalidades preservam as faixas fictícias", () => {
  assert.deepEqual([100, 80, 79, 60, 59, 40, 39, 0].map(mention), [
    "MB",
    "MB",
    "B",
    "B",
    "R",
    "R",
    "I",
    "I",
  ]);
  assert.equal(mention(100 - 4 * 20), "I");
});
test("cola com professor olhando é arriscada; esconder e respirar recuperam", () => {
  let r = { suspicion: 10, nervous: 35 };
  r = updateRisk(r, 3, true, true);
  assert.equal(r.suspicion, 70);
  assert.equal(r.nervous, 71);
  r = breathe(r);
  assert.equal(r.nervous, 51);
  r = updateRisk(r, 10, false, true);
  assert.equal(r.suspicion, 0);
  assert.equal(r.nervous, 0);
  assert.equal(updateRisk(r, 10, true, true).suspicion, 100);
});
test("questões têm respostas válidas e cinco perguntas na prova", () => {
  assert.equal(prova.length, 5);
  assert.equal(logica.length, 3);
  for (const q of [...prova, ...logica, ...Object.values(preparacao), ...epa]) {
    assert.equal(q.options.length, 3);
    assert.ok(q.answer >= 0 && q.answer < 3);
  }
});
test("todos os mapas possuem pisos, spawn, interações e colisões reais", async () => {
  const dir = new URL("../Assets/maps/", import.meta.url);
  const files = await readdir(dir);
  assert.equal(files.length, 11);
  for (const file of files) {
    const m = JSON.parse(await readFile(new URL(file, dir)));
    assert.equal(m.orientation, "orthogonal");
    assert.equal(
      m.layers.find((l) => l.name === "Piso").data.length,
      m.width * m.height,
    );
    for (const layer of ["Spawns", "Interacoes", "Colisoes"])
      assert.ok(m.layers.find((l) => l.name === layer).objects.length);
    const spawn = m.layers.find((l) => l.name === "Spawns").objects[0];
    for (const o of m.layers.find((l) => l.name === "Colisoes").objects)
      assert.ok(
        !(
          spawn.x >= o.x &&
          spawn.x <= o.x + o.width &&
          spawn.y >= o.y &&
          spawn.y <= o.y + o.height
        ),
        "spawn inside collision",
      );
  }
});
