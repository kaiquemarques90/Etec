const { chromium } = require(process.env.PLAYWRIGHT_MODULE || "playwright");
const assert = require("node:assert/strict");
const path = require("node:path");
const URL = process.env.TEST_URL || "http://127.0.0.1:4173";
(async () => {
  const browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1100 },
  });
  const errors = [];
  page.on("pageerror", (e) => {
    errors.push(e.stack);
    console.log("PAGE ERROR", e.message);
  });
  page.on("response", (r) => {
    if (r.status() >= 400) errors.push(r.status() + " " + r.url());
  });
  async function scene() {
    return page.evaluate(
      () => window.etecGame?.scene.getScenes(true)[0]?.scene.key,
    );
  }
  async function waitScene(key) {
    await page.waitForFunction(
      (k) => window.etecGame?.scene.getScenes(true)[0]?.scene.key === k,
      key,
      { timeout: 15000 },
    );
    console.log("Scene:", key);
  }
  async function ready() {
    await page.waitForFunction(
      () => {
        const s = window.etecGame?.scene.getScenes(true)[0];
        return s && !s.dialogue?.active && s.menuItems?.length > 0;
      },
      null,
      { timeout: 10000 },
    );
  }
  async function drain() {
    const initialKey = await scene();
    for (let i = 0; i < 250; i++) {
      const current = await page.evaluate(() => {
        const s = window.etecGame?.scene.getScenes(true)[0];
        return {
          key: s?.scene.key,
          dialogue: s?.dialogue?.active,
          locked: s?.locked,
          menu: s?.menuItems?.length,
        };
      });
      if (current.key && current.key !== initialKey) return;
      if (current.dialogue) {
        await page.keyboard.press("Enter");
        await page.waitForTimeout(10);
      } else if (current.locked || !current.key) {
        await page.waitForTimeout(100);
      } else return;
    }
    throw Error("Dialogue failed to finish");
  }
  async function choose(n) {
    await ready();
    await page.keyboard.press("Digit" + n);
    await page.waitForTimeout(50);
  }
  async function npc(id) {
    await page.evaluate((id) => {
      const s = window.etecGame.scene.getScenes(true)[0];
      const n = s.npcs.find((n) => n.id === id);
      s.player.setPosition(n.x, n.y + 40);
      s.player.body.reset(n.x, n.y + 40);
    }, id);
    await page.waitForTimeout(100);
    await page.keyboard.press("KeyE");
    await page.waitForTimeout(50);
  }
  await page.goto(URL);
  await page.click("#launch");
  await waitScene("Prologo");
  await drain();
  await waitScene("Titulo");
  await page.screenshot({ path: "/tmp/etec-menu.png" });
  await choose(1);
  await waitScene("CutsceneInicio");
  await drain();
  await waitScene("TransicaoBimestre");
  await choose(1);
  await waitScene("Bimestre1");
  await drain();
  // Feet collider hits a real desk exported from Tiled.
  await page.evaluate(() => {
    const s = window.etecGame.scene.getScenes(true)[0];
    s.player.body.reset(208, 210);
    s.player.setPosition(208, 210);
  });
  await page.keyboard.down("ArrowDown");
  await page.waitForTimeout(600);
  await page.keyboard.up("ArrowDown");
  const y = await page.evaluate(
    () => window.etecGame.scene.getScenes(true)[0].player.y,
  );
  assert.ok(y < 229, "desk collision, y=" + y);
  console.log("PASS desk collision");
  for (const id of ["tryhards", "jogadores", "misteriosos"]) {
    await npc(id);
    await drain();
  }
  assert.equal(
    await page.evaluate(
      () => window.etecGame.registry.get("state").known.length,
    ),
    3,
  );
  await page.screenshot({ path: "/tmp/etec-classroom.png" });
  await page.keyboard.press("Escape");
  await page.waitForTimeout(80);
  assert.equal(
    await page.evaluate(() => window.etecGame.scene.getScenes(true)[0].paused),
    true,
  );
  await page.keyboard.press("Escape");
  await npc("amigos");
  await drain();
  await choose(1);
  await drain();
  await waitScene("TransicaoBimestre");
  await choose(1);
  await waitScene("Bimestre2");
  await drain();
  for (const n of [1, 1, 2, 1, 1, 2, 1, 1, 2]) {
    await choose(n);
    await drain();
  }
  await waitScene("Prova");
  await drain();
  for (const [i, n] of [2, 1, 2, 2, 2].entries()) {
    await choose(n);
    if (i < 4) await page.waitForTimeout(850);
    else await drain();
  }
  await waitScene("TransicaoBimestre");
  assert.equal(
    await page.evaluate(() => window.etecGame.registry.get("state").examScore),
    100,
  );
  await choose(1);
  await waitScene("Bimestre3");
  await drain();
  await choose(1);
  await waitScene("RotaHonesta");
  await drain();
  for (const [i, n] of [1, 3, 2].entries()) {
    await choose(n);
    if (i < 2) await page.waitForTimeout(850);
    else await drain();
  }
  await waitScene("CutsceneEPA");
  await drain();
  await waitScene("TransicaoBimestre");
  await choose(1);
  await waitScene("Bimestre4");
  await drain();
  for (const [id, n] of [
    ["testar", 2],
    ["revisar", 1],
    ["ensaiar", 3],
  ]) {
    await npc(id);
    await choose(n);
    await drain();
  }
  await waitScene("DiaEPA");
  await drain();
  await waitScene("Apresentacao");
  await drain();
  await choose(1);
  await drain();
  for (const [i, n] of [1, 2, 3].entries()) {
    await choose(n);
    if (i < 2) await page.waitForTimeout(750);
    else await drain();
  }
  for (let i = 0; i < 3; i++) {
    await choose(1);
    await drain();
  }
  await waitScene("Final");
  await drain();
  await waitScene("Encerramento");
  await page.screenshot({ path: "/tmp/etec-ending.png" });
  const finished = await page.evaluate(() =>
    window.etecGame.registry.get("state"),
  );
  assert.equal(finished.friendship, 1);
  assert.equal(finished.route, "honesta");
  assert.equal(finished.completed, true);
  assert.equal(finished.epaTasks.length, 3);
  assert.ok(finished.presentation.confidence >= 80);
  console.log("PASS complete four-chapter honest campaign");
  const saved = await page.evaluate(() =>
    localStorage.getItem("survive-at-etec-v1"),
  );
  await choose(1);
  await page.waitForTimeout(100);
  assert.equal(await page.evaluate(() => window.etecGame), null);
  assert.equal(await page.isVisible("#project-page"), true);
  await page.keyboard.press("ArrowDown");
  console.log("PASS project handoff destroys game and releases keyboard");
  // Restore a real checkpoint into the alternate branch and play both caught and successful outcomes.
  await page.evaluate((saved) => {
    const d = JSON.parse(saved);
    d.scene = "Bimestre3";
    d.completed = false;
    d.seen = [];
    d.route = null;
    localStorage.setItem("survive-at-etec-v1", JSON.stringify(d));
  }, saved);
  await page.click("#return-game");
  await page.click("#launch");
  await waitScene("Titulo");
  await choose(2);
  await waitScene("Bimestre3");
  await drain();
  await choose(2);
  await waitScene("RotaCola");
  await drain();
  await page.keyboard.down("KeyC");
  await page.waitForTimeout(12000);
  await page.keyboard.up("KeyC");
  await drain();
  await ready();
  assert.equal(
    await page.evaluate(() => window.etecGame.registry.get("state").caught),
    true,
  );
  console.log("PASS visible predictable teacher patrol and caught consequence");
  await choose(1);
  await waitScene("Bimestre3");
  await drain();
  await choose(2);
  await waitScene("RotaCola");
  await drain();
  await page.keyboard.down("KeyC");
  await page.waitForTimeout(500);
  assert.ok(
    (
      await page.evaluate(
        () => window.etecGame.scene.getScenes(true)[0].clue.text,
      )
    ).includes("PISTA"),
  );
  await page.keyboard.up("KeyC");
  await page.keyboard.press("Space");
  assert.ok(
    await page.evaluate(
      () => window.etecGame.scene.getScenes(true)[0].cooldown > 0,
    ),
  );
  for (const [i, n] of [1, 3, 2].entries()) {
    await choose(n);
    if (i < 2) await page.waitForTimeout(850);
    else await drain();
  }
  await waitScene("CutsceneEPA");
  console.log("PASS risky route success with breathing and hint");
  // Failed exam and checkpoint retry.
  await page.evaluate(() => {
    const s = window.etecGame.registry.get("state");
    s.scene = "Prova";
    window.etecGame.scene.getScenes(true)[0].scene.start("Prova");
  });
  await waitScene("Prova");
  await drain();
  for (const [i, n] of [1, 2, 1, 1, 1].entries()) {
    await choose(n);
    if (i < 4) await page.waitForTimeout(850);
    else await drain();
  }
  await ready();
  assert.equal(
    await page.evaluate(() => window.etecGame.registry.get("state").examScore),
    0,
  );
  await choose(1);
  await waitScene("Prova");
  await drain();
  assert.equal(
    await page.evaluate(() => window.etecGame.scene.getScenes(true)[0].score),
    100,
  );
  console.log("PASS failed exam can retry checkpoint");
  assert.deepEqual(errors, []);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: "/tmp/etec-mobile.png" });
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  );
  console.log("PASS mobile layout, no browser errors or missing assets");
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
