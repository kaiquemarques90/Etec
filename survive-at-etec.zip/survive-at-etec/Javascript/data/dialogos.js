export const dialogos = {
  prologo: [
    {
      speaker: "NARRADOR",
      text: "Parabéns.",
    },
    {
      speaker: "NARRADOR",
      text: "Você passou no vestibulinho.",
    },
    {
      speaker: "NARRADOR",
      text: "Depois de tanto estudar...",
    },
    {
      speaker: "NARRADOR",
      text: "...finalmente conseguiu entrar na ETEC.",
    },
    {
      speaker: "NARRADOR",
      text: "Você provavelmente acha que a parte difícil acabou.",
    },
    {
      speaker: "NARRADOR",
      text: "Que ingenuidade.",
    },
    {
      speaker: "NARRADOR",
      text: "Agora começa o verdadeiro desafio.",
    },
    {
      speaker: "NARRADOR",
      text: "Um ano.",
    },
    {
      speaker: "NARRADOR",
      text: "Quatro bimestres.",
    },
    {
      speaker: "NARRADOR",
      text: "E muitas coisas que ninguém explicou no vestibulinho.",
    },
    {
      speaker: "NARRADOR",
      text: "Bem-vindo à ETEC.",
    },
  ],
  quarto: [
    {
      speaker: "PLAYER",
      text: "Eu consegui...",
    },
    {
      speaker: "PLAYER",
      text: "Caramba.",
    },
    {
      speaker: "PLAYER",
      text: "EU CONSEGUI!",
    },
    {
      speaker: "PLAYER",
      text: "Agora vai ser tranquilo.",
    },
    {
      speaker: "NARRADOR",
      text: "É claro.",
    },
    {
      speaker: "NARRADOR",
      text: "...tranquilo.",
    },
  ],
  chegada: [
    {
      speaker: "PLAYER",
      text: "Primeiro dia.",
    },
    {
      speaker: "PLAYER",
      text: "Escola nova.",
    },
    {
      speaker: "PLAYER",
      text: "Pessoas novas.",
    },
    {
      speaker: "PLAYER",
      text: "Eu consigo.",
    },
    {
      speaker: "PLAYER",
      text: "...eu acho.",
    },
    {
      speaker: "ALUNO CORRENDO",
      text: "LICENÇA! EU TÔ ATRASADO!",
    },
    {
      speaker: "PLAYER",
      text: "Mas a aula nem começou...",
    },
    {
      speaker: "NARRADOR",
      text: "Você descobrirá que isso não importa.",
    },
    {
      speaker: "PLAYER",
      text: "Primeiro ano de Desenvolvimento de Sistemas...",
    },
    {
      speaker: "PLAYER",
      text: "Deve ser aqui.",
    },
    {
      speaker: "PLAYER",
      text: "Tá. É só entrar.",
    },
    {
      speaker: "PLAYER",
      text: "...por que eu tô nervoso?",
    },
    {
      speaker: "PLAYER",
      text: "Uau.",
    },
    {
      speaker: "PLAYER",
      text: "Todo mundo já parece conhecer alguém.",
    },
    {
      speaker: "PLAYER",
      text: "Tem até gente que já formou grupo.",
    },
    {
      speaker: "PLAYER",
      text: "...e tem alguém escondido ali?",
    },
    {
      speaker: "DIOGO",
      text: "Bom dia, pessoal.",
    },
    {
      speaker: "DIOGO",
      text: "Sejam bem-vindos ao curso de Desenvolvimento de Sistemas.",
    },
    {
      speaker: "DIOGO",
      text: "Espero que gostem de lógica.",
    },
    {
      speaker: "DIOGO",
      text: "Porque vocês vão precisar.",
    },
    {
      speaker: "PLAYER",
      text: "Isso foi uma ameaça?",
    },
  ],
  tryhards: [
    {
      speaker: "TRYHARD 1",
      text: "Você é novo aqui?",
    },
    {
      speaker: "PLAYER",
      text: "Sou. Posso ficar com vocês?",
    },
    {
      speaker: "TRYHARD 2",
      text: "Depende.",
    },
    {
      speaker: "TRYHARD 2",
      text: "Quanto você tirou no vestibulinho?",
    },
    {
      speaker: "PLAYER",
      text: "Eu... passei?",
    },
    {
      speaker: "TRYHARD 3",
      text: "Isso não responde à pergunta.",
    },
    {
      speaker: "TRYHARD 1",
      text: "Você já começou a estudar para o ENEM?",
    },
    {
      speaker: "PLAYER",
      text: "Mas a gente acabou de entrar...",
    },
    {
      speaker: "TRYHARD 2",
      text: "Exatamente.",
    },
    {
      speaker: "TRYHARD 1",
      text: "Desculpa, nosso grupo está completo.",
    },
    {
      speaker: "PLAYER",
      text: "Eu só queria conversar...",
    },
  ],
  jogadores: [
    {
      speaker: "JOGADOR 1",
      text: "E aí, mano.",
    },
    {
      speaker: "JOGADOR 1",
      text: "Você joga alguma coisa?",
    },
    {
      speaker: "PLAYER",
      text: "Jogo, sim.",
    },
    {
      speaker: "JOGADOR 2",
      text: "Qual seu rank?",
    },
    {
      speaker: "PLAYER",
      text: "Em quê?",
    },
    {
      speaker: "JOGADOR 3",
      text: "Isso já responde.",
    },
    {
      speaker: "PLAYER",
      text: "Eu também gosto de programação.",
    },
    {
      speaker: "JOGADOR 1",
      text: "Legal.",
    },
    {
      speaker: "JOGADOR 1",
      text: "Mas nosso squad tá fechado.",
    },
    {
      speaker: "JOGADOR 2",
      text: "Foi mal.",
    },
    {
      speaker: "PLAYER",
      text: "Até na escola tem matchmaking...",
    },
  ],
  misteriosos: [
    {
      speaker: "PLAYER",
      text: "Oi...",
    },
    {
      speaker: "MISTERIOSO 1",
      text: "...",
    },
    {
      speaker: "PLAYER",
      text: "Posso ficar aqui?",
    },
    {
      speaker: "MISTERIOSO 2",
      text: "......",
    },
    {
      speaker: "PLAYER",
      text: "Vocês estão fazendo alguma coisa?",
    },
    {
      speaker: "MISTERIOSO 3",
      text: "Estamos esperando.",
    },
    {
      speaker: "PLAYER",
      text: "Esperando o quê?",
    },
    {
      speaker: "MISTERIOSO 1",
      text: "O momento.",
    },
    {
      speaker: "PLAYER",
      text: "Tá bom...",
    },
    {
      speaker: "MISTERIOSO 2",
      text: "Não.",
    },
    {
      speaker: "PLAYER",
      text: "...entendi.",
    },
  ],
  amigos: [
    {
      speaker: "LIA",
      text: "Ei!",
    },
    {
      speaker: "LIA",
      text: "Você é o aluno novo, né?",
    },
    {
      speaker: "PLAYER",
      text: "Sou.",
    },
    {
      speaker: "NIKO",
      text: "Você tá procurando alguém pra conversar?",
    },
    {
      speaker: "PLAYER",
      text: "Mais ou menos.",
    },
    {
      speaker: "BIA",
      text: "Ele tá com cara de quem já foi rejeitado três vezes.",
    },
    {
      speaker: "PLAYER",
      text: "...",
    },
    {
      speaker: "NIKO",
      text: "Caramba, acertou?",
    },
    {
      speaker: "LIA",
      text: "Relaxa.",
    },
    {
      speaker: "LIA",
      text: "Pode ficar aqui com a gente.",
    },
    {
      speaker: "PLAYER",
      text: "Sério?",
    },
    {
      speaker: "LIA",
      text: "Claro.",
    },
    {
      speaker: "LIA",
      text: "Você gosta de fazer o quê?",
    },
  ],
  fim1: [
    {
      speaker: "LIA",
      text: "Viu? Não foi tão difícil.",
    },
    {
      speaker: "PLAYER",
      text: "Foi um pouco.",
    },
    {
      speaker: "NIKO",
      text: "Agora que você tem amigos, vai ficar tranquilo.",
    },
    {
      speaker: "BIA",
      text: "É.",
    },
    {
      speaker: "BIA",
      text: "Até começarem as provas.",
    },
    {
      speaker: "PLAYER",
      text: "...as provas?",
    },
    {
      speaker: "PLAYER",
      text: "Você fez amigos.",
    },
    {
      speaker: "PLAYER",
      text: "+1 AMIZADE",
    },
    {
      speaker: "PLAYER",
      text: "Próximo desafio: sobreviver às provas.",
    },
  ],
  inicio2: [
    {
      speaker: "NARRADOR",
      text: "Depois de algumas semanas...",
    },
    {
      speaker: "NARRADOR",
      text: "Você descobriu uma verdade.",
    },
    {
      speaker: "NARRADOR",
      text: "A ETEC tem provas.",
    },
    {
      speaker: "NARRADOR",
      text: "Muitas provas.",
    },
    {
      speaker: "PLAYER",
      text: "Mas eu acabei de entregar um trabalho!",
    },
    {
      speaker: "LIA",
      text: "Sim.",
    },
    {
      speaker: "LIA",
      text: "Agora tem outro.",
    },
    {
      speaker: "NIKO",
      text: "Relaxa, eu também não comecei.",
    },
    {
      speaker: "BIA",
      text: "A entrega é amanhã.",
    },
    {
      speaker: "NIKO",
      text: "...",
    },
    {
      speaker: "PLAYER",
      text: "Estamos perdidos.",
    },
  ],
  inicio3: [
    {
      speaker: "DIOGO",
      text: "Bom dia, pessoal.",
    },
    {
      speaker: "DIOGO",
      text: "Hoje teremos uma avaliação.",
    },
    {
      speaker: "PLAYER",
      text: "Hoje?",
    },
    {
      speaker: "NIKO",
      text: "Hoje.",
    },
    {
      speaker: "PLAYER",
      text: "Mas ninguém avisou!",
    },
    {
      speaker: "BIA",
      text: "Avisaram.",
    },
    {
      speaker: "PLAYER",
      text: "Quando?",
    },
    {
      speaker: "BIA",
      text: "Na última aula.",
    },
    {
      speaker: "PLAYER",
      text: "Eu tava aqui?",
    },
    {
      speaker: "LIA",
      text: "Fisicamente.",
    },
    {
      speaker: "DIOGO",
      text: "Podem começar.",
    },
    {
      speaker: "PLAYER",
      text: "Eu não lembro de metade disso...",
    },
  ],
  fim3: [
    {
      speaker: "LIA",
      text: "Finalmente acabou.",
    },
    {
      speaker: "NIKO",
      text: "Eu achei que não ia sobreviver.",
    },
    {
      speaker: "BIA",
      text: "Vocês falam isso todo bimestre.",
    },
    {
      speaker: "PLAYER",
      text: "E ainda estamos aqui.",
    },
    {
      speaker: "LIA",
      text: "Falta só mais um.",
    },
    {
      speaker: "NIKO",
      text: "O último costuma ser tranquilo, né?",
    },
    {
      speaker: "BIA",
      text: "Tem o EPA.",
    },
    {
      speaker: "PLAYER",
      text: "...o quê?",
    },
    {
      speaker: "PLAYER",
      text: "Você ainda não terminou.",
    },
  ],
  inicio4: [
    {
      speaker: "DIOGO",
      text: "Pessoal, estamos chegando ao final do ano.",
    },
    {
      speaker: "DIOGO",
      text: "Agora vocês terão uma oportunidade de mostrar o que aprenderam.",
    },
    {
      speaker: "DIOGO",
      text: "Preparem seus projetos para o EPA.",
    },
    {
      speaker: "PLAYER",
      text: "Projeto?",
    },
    {
      speaker: "NIKO",
      text: "Projeto.",
    },
    {
      speaker: "BIA",
      text: "Apresentação.",
    },
    {
      speaker: "LIA",
      text: "Avaliadores.",
    },
    {
      speaker: "PLAYER",
      text: "...público?",
    },
    {
      speaker: "DIOGO",
      text: "Exatamente.",
    },
    {
      speaker: "PLAYER",
      text: "Eu prefiro outra prova.",
    },
    {
      speaker: "LIA",
      text: "Precisamos terminar o projeto.",
    },
    {
      speaker: "NIKO",
      text: "Eu fiz a parte visual.",
    },
    {
      speaker: "BIA",
      text: "Eu organizei a apresentação.",
    },
    {
      speaker: "PLAYER",
      text: "E eu?",
    },
    {
      speaker: "NIKO",
      text: "Você vai explicar o sistema.",
    },
    {
      speaker: "PLAYER",
      text: "...",
    },
    {
      speaker: "BIA",
      text: "Boa sorte.",
    },
  ],
  epa: [
    {
      speaker: "NARRADOR",
      text: "Meses se passaram.",
    },
    {
      speaker: "NARRADOR",
      text: "Trabalhos foram entregues.",
    },
    {
      speaker: "NARRADOR",
      text: "Provas foram feitas.",
    },
    {
      speaker: "NARRADOR",
      text: "Amizades foram construídas.",
    },
    {
      speaker: "NARRADOR",
      text: "E agora...",
    },
    {
      speaker: "NARRADOR",
      text: "...chegou o grande dia.",
    },
    {
      speaker: "LIA",
      text: "Tá tudo pronto?",
    },
    {
      speaker: "NIKO",
      text: "O sistema tá funcionando.",
    },
    {
      speaker: "BIA",
      text: "O banner tá no lugar.",
    },
    {
      speaker: "PLAYER",
      text: "E se eu esquecer tudo?",
    },
    {
      speaker: "LIA",
      text: "A gente te ajuda.",
    },
    {
      speaker: "BIA",
      text: "Você passou o ano inteiro aprendendo.",
    },
    {
      speaker: "NIKO",
      text: "E sobrevivendo.",
    },
    {
      speaker: "PLAYER",
      text: "...verdade.",
    },
    {
      speaker: "AVALIADOR 1",
      text: "Bom dia.",
    },
    {
      speaker: "AVALIADOR 1",
      text: "Podemos conhecer o projeto de vocês?",
    },
    {
      speaker: "LIA",
      text: "Vai lá.",
    },
    {
      speaker: "NIKO",
      text: "Você consegue.",
    },
    {
      speaker: "PLAYER",
      text: "Tá.",
    },
    {
      speaker: "PLAYER",
      text: "Vamos começar.",
    },
  ],
  final: [
    {
      speaker: "NIKO",
      text: "Então...",
    },
    {
      speaker: "NIKO",
      text: "Acabou?",
    },
    {
      speaker: "BIA",
      text: "Parece que sim.",
    },
    {
      speaker: "LIA",
      text: "Foi um ano estranho.",
    },
    {
      speaker: "PLAYER",
      text: "Foi.",
    },
    {
      speaker: "LIA",
      text: "A gente nem se conhecia.",
    },
    {
      speaker: "NIKO",
      text: "E agora sobrevivemos a tudo isso.",
    },
    {
      speaker: "BIA",
      text: "Mais ou menos.",
    },
    {
      speaker: "PLAYER",
      text: "É engraçado...",
    },
    {
      speaker: "PLAYER",
      text: "No primeiro dia eu só queria encontrar alguém pra conversar.",
    },
    {
      speaker: "PLAYER",
      text: "Depois vieram as provas.",
    },
    {
      speaker: "PLAYER",
      text: "As noites estudando.",
    },
    {
      speaker: "PLAYER",
      text: "Os trabalhos.",
    },
    {
      speaker: "PLAYER",
      text: "E agora a gente acabou de apresentar um projeto.",
    },
    {
      speaker: "LIA",
      text: "Você mudou bastante.",
    },
    {
      speaker: "PLAYER",
      text: "Vocês também.",
    },
    {
      speaker: "NIKO",
      text: "Será que o próximo ano vai ser mais fácil?",
    },
    {
      speaker: "BIA",
      text: "Não.",
    },
    {
      speaker: "LIA",
      text: "Mas pelo menos não vamos estar sozinhos.",
    },
    {
      speaker: "PLAYER",
      text: "É.",
    },
    {
      speaker: "PLAYER",
      text: "Isso já ajuda bastante.",
    },
  ],
};
