export const prova = [
  {
    text: "Se 2x + 3 = 11, qual é o valor de x?",
    options: ["3", "4", "7"],
    answer: 1,
    hint: "Subtraia 3 e divida por 2.",
  },
  {
    text: "Qual estrutura executa comandos enquanto uma condição for verdadeira?",
    options: ["while", "const", "return"],
    answer: 0,
    hint: "Em inglês: enquanto.",
  },
  {
    text: "Qual elemento HTML cria um link?",
    options: ["div", "a", "span"],
    answer: 1,
    hint: "Uma âncora leva a outra página.",
  },
  {
    text: "Um corpo de 2 kg acelera a 3 m/s². Qual a força resultante?",
    options: ["5 N", "6 N", "9 N"],
    answer: 1,
    hint: "F = massa × aceleração.",
  },
  {
    text: "Quantos átomos de hidrogênio há em H₂O?",
    options: ["1", "2", "3"],
    answer: 1,
    hint: "Observe o índice depois do H.",
  },
];
export const logica = [
  {
    text: "Se x = 4 e x > 3, qual mensagem aparece?",
    options: ["Verdadeiro", "Falso", "Erro"],
    answer: 0,
    hint: "4 é maior que 3.",
  },
  {
    text: "Observe: 2, 4, 8, 16. Qual é o próximo número?",
    options: ["18", "24", "32"],
    answer: 2,
    hint: "Cada número é o dobro do anterior.",
  },
  {
    text: "x = 0; enquanto x < 3: x = x + 1. Qual é o valor final de x?",
    options: ["2", "3", "4"],
    answer: 1,
    hint: "O laço termina quando x chega a 3.",
  },
];
export const preparacao = {
  testar: {
    text: "O botão de entrar chama abrirProjeto, mas a função se chama iniciarProjeto. Qual correção funciona?",
    options: ["Trocar só a cor", "Chamar iniciarProjeto", "Apagar o botão"],
    answer: 1,
  },
  revisar: {
    text: "Organize os tópicos da apresentação.",
    options: [
      "Problema → Solução → Benefícios",
      "Benefícios → Problema → Solução",
      "Solução → Benefícios → Problema",
    ],
    answer: 0,
  },
  ensaiar: {
    text: "Como explicar sua ideia para quem nunca viu o projeto?",
    options: [
      "Ler todo o código",
      "Falar só de bibliotecas",
      "Mostrar o problema e um exemplo simples",
    ],
    answer: 2,
  },
};
export const epa = [
  {
    text: "Qual problema o projeto de vocês procura resolver?",
    options: [
      "Uma dificuldade real que identificamos.",
      "A gente fez porque precisava entregar.",
      "É complicado explicar.",
    ],
    answer: 0,
  },
  {
    text: "Quem pode se beneficiar dessa solução?",
    options: [
      "Quem enfrenta o problema identificado.",
      "Só os desenvolvedores.",
      "Não pensamos nisso.",
    ],
    answer: 0,
  },
  {
    text: "Qual foi a maior dificuldade no desenvolvimento?",
    options: [
      "Integrar funcionalidades e testar.",
      "Escolher a cor do botão.",
      "Nenhuma. Foi tudo perfeito.",
    ],
    answer: 0,
  },
  {
    text: "O que melhorariam numa próxima versão?",
    options: [
      "Mais testes e retorno dos usuários.",
      "Nada. O sistema é perfeito.",
      "Talvez mudar o nome.",
    ],
    answer: 0,
  },
];
