export const configJogo = {
  project: {
    name: "Survive at ETEC",
    problem: "Acolher novos estudantes e compartilhar a experiência escolar.",
    solution: "Uma aventura narrativa sobre o primeiro ano.",
    benefit: "Aprender com escolhas e valorizar o trabalho em equipe.",
  },
  credits: {
    Desenvolvimento: [],
    Programação: [],
    Roteiro: [],
    "Arte e animação": [],
    "Design de som": [],
    Orientação: [],
    Agradecimentos: [],
  },
  colors: {
    ink: 0x11151f,
    navy: 0x1c2231,
    cream: 0xe7d6b8,
    gold: 0xf2cb78,
    blue: 0x4d739c,
    purple: 0x6c5b7b,
    red: 0xad4251,
  },
};
export const chapters = [
  "Faça amigos",
  "Sobreviva às provas",
  "A tentação da cola",
  "O EPA",
];
