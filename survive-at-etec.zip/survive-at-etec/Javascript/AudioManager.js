export class AudioManager {
  constructor(game, options) {
    this.game = game;
    this.options = options;
    this.current = null;
    this.name = null;
    this.muted = false;
    this.lastBlip = 0;
    this.fade = 0;
    game.events.on("step", (_time, delta) => {
      if (this.current) {
        this.fade = Math.min(
          1,
          this.fade + (Number.isFinite(delta) ? delta : 16) / 500,
        );
        this.current.setVolume(this.muted ? 0 : this.options.music * this.fade);
      }
    });
  }
  music(name) {
    if (this.name === name) return;
    this.stop();
    this.name = name;
    if (!this.game.cache.audio.exists("bgm-" + name)) return;
    this.current = this.game.sound.add("bgm-" + name, {
      loop: true,
      volume: 0,
    });
    this.fade = 0;
    this.current.play();
  }
  effect(name) {
    if (this.muted || !this.game.cache.audio.exists(name)) return;
    if (name.startsWith("dialogo")) {
      if (performance.now() - this.lastBlip < 85) return;
      this.lastBlip = performance.now();
    }
    this.game.sound.play(name, { volume: this.options.sfx });
  }
  apply() {
    if (this.current)
      this.current.setVolume(this.muted ? 0 : this.options.music);
  }
  stop() {
    this.name = null;
    if (this.current) {
      this.current.stop();
      this.current.destroy();
      this.current = null;
    }
  }
}
