export const characters = [
  "player",
  "lia",
  "niko",
  "bia",
  "professor-diogo",
  "tryhard",
  "jogador",
  "misterioso",
  "aluno",
  "avaliador",
];
export const maps = [
  "quarto",
  "rua",
  "fachada",
  "corredor",
  "sala",
  "laboratorio",
  "avaliacao",
  "preparacao",
  "epa",
  "entardecer",
  "noite",
];
export const themes = [
  "prologo",
  "menu",
  "primeiro-dia",
  "sala",
  "amizade",
  "rotina",
  "prova",
  "suspense",
  "cola",
  "preparacao",
  "epa",
  "final",
];
export const effects = [
  "dialogo-blip",
  "dialogo-professor",
  "dialogo-narrador",
  "menu-mover",
  "menu-confirmar",
  "menu-voltar",
  "passos",
  "porta",
  "sinal-escola",
  "ambiente-sala",
  "acerto",
  "erro",
  "rejeicao",
  "amizade",
  "relogio",
  "coracao",
  "alerta",
  "papel",
  "teclado",
  "sucesso",
  "game-over",
  "transicao",
  "aplausos",
];
export function loadAssets(scene) {
  for (const name of characters) {
    scene.load.spritesheet(name, "Assets/sprites/" + name + ".png", {
      frameWidth: 96,
      frameHeight: 96,
    });
    scene.load.image(
      name + "-retrato",
      "Assets/sprites/" + name + "-retrato.png",
    );
  }
  scene.load.spritesheet("player-acoes", "Assets/sprites/player-acoes.png", {
    frameWidth: 96,
    frameHeight: 96,
  });
  for (const name of [
    "sala",
    "corredor",
    "exterior",
    "quarto",
    "laboratorio",
    "epa",
  ])
    scene.load.image(name + "-tiles", "Assets/tiles/" + name + "-tiles.png");
  for (const name of maps)
    scene.load.tilemapTiledJSON(name, "Assets/maps/" + name + ".json");
  for (const name of themes)
    scene.load.audio("bgm-" + name, "Assets/audio/bgm-" + name + ".ogg");
  for (const name of effects)
    scene.load.audio(name, "Assets/audio/" + name + ".wav");
}
export function createAnimations(scene) {
  for (const name of characters)
    for (const [i, dir] of ["down", "left", "right", "up"].entries()) {
      const key = name + "-" + dir;
      if (!scene.anims.exists(key))
        scene.anims.create({
          key,
          frames: scene.anims.generateFrameNumbers(name, {
            start: i * 3,
            end: i * 3 + 2,
          }),
          frameRate: 7,
          repeat: -1,
        });
    }
}
