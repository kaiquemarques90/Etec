import { Base, line } from "./Base.js";
import { dialogos } from "../data/dialogos.js";
import { SaveManager } from "../SaveManager.js";
export class Cinematic extends Base {
  backdrop(map, { night = false } = {}) {
    if (this.backdropObjects) {
      for (const obj of this.backdropObjects) obj.destroy();
      this.backdropObjects = null;
    }
    const before = new Set(this.children.list);
    this.npcs = [];
    this.worldMap(map, {
      walk: false,
      npcs: ["sala", "epa", "preparacao", "laboratorio"].includes(map),
      tint: night ? { color: 0x111a38, alpha: 0.5 } : undefined,
    });
    this.backdropObjects = this.children.list.filter((o) => !before.has(o));
    this.prompt.setVisible(false);
    if (["fachada", "rua", "entardecer", "noite"].includes(map)) {
      const sign = this.add
        .text(480, 120, "ETEC\nSALES GOMES", {
          fontFamily: "monospace",
          fontSize: "14px",
          color: "#f2cb78",
          align: "center",
        })
        .setOrigin(0.5)
        .setDepth(3000);
      this.backdropObjects.push(sign);
    }
    this.hero = this.add
      .sprite(465, 335, "player", 1)
      .setScale(1 / 3)
      .setDepth(3001);
    this.backdropObjects.push(this.hero);
    if (map !== "quarto") {
      for (const [i, name] of ["lia", "niko", "bia"].entries()) {
        const s = this.add
          .sprite(505 + i * 35, 340 + i * 3, name, 1)
          .setScale(1 / 3)
          .setDepth(3001);
        this.backdropObjects.push(s);
      }
    }
    this.cameras.main.pan(480, 290, 1800, "Sine.easeInOut");
  }
  playScript(id, map, done) {
    this.backdrop(map);
    if (this.state.seen.includes(id)) {
      this.choice(
        "UMA LEMBRANÇA DO ANO",
        ["Assistir novamente", "Pular cena já vista"],
        (i) => (i === 1 ? done() : this.say(dialogos[id], () => done())),
      );
    } else
      this.say(dialogos[id], () => {
        this.state.seen.push(id);
        SaveManager.write(this.state);
        done();
      });
  }
}
export class Prologo extends Cinematic {
  constructor() {
    super("Prologo");
  }
  create() {
    this.setup();
    if (this.state.scene !== "Prologo") {
      this.scene.start("Titulo");
      return;
    }
    this.audio.music("prologo");
    const stars = this.add.graphics();
    for (let i = 0; i < 50; i++)
      stars
        .fillStyle(i % 2 ? 0xe7d6b8 : 0x6c5b7b, 0.4)
        .fillRect((i * 137) % 640, (i * 71) % 230, 1, 1);
    this.say(dialogos.prologo, () => {
      stars.destroy();
      this.playScript("quarto", "quarto", () => {
        this.audio.effect("sinal-escola");
        this.go("Titulo");
      });
    });
  }
}
export class CutsceneInicio extends Cinematic {
  constructor() {
    super("CutsceneInicio");
  }
  create() {
    this.setup();
    this.checkpoint();
    this.audio.music("primeiro-dia");
    const lines = dialogos.chegada;
    this.backdrop("rua");
    this.hero.play("player-right");
    this.tweens.add({
      targets: this.hero,
      x: 510,
      duration: 5000,
      onComplete: () => this.hero?.anims.stop(),
    });
    this.say(lines.slice(0, 9), () => {
      this.backdrop("corredor");
      this.audio.effect("porta");
      this.say(lines.slice(9, 15), () => {
        this.backdrop("sala");
        this.say(lines.slice(15), () =>
          this.go("TransicaoBimestre", {
            chapter: 1,
            next: "Bimestre1",
            subtitle: "Encontre alguém com quem passar o intervalo.",
          }),
        );
      });
    });
  }
}
export class CutsceneEPA extends Cinematic {
  constructor() {
    super("CutsceneEPA");
  }
  create() {
    this.setup();
    this.state.bimestre = 4;
    this.checkpoint();
    this.audio.music("preparacao");
    this.playScript("inicio4", "laboratorio", () =>
      this.go("TransicaoBimestre", {
        chapter: 4,
        next: "Bimestre4",
        subtitle: "Três amigos. Um projeto. Uma apresentação.",
      }),
    );
  }
}
export class Final extends Cinematic {
  constructor() {
    super("Final");
  }
  create() {
    this.setup();
    this.checkpoint();
    this.audio.music("final");
    this.playScript("final", "entardecer", () => {
      const extra =
        this.state.route === "cola"
          ? line(
              "PLAYER",
              "Da próxima vez eu quero confiar mais no que aprendi.",
            )
          : line("DIOGO", "Você aprendeu a pensar. É isso que importa.");
      this.say(
        [
          extra,
          line("NARRADOR", "FIM."),
          line("NARRADOR", "NÃO SABEMOS O QUE ACONTECERÁ DAQUI PARA FRENTE."),
          line("NARRADOR", "MAS SOBREVIVEMOS ATÉ AQUI."),
          line("NARRADOR", "OBRIGADO POR JOGAR SURVIVE AT ETEC."),
        ],
        () => {
          this.state.completed = true;
          this.go("Encerramento");
        },
      );
    });
  }
}
