import { Player } from "../Player.js";
import { DialogueBox } from "../dialogo.js";
import { HUD } from "../HUD.js";
import { SaveManager } from "../SaveManager.js";
export const line = (speaker, text) => ({ speaker, text });
export class Base extends Phaser.Scene {
  constructor(key) {
    super(key);
  }
  init(data = {}) {
    this.dataIn = data;
    this.state = this.game.registry.get("state");
    this.options = this.game.registry.get("options");
    this.audio = this.game.registry.get("audio");
    this.panel = null;
    this.paused = false;
    this.menuItems = [];
    this.menuIndex = 0;
    this.npcs = [];
    this.locked = false;
    this.checkpointed = false;
    this.player = null;
    this.hud = null;
    this.world = null;
    this.pausePanel = null;
    this.dialogue = null;
  }
  setup() {
    this.dialogue = new DialogueBox(this);
    const handle = (e) => {
      if (e.repeat) return;
      this.key(e);
    };
    this.input.keyboard.on("keydown", handle);
    this.events.once("shutdown", () => {
      this.input.keyboard.off("keydown", handle);
    });
    this.cameras.main.fadeIn(350, 17, 21, 31);
    document.getElementById("status").textContent =
      this.scene.key.toUpperCase();
  }
  checkpoint() {
    this.state.scene = this.scene.key;
    SaveManager.write(this.state);
    this.checkpointed = true;
  }
  go(scene, data) {
    this.player?.body.setVelocity(0);
    this.locked = true;
    this.cameras.main.fadeOut(320, 17, 21, 31);
    this.time.delayedCall(330, () => this.scene.start(scene, data));
  }
  say(lines, done) {
    this.dialogue.show(lines, done);
  }
  text(x, y, text, size = 12, color = "#e7d6b8") {
    return this.add
      .text(x, y, text, {
        fontFamily: "monospace",
        fontSize: size + "px",
        color,
        lineSpacing: 4,
      })
      .setScrollFactor(0);
  }
  worldMap(name, { walk = true, npcs = true, tint } = {}) {
    const map = this.make.tilemap({ key: name });
    const tiles = map.addTilesetImage(
      "escola",
      this.cache.tilemap
        .get(name)
        .data.tilesets[0].image.split("/")
        .pop()
        .replace(".png", ""),
    );
    map.createLayer("Piso", tiles).setDepth(-2);
    map.createLayer("Decoracao", tiles).setDepth(-1);
    this.world = map;
    this.physics.world.setBounds(
      32,
      32,
      map.widthInPixels - 64,
      map.heightInPixels - 64,
    );
    this.walls = this.physics.add.staticGroup();
    for (const obj of map.getObjectLayer("Colisoes").objects) {
      if (!obj.properties?.some((p) => p.name === "collides" && p.value))
        continue;
      const r = this.add.rectangle(
        obj.x + obj.width / 2,
        obj.y + obj.height / 2,
        obj.width,
        obj.height,
        0,
        0,
      );
      this.physics.add.existing(r, true);
      this.walls.add(r);
    }
    if (walk) {
      const spawn = map
        .getObjectLayer("Spawns")
        .objects.find((o) =>
          o.properties?.some(
            (p) => p.name === "spawnId" && p.value === "player",
          ),
        );
      this.player = new Player(this, spawn.x, spawn.y);
      this.physics.add.collider(this.player, this.walls);
      this.cameras.main.setBounds(0, 0, map.widthInPixels, map.heightInPixels);
      this.cameras.main.startFollow(this.player, true, 0.12, 0.12);
      this.cameras.main.setDeadzone(100, 70);
    } else {
      this.cameras.main.centerOn(480, 300);
      this.cameras.main.setBounds(0, 0, map.widthInPixels, map.heightInPixels);
    }
    if (npcs) {
      for (const o of map.getObjectLayer("Interacoes").objects) {
        const props = Object.fromEntries(
          (o.properties || []).map((p) => [p.name, p.value]),
        );
        const sprite = this.textures.exists(props.sprite)
          ? this.add
              .sprite(o.x, o.y, props.sprite, 1)
              .setScale(1 / 3)
              .setOrigin(0.5, 0.85)
          : null;
        if (sprite) {
          sprite.setDepth(o.y);
          this.tweens.add({
            targets: sprite,
            y: o.y - 1,
            duration: 1000,
            repeat: -1,
            yoyo: true,
          });
        }
        const label = this.add
          .text(o.x, o.y - 36, this.labelFor(props.interactionId), {
            fontFamily: "monospace",
            fontSize: "8px",
            color: "#252936",
            backgroundColor: "#efe0be",
            padding: { x: 4, y: 2 },
          })
          .setOrigin(0.5)
          .setDepth(o.y + 1);
        this.npcs.push({
          id: props.interactionId,
          x: o.x,
          y: o.y,
          sprite,
          label,
        });
        if (
          ["tryhards", "jogadores", "misteriosos", "amigos"].includes(
            props.interactionId,
          ) &&
          name === "sala"
        ) {
          const tex = {
            tryhards: "tryhard",
            jogadores: "jogador",
            misteriosos: "misterioso",
            amigos: "niko",
          }[props.interactionId];
          this.add
            .sprite(o.x - 28, o.y + 8, tex, 1)
            .setScale(1 / 3)
            .setDepth(o.y + 8)
            .setOrigin(0.5, 0.85);
          this.add
            .sprite(
              o.x + 28,
              o.y + 5,
              props.interactionId === "amigos" ? "bia" : tex,
              1,
            )
            .setScale(1 / 3)
            .setDepth(o.y + 5)
            .setOrigin(0.5, 0.85);
        }
      }
    }
    if (tint)
      this.add
        .rectangle(
          0,
          0,
          map.widthInPixels,
          map.heightInPixels,
          tint.color,
          tint.alpha,
        )
        .setOrigin(0)
        .setDepth(2000);
    this.prompt = this.add
      .text(320, 335, "WASD / setas · E conversar · ESC pausa", {
        fontFamily: "monospace",
        fontSize: "9px",
        color: "#e7d6b8",
        backgroundColor: "#11151fe8",
        padding: { x: 10, y: 6 },
      })
      .setOrigin(0.5)
      .setScrollFactor(0)
      .setDepth(3900);
    return map;
  }
  labelFor(id) {
    return (
      {
        tryhards: "TRYHARDS",
        jogadores: "JOGADORES",
        misteriosos: "MISTERIOSOS",
        amigos: "LIA · NIKO · BIA",
        diogo: "DIOGO",
        dormindo: "zzZ",
        escondido: "…",
        computador: "ERROR 404",
        estudar: "ESTUDAR",
        descansar: "DESCANSAR",
        exercicios: "EXERCÍCIOS",
        jogar: "JOGAR",
        dormir: "DORMIR CEDO",
        testar: "TESTAR",
        revisar: "REVISAR",
        ensaiar: "ENSAIAR",
        apresentar: "AVALIADORES",
      }[id] || id.toUpperCase()
    );
  }
  addHUD(title, objective) {
    this.hud = new HUD(this, title, objective);
  }
  button(x, y, label, callback, width = 280) {
    const bg = this.add
      .rectangle(0, 0, width, 27, 0x293044)
      .setOrigin(0.5)
      .setStrokeStyle(1, 0x4d5367);
    const text = this.add
      .text(0, 0, label, {
        fontFamily: "monospace",
        fontSize: "10px",
        color: "#e7d6b8",
        wordWrap: { width: width - 20 },
        align: "center",
      })
      .setOrigin(0.5);
    const c = this.add.container(x, y, [bg, text]).setScrollFactor(0);
    bg.setInteractive({ useHandCursor: true })
      .on("pointerover", () => bg.setFillStyle(0x44516a))
      .on("pointerout", () => bg.setFillStyle(0x293044))
      .on("pointerdown", () => {
        this.audio.effect("menu-confirmar");
        callback();
      });
    return { container: c, bg, text, callback };
  }
  choice(title, options, callback, { subtitle = "", y = 75 } = {}) {
    this.closePanel();
    this.panel = this.add.container(0, 0).setScrollFactor(0).setDepth(4600);
    this.panel.add(
      this.add.rectangle(0, 49, 640, 311, 0x11151f, 0.74).setOrigin(0),
    );
    this.panel.add(
      this.text(320, y, title, 14, "#f2cb78")
        .setWordWrapWidth(540)
        .setAlign("center")
        .setOrigin(0.5),
    );
    if (subtitle)
      this.panel.add(
        this.text(320, y + 34, subtitle, 10, "#c1bec9")
          .setWordWrapWidth(540)
          .setAlign("center")
          .setOrigin(0.5),
      );
    const top = y + (subtitle ? 70 : 48);
    this.menuItems = options.map((option, i) => {
      const b = this.button(
        320,
        top + i * 38,
        `${i + 1}. ${option}`,
        () => {
          this.closePanel();
          callback(i);
        },
        540,
      );
      this.panel.add(b.container);
      return b;
    });
    this.menuIndex = 0;
    this.highlight();
    this.panel.add(
      this.text(
        320,
        Math.min(338, top + options.length * 38),
        "↑ ↓ / 1–3 · ENTER confirmar · toque para escolher",
        8,
        "#9d9fac",
      ).setOrigin(0.5),
    );
  }
  closePanel() {
    this.panel?.destroy(true);
    this.panel = null;
    this.menuItems = [];
    this.menuIndex = 0;
  }
  highlight() {
    for (const [i, b] of this.menuItems.entries()) {
      b.bg.setFillStyle(i === this.menuIndex ? 0x4d5367 : 0x293044);
      b.text.setColor(i === this.menuIndex ? "#f2cb78" : "#e7d6b8");
    }
  }
  notice(text, good = true) {
    this.audio.effect(good ? "acerto" : "erro");
    const obj = this.text(320, 60, text, 10, good ? "#f2cb78" : "#f3a7ae")
      .setOrigin(0.5)
      .setDepth(4800)
      .setBackgroundColor("#11151f")
      .setPadding(8);
    this.tweens.add({
      targets: obj,
      alpha: 0,
      y: 50,
      duration: 1600,
      onComplete: () => obj.destroy(),
    });
  }
  key(e) {
    if (e.code === "Escape") {
      if (this.paused) this.resume();
      else this.pause();
      return;
    }
    if (this.paused) {
      this.pauseKey(e);
      return;
    }
    if (this.dialogue?.active) {
      if (e.code === "Enter" || e.code === "Space") this.dialogue.advance();
      return;
    }
    if (e.code === "Space" && this.breathe) {
      this.breathe();
      return;
    }
    if (this.menuItems.length) {
      if (e.code === "ArrowUp" || e.code === "ArrowDown") {
        this.menuIndex = Phaser.Math.Wrap(
          this.menuIndex + (e.code === "ArrowDown" ? 1 : -1),
          0,
          this.menuItems.length,
        );
        this.audio.effect("menu-mover");
        this.highlight();
      } else if (e.code === "Enter") {
        const callback = this.menuItems[this.menuIndex]?.callback;
        callback?.();
      } else if (/^Digit[1-9]$/.test(e.code)) {
        this.menuItems[Number(e.code.slice(-1)) - 1]?.callback();
      }
      return;
    }
    if (e.code === "KeyE" && this.near && !this.locked)
      this.interact(this.near.id);
    if (e.code === "Space") this.breathe?.();
    if (e.code === "KeyC") this.consult?.();
  }
  interact() {}
  pause() {
    this.paused = true;
    this.physics.world.pause();
    this.pausePanel = this.add
      .container(0, 0)
      .setScrollFactor(0)
      .setDepth(9000);
    this.pausePanel.add(
      this.add.rectangle(0, 0, 640, 360, 0x11151f, 0.96).setOrigin(0),
    );
    this.pausePanel.add(
      this.text(320, 34, "PAUSA · RESPIRE UM POUCO", 16, "#f2cb78").setOrigin(
        0.5,
      ),
    );
    const labels = [
      "Continuar",
      "Reiniciar checkpoint",
      `Música: ${Math.round(this.options.music * 100)}%`,
      `Efeitos: ${Math.round(this.options.sfx * 100)}%`,
      `Texto: ${this.options.textSpeed} ms / letra`,
      `Reduzir tremor: ${this.options.reduceShake ? "SIM" : "NÃO"}`,
      "Histórico de diálogo",
      "Voltar ao menu",
    ];
    this.pauseButtons = labels.map((label, i) => {
      const b = this.button(
        320,
        72 + i * 32,
        label,
        () => this.pauseAction(i),
        430,
      );
      this.pausePanel.add(b.container);
      return b;
    });
    this.pauseSelection = 0;
    this.pauseHighlight();
  }
  pauseAction(i) {
    if (i === 0) this.resume();
    if (i === 1) {
      const saved = SaveManager.read();
      if (saved) {
        this.game.registry.set("state", saved);
        this.state = saved;
      }
      this.resume();
      this.scene.start(saved?.scene || this.scene.key);
    }
    if (i === 2 || i === 3) {
      const key = i === 2 ? "music" : "sfx";
      this.options[key] = Math.round((this.options[key] + 0.1) * 100) / 100;
      if (this.options[key] > 1) this.options[key] = 0;
      this.audio.apply();
      SaveManager.saveOptions(this.options);
      this.pauseButtons[i].text.setText(
        (i === 2 ? "Música" : "Efeitos") +
          ": " +
          Math.round(this.options[key] * 100) +
          "%",
      );
    }
    if (i === 4) {
      this.options.textSpeed =
        this.options.textSpeed === 24
          ? 12
          : this.options.textSpeed === 12
            ? 40
            : 24;
      SaveManager.saveOptions(this.options);
      this.pauseButtons[i].text.setText(
        "Texto: " + this.options.textSpeed + " ms / letra",
      );
    }
    if (i === 5) {
      this.options.reduceShake = !this.options.reduceShake;
      SaveManager.saveOptions(this.options);
      this.pauseButtons[i].text.setText(
        "Reduzir tremor: " + (this.options.reduceShake ? "SIM" : "NÃO"),
      );
    }
    if (i === 6) {
      const recent = this.state.history
        .slice(-6)
        .map((l) => l.speaker + ": " + l.text)
        .join("\n");
      this.pausePanel.setVisible(false);
      this.historyOverlay = this.add
        .container(0, 0)
        .setScrollFactor(0)
        .setDepth(9500);
      this.historyOverlay.add(
        this.add.rectangle(0, 0, 640, 360, 0x11151f, 0.98).setOrigin(0),
      );
      const t = this.text(
        24,
        34,
        recent || "Ainda não há falas registradas.",
        11,
      );
      t.setWordWrapWidth(590);
      this.historyOverlay.add(t);
      const b = this.button(320, 325, "VOLTAR", () => {
        this.historyOverlay.destroy(true);
        this.historyOverlay = null;
        this.pausePanel.setVisible(true);
      });
      this.historyOverlay.add(b.container);
    }
    if (i === 7) {
      this.resume();
      this.scene.start("Titulo");
    }
  }
  pauseKey(e) {
    if (this.historyOverlay) {
      if (e.code === "Enter") {
        this.historyOverlay.destroy(true);
        this.historyOverlay = null;
        this.pausePanel.setVisible(true);
      }
      return;
    }
    if (e.code === "ArrowDown" || e.code === "ArrowUp") {
      this.pauseSelection = Phaser.Math.Wrap(
        this.pauseSelection + (e.code === "ArrowDown" ? 1 : -1),
        0,
        8,
      );
      this.pauseHighlight();
    }
    if (e.code === "Enter") this.pauseAction(this.pauseSelection);
  }
  pauseHighlight() {
    this.pauseButtons.forEach((b, i) =>
      b.bg.setFillStyle(i === this.pauseSelection ? 0x4d5367 : 0x293044),
    );
  }
  resume() {
    this.paused = false;
    this.pausePanel?.destroy(true);
    this.pausePanel = null;
    this.historyOverlay?.destroy(true);
    this.historyOverlay = null;
    this.physics.world.resume();
  }
  update(time, delta) {
    if (this.paused) return;
    this.dialogue?.update(delta);
    const locked = this.locked || this.dialogue?.active || !!this.panel;
    this.player?.update(locked);
    if (this.player && !locked) {
      this.near = this.npcs
        .filter(
          (n) =>
            Phaser.Math.Distance.Between(
              this.player.x,
              this.player.y,
              n.x,
              n.y,
            ) < 65,
        )
        .sort(
          (a, b) =>
            Phaser.Math.Distance.Between(
              this.player.x,
              this.player.y,
              a.x,
              a.y,
            ) -
            Phaser.Math.Distance.Between(
              this.player.x,
              this.player.y,
              b.x,
              b.y,
            ),
        )[0];
      this.prompt.setText(
        this.near
          ? "[ E ] " + this.labelFor(this.near.id) + " · conversar / interagir"
          : "WASD / setas · E interagir · ESC pausa",
      );
    }
    this.tick?.(delta / 1000);
  }
}
