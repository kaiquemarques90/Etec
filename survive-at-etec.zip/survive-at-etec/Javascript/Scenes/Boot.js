import { loadAssets, createAnimations } from "../AssetLoader.js";
export class Boot extends Phaser.Scene {
  constructor() {
    super("Boot");
  }
  preload() {
    const title = this.add
      .text(320, 135, "PREPARANDO O PRIMEIRO DIA…", {
        fontFamily: "monospace",
        fontSize: "13px",
        color: "#f2cb78",
      })
      .setOrigin(0.5);
    const bar = this.add.rectangle(170, 175, 0, 5, 0xf2cb78).setOrigin(0);
    this.load.on("progress", (v) => (bar.width = 300 * v));
    this.load.on("loaderror", (file) => {
      console.error("Asset falhou", file.src);
      title.setText("Não foi possível carregar: " + file.key);
    });
    loadAssets(this);
  }
  create() {
    createAnimations(this);
    this.scene.start("Prologo");
  }
}
