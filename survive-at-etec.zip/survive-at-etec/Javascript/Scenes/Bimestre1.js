import { Base, line } from "./Base.js";
import { dialogos } from "../data/dialogos.js";
import { SaveManager } from "../SaveManager.js";
export class Bimestre1 extends Base {
  constructor() {
    super("Bimestre1");
  }
  create() {
    this.setup();
    this.state.bimestre = 1;
    this.checkpoint();
    this.worldMap("sala");
    this.audio.music("sala");
    this.addHUD(
      "1º BIMESTRE · FAÇA AMIGOS",
      "Conheça os três grupos. Depois encontre sua turma.",
    );
    this.refresh();
    this.say([
      line("NARRADOR", "Seu primeiro desafio não será uma prova."),
      line("NARRADOR", "Será encontrar alguém com quem passar o intervalo."),
    ]);
  }
  refresh() {
    this.hud.update(
      `GRUPOS CONHECIDOS: ${this.state.known.length}/3\nAMIZADE: ${this.state.friendship}`,
    );
    for (const npc of this.npcs)
      if (this.state.known.includes(npc.id))
        npc.label.setText("✓ " + this.labelFor(npc.id));
  }
  interact(id) {
    if (["tryhards", "jogadores", "misteriosos"].includes(id)) {
      if (this.state.known.includes(id)) {
        this.say([
          line("PLAYER", "Melhor procurar outro grupo. Eles já responderam."),
        ]);
        return;
      }
      this.say(dialogos[id], () => {
        this.state.known.push(id);
        SaveManager.write(this.state);
        this.audio.effect("rejeicao");
        this.refresh();
      });
    } else if (id === "amigos") {
      if (this.state.known.length < 3) {
        this.say([
          line("LIA", "Ei! Você é o aluno novo, né?"),
          line(
            "LIA",
            "Pode conhecer a sala primeiro. A gente guarda um lugar pra você.",
          ),
          line("BIA", "E se os outros grupos forem estranhos, não é você."),
        ]);
        return;
      }
      this.say(dialogos.amigos, () =>
        this.choice(
          "VOCÊ GOSTA DE FAZER O QUÊ?",
          [
            "Programação e tecnologia.",
            "Jogos e música.",
            "Eu ainda tô descobrindo.",
          ],
          (i) => {
            this.state.interest = i;
            const reactions = [
              [
                line("NIKO", "Então você vai se dar bem com a gente."),
                line(
                  "BIA",
                  "Principalmente quando nossos códigos pararem de funcionar.",
                ),
              ],
              [
                line("BIA", "Perfeito."),
                line("NIKO", "Já temos assunto pro intervalo inteiro."),
              ],
              [
                line(
                  "LIA",
                  "Melhor ainda. Tem um monte de coisa pra descobrir aqui.",
                ),
              ],
            ][i];
            this.say(
              [
                ...reactions,
                line("LIA", "Enfim, seja bem-vindo."),
                line("NIKO", "Agora você faz parte do grupo."),
                line("BIA", "Infelizmente."),
                line("PLAYER", "Infelizmente?"),
                line("BIA", "Você vai entender."),
              ],
              () => {
                this.state.friendship = 1;
                this.audio.music("amizade");
                this.audio.effect("amizade");
                this.refresh();
                this.say(dialogos.fim1, () =>
                  this.go("TransicaoBimestre", {
                    chapter: 2,
                    next: "Bimestre2",
                    subtitle: "Você fez amigos. Agora vêm as provas.",
                  }),
                );
              },
            );
          },
        ),
      );
    } else {
      const ambient = {
        diogo: [
          line("DIOGO", "Alguma dúvida?"),
          line("PLAYER", "Por enquanto, não."),
          line("DIOGO", "Ótimo. Guarde essa sensação."),
        ],
        dormindo: [
          line("PLAYER", "Ele tá dormindo?"),
          line("ALUNO", "Não. Tá compilando."),
        ],
        escondido: [
          line("PLAYER", "Por que você tá aí?"),
          line("ALUNO", "Você já viu a quantidade de matéria?"),
          line("PLAYER", "Ainda não."),
          line("ALUNO", "Então entra também."),
        ],
        computador: [
          line("ALUNO", "Meu código funcionava ontem."),
          line("PLAYER", "E hoje?"),
          line("ALUNO", "Hoje é outro dia."),
        ],
      };
      this.say(
        ambient[id] || [line("PLAYER", "Cada pessoa tem uma história aqui.")],
      );
    }
  }
}
