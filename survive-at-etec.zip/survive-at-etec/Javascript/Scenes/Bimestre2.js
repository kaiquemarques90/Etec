import { Base, line } from "./Base.js";
import { Cinematic } from "./Cinematic.js";
import { dialogos } from "../data/dialogos.js";
import {
  applyRoutine,
  routineActions,
  mention,
  examSeconds,
} from "../GameState.js";
import { SaveManager } from "../SaveManager.js";
import { prova } from "../data/questoes.js";
export class Bimestre2 extends Base {
  constructor() {
    super("Bimestre2");
  }
  create() {
    this.setup();
    this.state.bimestre = 2;
    this.checkpoint();
    this.worldMap("quarto");
    this.audio.music("rotina");
    this.addHUD(
      "2º BIMESTRE · TRÊS DIAS ANTES DA PROVA",
      "E nos objetos · planeje estudo e descanso.",
    );
    this.refresh();
    if (!this.state.seen.includes("inicio2"))
      this.say(dialogos.inicio2, () => {
        this.state.seen.push("inicio2");
        SaveManager.write(this.state);
        this.showActions();
      });
    else this.showActions();
  }
  refresh() {
    const r = this.state.routine;
    this.hud.update(
      `DIA ${Math.min(r.day, 3)}/3 · ${r.actions} AÇÕES\nENERGIA ${r.energy} · PREPARO ${r.preparation} · ESTRESSE ${r.stress}`,
    );
  }
  showActions() {
    if (this.state.routine.day > 3) {
      this.go("Prova");
      return;
    }
    this.choice(
      `DIA ${this.state.routine.day} · ${this.state.routine.actions} AÇÕES RESTANTES`,
      [
        "Estudar · +20 preparo, −15 energia",
        "Descansar · +25 energia, −10 estresse",
        "Outras atividades",
      ],
      (i) => {
        if (i < 2) this.doAction(i === 0 ? "estudar" : "descansar");
        else this.otherActions();
      },
      { subtitle: "Equilibre energia, preparação e estresse." },
    );
  }
  otherActions() {
    this.choice(
      "COMO USAR ESSE TEMPO?",
      [
        "Exercícios · +10 preparo, −10 energia",
        "Conversar com amigos · −15 estresse",
        "Jogar / dormir cedo",
      ],
      (i) => {
        if (i < 2) this.doAction(i === 0 ? "exercicios" : "amigos");
        else
          this.choice(
            "UMA PAUSA?",
            [
              "Jogar · +15 energia",
              "Dormir cedo · encerrar o dia",
              "Voltar às atividades",
            ],
            (j) =>
              j === 2
                ? this.showActions()
                : this.doAction(j === 0 ? "jogar" : "dormir"),
          );
      },
    );
  }
  interact(id) {
    if (routineActions[id]) this.doAction(id);
  }
  doAction(action) {
    this.state.routine = applyRoutine(this.state.routine, action);
    SaveManager.write(this.state);
    this.refresh();
    const texts = {
      estudar: "Se eu entender isso agora, talvez não sofra amanhã.",
      descansar: "Cinco minutinhos…",
      exercicios: "Prática é diferente de só ler.",
      amigos: "A Lia disse que a gente pode estudar junto.",
      jogar: "Só uma partida.",
      dormir: "Hoje meu cérebro já fechou o expediente.",
    };
    const lines = [line("PLAYER", texts[action])];
    if (action === "jogar")
      lines.push(line("NARRADOR", "Três partidas depois…"));
    if (this.state.routine.energy < 25)
      lines.push(line("PLAYER", "Meu cérebro tá rodando a 2 FPS."));
    if (this.state.routine.preparation >= 80)
      lines.push(line("PLAYER", "Tá. Acho que finalmente entendi."));
    this.say(lines, () => {
      if (this.state.routine.day > 3)
        this.say(
          [line("NARRADOR", "Chegou a hora. A prova sempre chega.")],
          () => this.go("Prova"),
        );
      else this.showActions();
    });
  }
}
export class Prova extends Cinematic {
  constructor() {
    super("Prova");
  }
  create() {
    this.setup();
    this.checkpoint();
    this.backdrop("avaliacao");
    this.audio.music("prova");
    this.addHUD("2º BIMESTRE · A PROVA", "1, 2, 3 / setas · ENTER confirmar");
    this.score = 100;
    this.question = 0;
    this.timer = examSeconds(this.state.routine);
    this.finished = false;
    this.say(
      [
        line("DIOGO", "Guardem os materiais. Podem começar."),
        line(
          "NARRADOR",
          "Menções fictícias do jogo: MB ≥80, B ≥60, R ≥40, I <40.",
        ),
      ],
      () => this.ask(),
    );
  }
  ask() {
    this.timer = examSeconds(this.state.routine);
    const q = prova[this.question];
    this.choice(q.text, q.options, (i) => this.answer(i), {
      subtitle:
        this.state.routine.preparation >= 60
          ? "DICA: " + q.hint
          : "Lembre-se do que estudou.",
      y: 90,
    });
    this.refresh();
  }
  refresh() {
    this.hud.update(
      `MENÇÃO ${mention(this.score)} · QUESTÃO ${this.question + 1}/5\nTEMPO ${Math.ceil(this.timer)}s · PREPARO ${this.state.routine.preparation}`,
    );
  }
  answer(i) {
    if (this.finished) return;
    const q = prova[this.question];
    const right = i === q.answer;
    if (i === -1) this.score -= 10;
    else if (!right) this.score -= 20;
    this.closePanel();
    this.notice(
      i === -1
        ? "TEMPO ESGOTADO · −10"
        : right
          ? "✓ Resposta registrada."
          : "× Você não tem tanta certeza…",
      right,
    );
    if (!right && !this.options.reduceShake) this.cameras.main.shake(90, 0.002);
    this.question++;
    if (this.question < prova.length) {
      this.time.delayedCall(800, () => this.ask());
    } else this.result();
  }
  tick(dt) {
    if (!this.panel || this.dialogue.active || this.finished) return;
    this.timer = Math.max(0, this.timer - dt);
    this.refresh();
    if (this.timer === 0) this.answer(-1);
  }
  result() {
    this.finished = true;
    this.state.examScore = this.score;
    const m = mention(this.score);
    if (m === "I") {
      this.audio.effect("game-over");
      this.say(
        [
          line("NARRADOR", "Você descobriu uma nova palavra: recuperação."),
          line("DIOGO", "Vamos precisar conversar sobre essa prova."),
        ],
        () =>
          this.choice(
            "MENÇÃO I · NOVA CHANCE",
            ["Tentar a prova novamente"],
            () => this.scene.restart(),
          ),
      );
      return;
    }
    SaveManager.write(this.state);
    const results = {
      MB: [
        line("PLAYER", "EU CONSEGUI!"),
        line("LIA", "Sabia que você ia conseguir."),
        line("BIA", "Agora só faltam as próximas."),
        line("PLAYER", "Não estraga o momento."),
      ],
      B: [
        line("PLAYER", "Tá ótimo, na verdade."),
        line("NIKO", "Passamos por mais uma."),
      ],
      R: [
        line("PLAYER", "Isso foi por pouco."),
        line("LIA", "Na próxima a gente estuda junto."),
      ],
    };
    this.say(
      [
        ...results[m],
        line(
          "NARRADOR",
          "Você aprendeu a administrar seu tempo. Mais ou menos.",
        ),
        line("NARRADOR", "O próximo bimestre não será mais fácil."),
      ],
      () =>
        this.go("TransicaoBimestre", {
          chapter: 3,
          next: "Bimestre3",
          subtitle: "Mais uma prova. Uma escolha difícil.",
        }),
    );
  }
}
