import { Cinematic } from "./Cinematic.js";
import { newState } from "../GameState.js";
import { SaveManager } from "../SaveManager.js";
import { configJogo } from "../data/configJogo.js";
export class Titulo extends Cinematic {
  constructor() {
    super("Titulo");
  }
  create() {
    this.setup();
    this.audio.music("menu");
    this.backdrop("fachada");
    this.hero.setVisible(false);
    this.add
      .rectangle(0, 0, 640, 360, 0x11151f, 0.38)
      .setOrigin(0)
      .setScrollFactor(0)
      .setDepth(3500);
    this.text(320, 48, "SURVIVE", 34, "#f2cb78")
      .setOrigin(0.5)
      .setDepth(4000)
      .setStroke("#11151f", 5);
    this.text(320, 85, "AT ETEC", 34, "#f2f2f2")
      .setOrigin(0.5)
      .setDepth(4000)
      .setStroke("#11151f", 5);
    this.text(320, 116, "Um ano. Quatro bimestres. Boa sorte.", 10)
      .setOrigin(0.5)
      .setDepth(4000);
    this.panel = this.add.container(0, 0).setDepth(4600).setScrollFactor(0);
    const saved = SaveManager.read();
    const labels = [
      "COMEÇAR",
      saved ? "CONTINUAR" : "CONTINUAR · sem progresso",
      "OPÇÕES",
      "CRÉDITOS",
    ];
    this.menuItems = labels.map((label, i) => {
      const b = this.button(
        320,
        164 + i * 35,
        label,
        () => this.select(i),
        265,
      );
      this.panel.add(b.container);
      if (i === 1 && !saved) b.text.setAlpha(0.35);
      return b;
    });
    this.highlight();
    this.text(
      320,
      321,
      "↑ ↓ ENTER / toque · original, feito para o EPA",
      8,
      "#c6c1bf",
    )
      .setOrigin(0.5)
      .setDepth(4000);
    this.addClouds();
  }
  addClouds() {
    for (let i = 0; i < 4; i++) {
      const cloud = this.add.graphics().setScrollFactor(0).setDepth(0);
      cloud
        .fillStyle(0xe7d6b8, 0.15)
        .fillRect(0, 0, 48, 5)
        .fillRect(9, -4, 30, 5);
      cloud.setPosition(i * 180, 20 + (i % 2) * 18);
      this.tweens.add({
        targets: cloud,
        x: "+=80",
        duration: 30000,
        repeat: -1,
        yoyo: true,
      });
    }
  }
  select(i) {
    if (i === 0) {
      if (SaveManager.read()?.scene !== "Prologo" && SaveManager.read()) {
        this.choice(
          "COMEÇAR UM NOVO ANO?",
          ["Novo jogo · substituir checkpoint", "Voltar"],
          (choice) => {
            if (choice === 0) this.startNew();
            else this.scene.restart();
          },
        );
      } else this.startNew();
    }
    if (i === 1) {
      const saved = SaveManager.read();
      if (saved) {
        this.game.registry.set("state", saved);
        this.go(saved.scene);
      }
    }
    if (i === 2) this.pause();
    if (i === 3) this.go("Creditos", { returnTo: "Titulo" });
  }
  startNew() {
    const state = newState();
    this.game.registry.set("state", state);
    SaveManager.write(state);
    this.audio.effect("sinal-escola");
    this.go("CutsceneInicio");
  }
}
export class TransicaoBimestre extends Cinematic {
  constructor() {
    super("TransicaoBimestre");
  }
  create() {
    this.setup();
    this.audio.effect("transicao");
    const { chapter, next, subtitle } = this.dataIn;
    this.text(320, 80, "UM ANO PARA CONTAR", 9, "#a8a0b2").setOrigin(0.5);
    this.text(
      320,
      128,
      String(chapter).padStart(2, "0"),
      62,
      "#6c5b7b",
    ).setOrigin(0.5);
    this.text(320, 190, `${chapter}º BIMESTRE`, 23, "#f2cb78").setOrigin(0.5);
    this.text(320, 230, subtitle || "Você chegou até aqui.", 11).setOrigin(0.5);
    this.choice("", ["CONTINUAR"], () => this.go(next), { y: 245 });
  }
}
export class Encerramento extends Cinematic {
  constructor() {
    super("Encerramento");
  }
  create() {
    this.setup();
    this.state.completed = true;
    this.checkpoint();
    this.audio.music("final");
    this.backdrop("noite", { night: true });
    this.hero.setFrame(10);
    for (const obj of this.backdropObjects)
      if (obj.texture && ["lia", "niko", "bia"].includes(obj.texture.key))
        obj.setFrame(10);
    this.text(320, 40, "SURVIVE AT ETEC", 24, "#f2cb78")
      .setOrigin(0.5)
      .setDepth(4000)
      .setStroke("#11151f", 5);
    this.text(320, 76, "FIM DO PRIMEIRO ANO", 10).setOrigin(0.5).setDepth(4000);
    this.choice(
      "MAS SOBREVIVEMOS ATÉ AQUI.",
      ["CONHECER NOSSO PROJETO", "JOGAR NOVAMENTE", "CRÉDITOS"],
      (i) => {
        if (i === 0) this.game.events.emit("project");
        if (i === 1) {
          this.game.registry.set("state", newState());
          this.go("Prologo");
        }
        if (i === 2) this.go("Creditos", { returnTo: "Encerramento" });
      },
      {
        y: 120,
        subtitle: `Amizade: ${this.state.friendship} · Prova: ${this.state.examScore ?? "—"} · EPA: ${this.state.presentation?.confidence ?? "—"}`,
      },
    );
  }
}
export class Creditos extends Cinematic {
  constructor() {
    super("Creditos");
  }
  create() {
    this.setup();
    this.audio.music("final");
    this.text(320, 32, "QUEM FEZ ESSA HISTÓRIA", 17, "#f2cb78").setOrigin(0.5);
    Object.entries(configJogo.credits).forEach(([category, names], i) => {
      this.text(44, 70 + i * 25, category, 11, "#b4a4c2");
      this.text(
        290,
        70 + i * 25,
        names.length ? names.join(", ") : "Equipe · a preencher",
        10,
      );
    });
    this.text(
      320,
      267,
      "Feito por estudantes que ainda estão\ntentando sobreviver à ETEC.",
      10,
    ).setOrigin(0.5);
    this.choice(
      "",
      ["VOLTAR"],
      () => this.go(this.dataIn.returnTo || "Titulo"),
      { y: 280 },
    );
  }
}
