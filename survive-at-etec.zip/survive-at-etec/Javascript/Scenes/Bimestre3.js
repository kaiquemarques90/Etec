import { Cinematic } from "./Cinematic.js";
import { line } from "./Base.js";
import { dialogos } from "../data/dialogos.js";
import { logica } from "../data/questoes.js";
import { updateRisk, breathe, clamp } from "../GameState.js";
import { SaveManager } from "../SaveManager.js";
export class Bimestre3 extends Cinematic {
  constructor() {
    super("Bimestre3");
  }
  create() {
    this.setup();
    this.state.bimestre = 3;
    this.checkpoint();
    this.audio.music("suspense");
    this.backdrop("avaliacao");
    this.say(dialogos.inicio3, () => this.chooseRoute());
  }
  chooseRoute() {
    this.choice(
      "COMO ENFRENTAR A AVALIAÇÃO?",
      ["Tentar resolver com o que sabe.", "Usar a cola escondida."],
      (i) => {
        this.state.route = i === 0 ? "honesta" : "cola";
        SaveManager.write(this.state);
        this.go(i === 0 ? "RotaHonesta" : "RotaCola");
      },
      {
        subtitle: "Você pode vencer sem colar. Toda escolha tem consequências.",
      },
    );
  }
}
class Assessment extends Cinematic {
  create() {
    this.setup();
    this.checkpoint();
    this.backdrop("avaliacao");
    this.audio.music(this.scene.key === "RotaCola" ? "cola" : "prova");
    this.question = 0;
    this.correct = 0;
    this.finished = false;
    this.addHUD(
      "3º BIMESTRE · A AVALIAÇÃO",
      "Resolva três desafios de lógica.",
    );
  }
  complete() {
    this.finished = true;
    this.closePanel();
    if (this.correct < 2) {
      this.say(
        [
          line(
            "DIOGO",
            "Vamos revisar com calma. Aprender também é tentar de novo.",
          ),
        ],
        () =>
          this.choice(
            "MAIS UMA CHANCE",
            ["Repetir avaliação", "Escolher outra rota"],
            (i) => (i === 0 ? this.scene.restart() : this.go("Bimestre3")),
          ),
      );
      return;
    }
    const route =
      this.state.route === "cola"
        ? [
            line("PLAYER", "Consegui… acho que perdi uns cinco anos de vida."),
            line("NARRADOR", "Talvez não tenha sido sua melhor decisão."),
          ]
        : [
            line(
              "PLAYER",
              "Talvez eu não soubesse tudo… mas consegui resolver.",
            ),
            line("DIOGO", "É assim que se aprende."),
          ];
    SaveManager.write(this.state);
    this.say(route, () => {
      this.backdrop("corredor");
      this.say(dialogos.fim3, () => this.go("CutsceneEPA"));
    });
  }
}
export class RotaHonesta extends Assessment {
  constructor() {
    super("RotaHonesta");
  }
  create() {
    super.create();
    this.state.route = "honesta";
    this.say([line("PLAYER", "Vamos pensar. Uma coisa de cada vez.")], () =>
      this.ask(),
    );
  }
  ask() {
    const q = logica[this.question];
    this.choice(
      q.text,
      q.options,
      (i) => {
        this.correct += i === q.answer ? 1 : 0;
        this.notice(
          i === q.answer ? "✓ Confiança +1" : "× Respire e pense no próximo.",
          i === q.answer,
        );
        this.question++;
        if (this.question < 3) this.time.delayedCall(800, () => this.ask());
        else this.complete();
      },
      {
        subtitle:
          this.state.examScore >= 80
            ? "Você lembra das aulas. " + q.hint
            : "Sem pressa. O raciocínio vale mais que o medo.",
        y: 95,
      },
    );
    this.hud.update(
      `QUESTÃO ${this.question + 1}/3\nCONFIANÇA ${this.correct}/3`,
    );
  }
}
export class RotaCola extends Assessment {
  constructor() {
    super("RotaCola");
  }
  create() {
    super.create();
    this.state.route = "cola";
    this.risk = { suspicion: 10, nervous: 35 };
    this.elapsed = 0;
    this.cooldown = 0;
    this.holding = false;
    this.teacher = this.add
      .sprite(390, 190, "professor-diogo", 7)
      .setScale(1 / 3)
      .setDepth(3200);
    this.eye = this.text(320, 62, "DIOGO OLHANDO PARA O QUADRO", 10, "#a1c5ae")
      .setOrigin(0.5)
      .setDepth(4700);
    this.riskText = this.text(320, 313, "", 9, "#f2cb78")
      .setOrigin(0.5)
      .setDepth(4700);
    this.consultKey = this.input.keyboard.addKey("C");
    this.say(
      [
        line("PLAYER", "Tá. Só uma olhadinha."),
        line(
          "NARRADOR",
          "SEGURE C para consultar. SOLTE C para esconder. ESPAÇO respira (5s de recarga). Observe o professor.",
        ),
      ],
      () => this.ask(),
    );
  }
  ask() {
    this.clue?.destroy();
    const q = logica[this.question];
    this.choice(
      q.text,
      q.options,
      (i) => {
        this.correct += i === q.answer ? 1 : 0;
        this.notice(
          i === q.answer
            ? "✓ Resposta registrada."
            : "× Essa resposta não parece certa.",
          i === q.answer,
        );
        this.question++;
        if (this.question < 3) this.time.delayedCall(800, () => this.ask());
        else this.complete();
      },
      {
        subtitle:
          "C segurar: pista · ESPAÇO: respirar · sem obrigação de consultar",
        y: 95,
      },
    );
    this.clue = this.text(320, 282, "[ COLA ESCONDIDA ]", 10, "#c2bbcb")
      .setOrigin(0.5)
      .setDepth(4800);
  }
  breathe() {
    if (this.cooldown > 0 || this.dialogue.active || this.finished) return;
    this.risk = breathe(this.risk);
    this.cooldown = 5;
    this.audio.effect("coracao");
    this.notice("Respiração · nervosismo −20");
  }
  tick(dt) {
    if (this.finished || this.dialogue.active || !this.panel) return;
    this.elapsed += dt;
    this.cooldown = Math.max(0, this.cooldown - dt);
    const phase = this.elapsed % 10;
    this.watching = phase >= 5;
    const warning = phase >= 4 && phase < 5;
    const consulting = this.consultKey.isDown;
    this.teacher.x = 390 + Math.sin(this.elapsed * 0.55) * 90;
    this.teacher.setFrame(this.watching ? 1 : 10);
    this.eye.setText(
      warning
        ? "! DIOGO VAI OLHAR · ESCONDA"
        : this.watching
          ? "◉ DIOGO OBSERVANDO · ESCONDA"
          : "○ DIOGO NO QUADRO · janela de 5s",
    );
    this.eye.setColor(this.watching ? "#f2a1ae" : "#c4d6bd");
    this.risk = updateRisk(this.risk, dt, consulting, this.watching);
    if (this.risk.nervous >= 90 && consulting)
      this.risk.suspicion = clamp(this.risk.suspicion + dt * 5);
    this.clue?.setText(
      consulting
        ? "PISTA: " + (logica[this.question]?.hint || "")
        : "[ COLA ESCONDIDA ]",
    );
    this.riskText.setText(
      `SUSPEITA ${Math.round(this.risk.suspicion)}/100 · NERVOSISMO ${Math.round(this.risk.nervous)}/100 · RESPIRAR ${this.cooldown > 0 ? Math.ceil(this.cooldown) + "s" : "PRONTO"}`,
    );
    this.hud.update(
      `QUESTÕES ${this.question}/3\n${this.state.caught ? "Já houve um flagrante." : ""}`,
    );
    if (this.risk.suspicion >= 100) this.caught();
  }
  caught() {
    this.finished = true;
    this.state.caught = true;
    SaveManager.write(this.state);
    this.closePanel();
    this.clue?.destroy();
    this.audio.stop();
    this.audio.effect("alerta");
    this.say(
      [
        line("DIOGO", "Posso saber o que você está fazendo?"),
        line("PLAYER", "…"),
        line("DIOGO", "Guarde isso. Depois conversamos."),
      ],
      () =>
        this.choice(
          "VOCÊ FOI DESCOBERTO",
          ["Voltar ao checkpoint · escolher outra rota"],
          () => this.go("Bimestre3"),
        ),
    );
  }
  complete() {
    this.clue?.destroy();
    super.complete();
  }
}
