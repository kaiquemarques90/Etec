import { Base, line } from "./Base.js";
import { Cinematic } from "./Cinematic.js";
import { dialogos } from "../data/dialogos.js";
import { preparacao, epa } from "../data/questoes.js";
import { configJogo } from "../data/configJogo.js";
import { clamp } from "../GameState.js";
import { SaveManager } from "../SaveManager.js";
export class Bimestre4 extends Base {
  constructor() {
    super("Bimestre4");
  }
  create() {
    this.setup();
    this.checkpoint();
    this.worldMap("preparacao");
    this.audio.music("preparacao");
    this.addHUD(
      "4º BIMESTRE · PREPARAR O EPA",
      "E: testar o projeto, revisar os tópicos, ensaiar.",
    );
    this.refresh();
    if (this.state.epaTasks.length === 3) this.toEPA();
    else
      this.say([
        line("LIA", "Precisamos terminar o projeto."),
        line(
          "NIKO",
          this.state.interest === 0
            ? "Você curte tecnologia. Vamos testar juntos?"
            : "Eu fiz a parte visual.",
        ),
        line("BIA", "Eu organizei a apresentação."),
        line("PLAYER", "E eu?"),
        line("NIKO", "Você vai explicar o sistema."),
        line("BIA", "Boa sorte."),
      ]);
  }
  refresh() {
    this.hud.update(
      `TAREFAS ${this.state.epaTasks.length}/3\nPREPARAÇÃO EPA ${this.state.epaPreparation}/100`,
    );
    for (const npc of this.npcs)
      if (this.state.epaTasks.includes(npc.id))
        npc.label.setText("✓ " + this.labelFor(npc.id));
  }
  interact(id) {
    if (["testar", "revisar", "ensaiar"].includes(id)) {
      if (this.state.epaTasks.includes(id)) {
        this.say([
          line("LIA", "Essa parte já está pronta. Vamos cuidar das outras."),
        ]);
        return;
      }
      const q = preparacao[id];
      this.choice(
        q.text,
        q.options,
        (i) => {
          const correct = i === q.answer;
          this.state.epaTasks.push(id);
          this.state.epaPreparation = clamp(
            this.state.epaPreparation + (correct ? 33 : 10),
          );
          this.refresh();
          SaveManager.write(this.state);
          this.say(
            [
              line(
                correct ? "NIKO" : "LIA",
                correct
                  ? "Boa! Mais uma parte pronta."
                  : "Vamos corrigir juntos. " + q.options[q.answer] + ".",
              ),
              line(
                "BIA",
                correct
                  ? "Olha só. Trabalho em equipe funciona."
                  : "Ainda bem que a gente testou antes da feira.",
              ),
            ],
            () => {
              if (this.state.epaTasks.length === 3) this.toEPA();
            },
          );
        },
        { subtitle: "Não precisa ser perfeito para avançar.", y: 90 },
      );
    } else
      this.say([
        line(
          id === "niko" ? "NIKO" : "BIA",
          id === "niko"
            ? "O sistema precisa estar funcionando. Testar nunca é demais."
            : "Problema. Solução. Benefícios. Sem ler o slide inteiro.",
        ),
      ]);
  }
  toEPA() {
    this.say(
      [line("LIA", "O projeto está pronto. A gente te ajuda lá na frente.")],
      () => this.go("DiaEPA"),
    );
  }
}
export class DiaEPA extends Cinematic {
  constructor() {
    super("DiaEPA");
  }
  create() {
    this.setup();
    this.audio.music("epa");
    this.backdrop("epa");
    this.say(dialogos.epa, () => this.go("Apresentacao"));
  }
}
export class Apresentacao extends Cinematic {
  constructor() {
    super("Apresentacao");
  }
  create() {
    this.setup();
    this.checkpoint();
    this.backdrop("epa");
    this.audio.music("epa");
    this.addHUD("EPA · APRESENTAÇÃO", "ESPAÇO respirar · 1–3 / setas escolher");
    this.confidence = clamp(
      45 +
        this.state.epaPreparation * 0.3 +
        (this.state.examScore >= 80 ? 8 : 0),
    );
    this.nervous = 35;
    this.cooldown = 0;
    this.stage = 1;
    this.q = 0;
    this.finished = false;
    this.seconds = 0;
    this.metrics = this.text(320, 60, " ", 10, "#f2cb78")
      .setOrigin(0.5)
      .setDepth(4800);
    this.say(
      [
        line("AVALIADOR", "Podemos conhecer o projeto de vocês?"),
        line("LIA", "Vai lá. Você consegue."),
        line("PLAYER", "Tá. Vamos começar."),
      ],
      () => this.introduction(),
    );
  }
  refresh() {
    this.hud.update(
      `ETAPA ${this.stage}/3\nCONFIANÇA ${Math.round(this.confidence)}/100`,
    );
    this.metrics.setText(
      `NERVOSISMO ${Math.round(this.nervous)}/100 · ESPAÇO: ${this.cooldown > 0 ? "respirar em " + Math.ceil(this.cooldown) + "s" : "respirar"}`,
    );
  }
  breathe() {
    if (this.cooldown || this.dialogue.active || this.finished) return;
    this.nervous = clamp(this.nervous - 20);
    this.cooldown = 5;
    this.audio.effect("coracao");
    this.notice("Respire. Você não está sozinho.");
  }
  tick(dt) {
    if (this.dialogue.active || this.finished || !this.panel) return;
    this.cooldown = Math.max(0, this.cooldown - dt);
    this.nervous = clamp(this.nervous + dt * 0.65);
    this.seconds += dt;
    this.refresh();
    if (this.nervous >= 100) {
      this.closePanel();
      this.nervous = 50;
      this.confidence = clamp(this.confidence - 5);
      this.say(
        [
          line("LIA", "Olha pra gente. Respira. Você sabe explicar isso."),
          line(
            "BIA",
            "A apresentação é uma conversa. Não precisa ser perfeita.",
          ),
        ],
        () => this.resumeStage(),
      );
    }
  }
  resumeStage() {
    if (this.stage === 1) this.introduction();
    else if (this.stage === 2) this.demo();
    else this.questions();
  }
  reward(right) {
    this.confidence = clamp(this.confidence + (right ? 12 : -8));
    this.nervous = clamp(this.nervous + (right ? -5 : 10));
    this.audio.effect(right ? "acerto" : "erro");
  }
  introduction() {
    const question = epa[0];
    this.choice(
      question.text,
      question.options,
      (i) => {
        this.reward(i === 0);
        this.say(
          [
            line(
              "PLAYER",
              i === 0
                ? configJogo.project.problem
                : i === 1
                  ? "A gente… precisava entregar. Mas também identificou um problema."
                  : "Vamos mostrar um exemplo. Fica mais claro.",
            ),
            line(
              "AVALIADOR",
              i === 0
                ? "Interessante. Continuem."
                : "Certo. Gostaríamos de ver como funciona.",
            ),
          ],
          () => {
            this.stage = 2;
            this.demoStep = 0;
            this.demo();
          },
        );
      },
      { subtitle: configJogo.project.name, y: 100 },
    );
  }
  demo() {
    const actions = [
      "Abrir a aplicação",
      "Demonstrar a funcionalidade",
      "Mostrar o resultado",
    ];
    this.choice(
      "DEMONSTRAÇÃO · " + (this.demoStep + 1) + "/3",
      actions,
      (i) => {
        if (i === this.demoStep) {
          this.notice("✓ " + actions[i]);
          this.demoStep++;
          this.confidence = clamp(this.confidence + 4);
          if (this.demoStep === 3) {
            this.say([line("AVALIADOR", "Entendi. Muito bom.")], () => {
              this.stage = 3;
              this.questions();
            });
          } else this.time.delayedCall(700, () => this.demo());
        } else {
          this.nervous = clamp(this.nervous + 8);
          this.say(
            [
              line("PLAYER", "Calma… isso funcionava ontem."),
              line(
                "NIKO",
                "Clássico. Abre a aplicação, demonstra e mostra o resultado.",
              ),
            ],
            () => this.demo(),
          );
        }
      },
      {
        subtitle: "Faça as ações em ordem. Se errar, você pode corrigir.",
        y: 100,
      },
    );
  }
  questions() {
    const q = epa[this.q + 1];
    this.choice(
      q.text,
      q.options,
      (i) => {
        this.reward(i === q.answer);
        this.q++;
        if (this.q < 3)
          this.say(
            [
              line(
                "AVALIADOR",
                i === q.answer
                  ? "Obrigado. Vamos à próxima pergunta."
                  : "Entendi. Vale refletir sobre isso na próxima versão.",
              ),
            ],
            () => this.questions(),
          );
        else this.complete();
      },
      {
        subtitle: "PERGUNTA " + (this.q + 1) + "/3 · fale com honestidade",
        y: 100,
      },
    );
  }
  complete() {
    this.finished = true;
    this.state.presentation = {
      confidence: Math.round(this.confidence),
      nervous: Math.round(this.nervous),
    };
    SaveManager.write(this.state);
    this.audio.music("amizade");
    this.audio.effect("aplausos");
    this.say(
      [
        line("PLAYER", "Acabou?"),
        line("AVALIADOR", "Obrigado pela apresentação."),
        line(
          "AVALIADOR",
          this.confidence >= 60
            ? "Parabéns pelo trabalho. Vocês foram muito claros."
            : "Vocês têm uma boa ideia. Continuem testando e praticando.",
        ),
        line("LIA", "Conseguimos."),
        line("NIKO", "Eu falei."),
        line("BIA", "Você tava tremendo."),
        line("PLAYER", "Eu sei."),
      ],
      () => this.go("Final"),
    );
  }
}
