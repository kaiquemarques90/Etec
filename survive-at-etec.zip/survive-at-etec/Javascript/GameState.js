export const clamp = (value, min = 0, max = 100) =>
  Math.min(max, Math.max(min, value));
export function newState() {
  return {
    version: 1,
    scene: "Prologo",
    bimestre: 1,
    known: [],
    friendship: 0,
    interest: null,
    routine: { day: 1, actions: 3, energy: 70, preparation: 0, stress: 20 },
    examScore: null,
    route: null,
    caught: false,
    epaTasks: [],
    epaPreparation: 0,
    presentation: null,
    seen: [],
    history: [],
    completed: false,
  };
}
export function mention(score) {
  return score >= 80 ? "MB" : score >= 60 ? "B" : score >= 40 ? "R" : "I";
}
export const routineActions = {
  estudar: { label: "Estudar", energy: -15, preparation: 20, stress: 10 },
  descansar: { label: "Descansar", energy: 25, preparation: 0, stress: -10 },
  exercicios: {
    label: "Fazer exercícios",
    energy: -10,
    preparation: 10,
    stress: 5,
  },
  amigos: {
    label: "Conversar com amigos",
    energy: 5,
    preparation: 0,
    stress: -15,
  },
  jogar: { label: "Jogar", energy: 15, preparation: 0, stress: -10 },
  dormir: { label: "Dormir cedo", energy: 30, preparation: 0, stress: -15 },
};
export function applyRoutine(routine, action) {
  const a = routineActions[action];
  if (!a || routine.day > 3) return { ...routine };
  const r = { ...routine };
  for (const key of ["energy", "preparation", "stress"])
    r[key] = clamp(r[key] + a[key]);
  r.actions = action === "dormir" ? 0 : r.actions - 1;
  if (r.actions <= 0) {
    r.day++;
    r.actions = 3;
    r.energy = clamp(r.energy + 10);
    r.stress = clamp(r.stress - 5);
  }
  return r;
}
export function examSeconds(r) {
  return (
    20 +
    Math.floor(r.preparation / 10) +
    Math.floor(r.energy / 20) -
    Math.floor(r.stress / 25)
  );
}
export function updateRisk(risk, seconds, consulting, watching) {
  return {
    ...risk,
    suspicion: clamp(
      risk.suspicion + seconds * (consulting ? (watching ? 20 : 2) : -8),
    ),
    nervous: clamp(risk.nervous + seconds * (consulting ? 12 : -6)),
  };
}
export function breathe(risk) {
  return { ...risk, nervous: clamp(risk.nervous - 20) };
}
