export class Player extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y) {
    super(scene, x, y, "player", 1);
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.setScale(1 / 3).setOrigin(0.5, 0.85);
    this.body.setSize(36, 21).setOffset(30, 66);
    this.setCollideWorldBounds(true);
    this.keys = scene.input.keyboard.addKeys("W,A,S,D,UP,DOWN,LEFT,RIGHT");
    this.direction = "down";
    this.lastStep = 0;
  }
  update(locked = false) {
    let x = 0,
      y = 0;
    if (!locked) {
      const k = this.keys;
      x =
        (k.D.isDown || k.RIGHT.isDown ? 1 : 0) -
        (k.A.isDown || k.LEFT.isDown ? 1 : 0);
      y =
        (k.S.isDown || k.DOWN.isDown ? 1 : 0) -
        (k.W.isDown || k.UP.isDown ? 1 : 0);
    }
    this.body.setVelocity(x * 115, y * 115);
    if (x && y) this.body.velocity.normalize().scale(115);
    if (x || y) {
      this.direction =
        Math.abs(x) > 0 ? (x < 0 ? "left" : "right") : y < 0 ? "up" : "down";
      this.play("player-" + this.direction, true);
      if (this.scene.time.now - this.lastStep > 290) {
        this.scene.audio.effect("passos");
        this.lastStep = this.scene.time.now;
      }
    } else {
      this.anims.stop();
      this.setFrame({ down: 1, left: 4, right: 7, up: 10 }[this.direction]);
    }
    this.setDepth(this.y);
  }
}
