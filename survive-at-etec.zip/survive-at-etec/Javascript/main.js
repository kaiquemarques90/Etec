import { newState } from "./GameState.js";
import { SaveManager } from "./SaveManager.js";
import { AudioManager } from "./AudioManager.js";
import { Boot } from "./Scenes/Boot.js";
import {
  Prologo,
  CutsceneInicio,
  CutsceneEPA,
  Final,
} from "./Scenes/Cinematic.js";
import {
  Titulo,
  TransicaoBimestre,
  Encerramento,
  Creditos,
} from "./Scenes/Titulo.js";
import { Bimestre1 } from "./Scenes/Bimestre1.js";
import { Bimestre2, Prova } from "./Scenes/Bimestre2.js";
import { Bimestre3, RotaHonesta, RotaCola } from "./Scenes/Bimestre3.js";
import { Bimestre4, DiaEPA, Apresentacao } from "./Scenes/Bimestre4.js";
let game = null;
const cover = document.getElementById("start-cover");
function launch() {
  if (game) return;
  cover.hidden = true;
  document.body.classList.remove("project-mode");
  document.getElementById("project-page").hidden = true;
  const options = SaveManager.options();
  game = new Phaser.Game({
    type: Phaser.CANVAS,
    parent: "game",
    width: 640,
    height: 360,
    backgroundColor: "#11151f",
    pixelArt: true,
    roundPixels: true,
    scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
    physics: { default: "arcade", arcade: { debug: false } },
    audio: { disableWebAudio: false },
    scene: [
      Boot,
      Prologo,
      Titulo,
      CutsceneInicio,
      Bimestre1,
      TransicaoBimestre,
      Bimestre2,
      Prova,
      Bimestre3,
      RotaHonesta,
      RotaCola,
      CutsceneEPA,
      Bimestre4,
      DiaEPA,
      Apresentacao,
      Final,
      Encerramento,
      Creditos,
    ],
    callbacks: {
      preBoot(g) {
        g.registry.set("state", SaveManager.read() || newState());
        g.registry.set("options", options);
        g.registry.set("audio", new AudioManager(g, options));
      },
    },
  });
  window.etecGame = game;
  game.events.on("project", showProject);
}
function showProject() {
  if (game) {
    game.registry.get("audio")?.stop();
    game.input.keyboard.enabled = false;
    game.destroy(true);
    game = null;
    window.etecGame = null;
  }
  document.body.classList.add("project-mode");
  document.getElementById("project-page").hidden = false;
  window.scrollTo({ top: 0, behavior: "instant" });
}
document.getElementById("launch").addEventListener("click", launch);
document.getElementById("project-link").addEventListener("click", showProject);
document.getElementById("return-game").addEventListener("click", () => {
  document.body.classList.remove("project-mode");
  document.getElementById("project-page").hidden = true;
  cover.hidden = false;
  window.scrollTo({ top: 0, behavior: "instant" });
});
document.getElementById("fullscreen").addEventListener("click", () => {
  const p = document.getElementById("viewport");
  if (document.fullscreenElement) document.exitFullscreen();
  else p.requestFullscreen?.();
});
document.getElementById("sound-toggle").addEventListener("click", (e) => {
  if (!game) return;
  const audio = game.registry.get("audio");
  audio.muted = !audio.muted;
  audio.apply();
  e.currentTarget.textContent = audio.muted
    ? "♫ SOM DESLIGADO"
    : "♫ SOM LIGADO";
});
const codes = {
  ArrowUp: 38,
  ArrowDown: 40,
  ArrowLeft: 37,
  ArrowRight: 39,
  KeyE: 69,
  Enter: 13,
  Space: 32,
  KeyC: 67,
  Escape: 27,
};
for (const button of document.querySelectorAll("[data-key]")) {
  const dispatch = (type) => {
    const code = button.dataset.key;
    window.dispatchEvent(
      new KeyboardEvent(type, {
        code,
        key: code === "Enter" ? "Enter" : code === "Space" ? " " : code,
        keyCode: codes[code],
        which: codes[code],
        bubbles: true,
      }),
    );
  };
  button.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    button.setPointerCapture(e.pointerId);
    dispatch("keydown");
  });
  button.addEventListener("pointerup", () => dispatch("keyup"));
  button.addEventListener("pointercancel", () => dispatch("keyup"));
}
