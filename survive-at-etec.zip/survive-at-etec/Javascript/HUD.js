export class HUD {
  constructor(scene, title, objective) {
    this.scene = scene;
    this.container = scene.add
      .container(0, 0)
      .setScrollFactor(0)
      .setDepth(4000);
    this.bg = scene.add.rectangle(0, 0, 640, 49, 0x11151f, 0.94).setOrigin(0);
    this.title = scene.add.text(14, 9, title, {
      fontFamily: "monospace",
      fontSize: "10px",
      color: "#f2cb78",
    });
    this.objective = scene.add.text(14, 27, objective, {
      fontFamily: "monospace",
      fontSize: "9px",
      color: "#dbd4c8",
    });
    this.stat = scene.add
      .text(626, 10, "", {
        fontFamily: "monospace",
        fontSize: "9px",
        color: "#e7d6b8",
        align: "right",
        lineSpacing: 7,
      })
      .setOrigin(1, 0);
    this.container.add([this.bg, this.title, this.objective, this.stat]);
  }
  update(text) {
    this.stat.setText(text);
  }
  objectiveText(text) {
    this.objective.setText(text);
  }
}
