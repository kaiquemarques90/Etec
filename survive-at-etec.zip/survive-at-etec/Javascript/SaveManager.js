import { newState } from "./GameState.js";
const key = "survive-at-etec-v1",
  optionsKey = "survive-at-etec-options";
const stages = [
  "Prologo",
  "CutsceneInicio",
  "Bimestre1",
  "Bimestre2",
  "Prova",
  "Bimestre3",
  "RotaHonesta",
  "RotaCola",
  "CutsceneEPA",
  "Bimestre4",
  "Apresentacao",
  "Final",
  "Encerramento",
];
export class SaveManager {
  static read() {
    try {
      const d = JSON.parse(localStorage.getItem(key));
      if (
        !d ||
        d.version !== 1 ||
        !stages.includes(d.scene) ||
        !Array.isArray(d.known) ||
        !Array.isArray(d.epaTasks) ||
        !d.routine ||
        !Number.isFinite(d.routine.day)
      )
        return null;
      const base = newState();
      return {
        ...base,
        ...d,
        routine: { ...base.routine, ...d.routine },
        seen: Array.isArray(d.seen) ? d.seen : [],
        history: Array.isArray(d.history) ? d.history.slice(-150) : [],
      };
    } catch {
      return null;
    }
  }
  static write(state) {
    try {
      localStorage.setItem(key, JSON.stringify(state));
      return true;
    } catch {
      return false;
    }
  }
  static options() {
    try {
      return {
        ...this.defaults,
        ...JSON.parse(localStorage.getItem(optionsKey) || "{}"),
      };
    } catch {
      return { ...this.defaults };
    }
  }
  static defaults = {
    music: 0.28,
    sfx: 0.32,
    textSpeed: 24,
    reduceShake:
      globalThis.matchMedia?.("(prefers-reduced-motion: reduce)").matches ||
      false,
  };
  static saveOptions(value) {
    try {
      localStorage.setItem(optionsKey, JSON.stringify(value));
    } catch {}
  }
}
