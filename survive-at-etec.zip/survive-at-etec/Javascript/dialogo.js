const portraits = {
  LIA: "lia",
  NIKO: "niko",
  BIA: "bia",
  DIOGO: "professor-diogo",
  PLAYER: "player",
  "TRYHARD 1": "tryhard",
  "TRYHARD 2": "tryhard",
  "TRYHARD 3": "tryhard",
  "JOGADOR 1": "jogador",
  "JOGADOR 2": "jogador",
  "JOGADOR 3": "jogador",
  "MISTERIOSO 1": "misterioso",
  "MISTERIOSO 2": "misterioso",
  "MISTERIOSO 3": "misterioso",
};
export class DialogueBox {
  constructor(scene) {
    this.scene = scene;
    this.active = false;
    this.lines = [];
    this.index = 0;
    this.char = 0;
    this.elapsed = 0;
    this.container = scene.add
      .container(12, 244)
      .setScrollFactor(0)
      .setDepth(5000);
    const bg = scene.add
      .rectangle(0, 0, 616, 104, 0x11151f, 0.98)
      .setOrigin(0)
      .setStrokeStyle(1, 0xe7d6b8);
    this.name = scene.add.text(84, 9, "", {
      fontFamily: "monospace",
      fontSize: "10px",
      color: "#f2cb78",
    });
    this.text = scene.add.text(84, 28, "", {
      fontFamily: "monospace",
      fontSize: "12px",
      color: "#f2f2f2",
      wordWrap: { width: 512 },
      lineSpacing: 4,
    });
    this.hint = scene.add
      .text(606, 85, "ENTER / toque  ▸", {
        fontFamily: "monospace",
        fontSize: "8px",
        color: "#999eac",
      })
      .setOrigin(1, 0);
    this.portrait = scene.add.image(42, 49, "player-retrato").setScale(0.75);
    this.container
      .add([bg, this.name, this.text, this.hint, this.portrait])
      .setVisible(false);
    bg.setInteractive().on("pointerdown", () => this.advance());
  }
  show(lines, done) {
    this.lines = lines;
    this.index = 0;
    this.done = done;
    this.active = true;
    this.container.setVisible(true);
    this.line();
  }
  line() {
    const line = this.lines[this.index];
    if (!line) {
      this.active = false;
      this.container.setVisible(false);
      const done = this.done;
      this.done = null;
      done?.();
      return;
    }
    this.char = 0;
    this.elapsed = 0;
    this.name.setText(line.speaker || "NARRADOR");
    this.text.setText("");
    const p = portraits[line.speaker];
    this.portrait.setVisible(!!p);
    this.text.setX(p ? 84 : 17);
    this.name.setX(p ? 84 : 17);
    this.text.setWordWrapWidth(p ? 512 : 580);
    if (p) this.portrait.setTexture(p + "-retrato");
    const state = this.scene.state;
    state.history.push({ speaker: line.speaker, text: line.text });
    state.history = state.history.slice(-150);
    if (line.text === "Que ingenuidade." && !this.scene.options.reduceShake) {
      this.scene.cameras.main.shake(130, 0.003);
      this.scene.audio.effect("rejeicao");
    }
    line.event?.();
  }
  advance() {
    if (!this.active) return;
    const line = this.lines[this.index];
    if (this.char < line.text.length) {
      this.char = line.text.length;
      this.text.setText(line.text);
    } else {
      this.index++;
      this.line();
    }
  }
  update(delta) {
    if (!this.active) return;
    const line = this.lines[this.index];
    this.elapsed += delta;
    const interval = this.scene.options.textSpeed;
    while (this.elapsed >= interval && this.char < line.text.length) {
      this.elapsed -= interval;
      this.char++;
      this.text.setText(line.text.slice(0, this.char));
      if (this.char % 3 === 0)
        this.scene.audio.effect(
          line.speaker === "DIOGO"
            ? "dialogo-professor"
            : line.speaker === "NARRADOR"
              ? "dialogo-narrador"
              : "dialogo-blip",
        );
    }
  }
}
